## Docker ref
- https://docs.docker.com/engine/reference/builder/#escape

## Buildah
- https://opensource.com/article/18/6/getting-started-buildah
- https://opensource.com/article/19/3/tips-tricks-rootless-buildah?utm_campaign=intrel
- https://buildah.io/

## SELinux
- https://en.wikipedia.org/wiki/Security-Enhanced_Linux
- https://en.wikipedia.org/wiki/Role-based_access_control
- https://en.wikipedia.org/wiki/Strace

- https://wiki.centos.org/HowTos/SELinux
- https://opensource.com/business/13/11/selinux-policy-guide
- https://opensource.com/business/14/7/docker-security-selinux
- https://opensource.com/business/14/9/security-for-docker
- https://opensource.com/article/18/2/understanding-selinux-labels-container-runtimes
- https://developers.redhat.com/blog/2018/11/29/managing-containerized-system-services-with-podman/
- https://medium.com/lucjuggery/docker-selinux-30-000-foot-view-30f6ef7f621
- https://danwalsh.livejournal.com/78373.html
- https://prefetch.net/blog/2017/09/30/using-docker-volumes-on-selinux-enabled-servers/

## Assignment (live code)
Build a container image that will using docker or buildah or runc:
- Will run as non-root user named "user1" with UID "3001"
- Will have a bind mounted volume at "/mydata" inside the container
- When executed will echo the string "hello world" to the terminal and write the same string to the file "/mydata/hello.txt"


