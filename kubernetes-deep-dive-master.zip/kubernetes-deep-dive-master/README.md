# Kubernetes-deep-dive


- [Linux Internal](https://medium.com/@hungys)
- [K8S Metrics](https://blog.freshtracks.io/@bob_cotton)
- [Understanding resource limits in kubernetes: cpu time](https://medium.com/@betz.mark/understanding-resource-limits-in-kubernetes-cpu-time-9eff74d3161b)
- [Understanding resource limits in kubernetes: memory](https://medium.com/@betz.mark/understanding-resource-limits-in-kubernetes-memory-6b41e9a955f9)
- [Getting Memory Usage in Linux and Docker](https://shuheikagawa.com/blog/2017/05/27/memory-usage/)
- [](https://github.com/bcicen/ctop)
- [strace](https://access.redhat.com/articles/2483)