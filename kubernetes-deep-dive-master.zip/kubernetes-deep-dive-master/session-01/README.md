# Kubernetes deep dive - Session 01

# Videos
- [Linux Container Internals: Lab 1: Container Architecture](https://youtu.be/gcfjWF_H5SU?t=0)
- [Linux Container Internals: Lab 2: Container Images](https://youtu.be/P5NaEXmJuWo?t=0)
- [Linux Container Internals - Lab 3](https://youtu.be/_R0kvlALF6s?t=0)
- [Linux Container Internals - Lab 4](https://youtu.be/6IYTYV8DuXc?t=0)

# Labs
- [Subsystems, Components, and Internals](https://www.katacoda.com/fatherlinux/courses/subsystems)

<!--
https://www.youtube.com/watch?v=KawKGsLR1V8&t=5852s
https://docs.google.com/presentation/d/1OpsvPvA82HJjHN3Vm2oVrqca1FCfn0PAfxGZ2w_ZZgc/edit#slide=id.g2441f8cc8d_0_0
https://docs.google.com/presentation/d/1S-JqLQ4jatHwEBRUQRiA5WOuCwpTUnxl2d1qRUoTz5g/edit#slide=id.g3e1a17e39e_2_83
https://github.com/fatherlinux/container-internals-lab
https://medium.com/@nagarwal/understanding-the-docker-internals-7ccb052ce9fe
-->