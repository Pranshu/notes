# Kubernetes deep dive - Session 02

## Linux namespace and cgroups
- [What even is a container: namespaces and cgroups](https://jvns.ca/blog/2016/10/10/what-even-is-a-container/)
- [Linux containers from scratch](https://wvi.cz/diyC/)
- [Namespaces in operation](https://lwn.net/Articles/531114/)
- [Everything You Need to Know about Linux Containers, Part I: Linux Control Groups and Process Isolation](https://www.linuxjournal.com/content/everything-you-need-know-about-linux-containers-part-i-linux-control-groups-and-process)
- [Linux Namespaces](https://medium.com/@teddyking/linux-namespaces-850489d3ccf)

## Blog post
- [Container Runtimes Part 1: An Introduction to Container Runtimes](https://www.ianlewis.org/en/container-runtimes-part-1-introduction-container-r)
- [Building Containers from Scratch](https://blog.gojekengineering.com/building-containers-from-scratch-c2368a8c8701)

## Slides
- [Linux Primitives](https://docs.google.com/presentation/d/10vFQfEUvpf7qYyksNqiy-bAxcy-bvF0OnUElCOtTTRc/edit#slide=id.p)
- [Docker Without Docker](http://chimeracoder.github.io/docker-without-docker/#1)

## Man
- [Linux Man Pages](http://man7.org/index.html)

## Video
- [Containers from Scratch](https://www.youtube.com/watch?v=wyqoi52k5jM&t=269s)
  - [Tutorial - Walk through](https://ericchiang.github.io/post/containers-from-scratch/)
- [The what and why of the namespaces that make containerization possible](https://youtu.be/gMpldbcMHuI?t=5)
- [Isolation without Containers](https://youtu.be/VGcwrPFl90U?t=0)

## Utils
- [buildroot.org](https://buildroot.org/docs.html)





























- https://www.linuxtechi.com/download-rpm-using-yumdownloader-centos-7-rhel-7/