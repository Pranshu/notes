## Single node cluster
- [ ] Control plane node untaint
- [x] CoreDNS & LB configs
- [x] Tigera SE in IP-IP mode
- [ ] Localdev using vagrant

## Production cluster
- [ ] Custom Node labeling
- [ ] Default compute node label
- [ ] NIC bonding
- [ ] 802.1Q trunking a.k.a vlan tagging
- [ ] LACP tunning
- [ ] LLDP
- [ ] Static Route
- [ ] iSCSI Luns
- [ ] Disable Internal Registry
- [x] Custom TLS certificates
- [x] Tigera SE in IP-IP mode
- [ ] Tigera SE in BGP mode
- [ ] PortWorx integration
- [ ] Sysdig integration
- [ ] Trident integration
- [ ] Custom logging
- [ ] Custom monitoring
- [ ] Synergy automation
- [ ] DL automation
- [ ] Cluster expansion procedure
- [ ] OIDC integration