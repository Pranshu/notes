#!/bin/bash -xe

if [ "$CLUSTER_NAME" == "" ]; then
    echo "Need cluster name set, set CLUSTER_NAME env var"
    exit 1
fi
if [ "$INFRASTRUCTURE_NAME" == "" ]; then
    echo "Need infrastructure name set, set INFRASTRUCTURE_NAME env var"
    echo "That should come from the metadata.json, by doing 'jq -r .infraID metadata.json'"
    exit 1
fi

#Outputs from $CLUSTER_NAME-osh4-vpc:
#  VpcId:
#    Description: ID of the newly created VPC
#    Value: !Ref VPC
#  PublicSubnetIds:
#    Description: Subnet IDs of the public subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PublicSubnet, !If [DoAz2, !Ref PublicSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PublicSubnet3, !Ref "AWS::NoValue"]]
#      ]
#  PrivateSubnetIds:
#    Description: Subnet IDs of the private subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PrivateSubnet, !If [DoAz2, !Ref PrivateSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PrivateSubnet3, !Ref "AWS::NoValue"]]
#      ]

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-vpc

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-vpc)"
vpcid="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="VpcId") | .OutputValue')"
public_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PublicSubnetIds") | .OutputValue')"

#Outputs from $CLUSTER_NAME-osh4-infra:
#  PrivateHostedZoneId:
#    Description: Hosted zone ID for the private DNS - needed for private records
#    Value: !Ref IntDns
#  ExternalApiLoadBalancerName:
#    Description: Full name of the External API load balancer created.
#    Value: !GetAtt ExtApiElb.LoadBalancerFullName
#  InternalApiLoadBalancerName:
#    Description: Full name of the Internal API load balancer created.
#    Value: !GetAtt IntApiElb.LoadBalancerFullName
#  ApiServerDnsName:
#    Description: Full hostname of the API server - Needed for ignition configs
#    Value: !Join [".", ["api-int", !Ref ClusterName, !Ref HostedZoneName]]
#  RegisterNlbIpTargetsLambda:
#    Description: Lambda ARN useful to help register/deregister IP targets for these load balancers
#    Value: !GetAtt RegisterNlbIpTargets.Arn
#  ExternalApiTargetGroupArn:
#    Description: ARN of External API target group
#    Value: !Ref ExternalApiTargetGroup
#  InternalApiTargetGroupArn:
#    Description: ARN of Internal API target group
#    Value: !Ref InternalApiTargetGroup
#  InternalServiceTargetGroupArn:
#    Description: ARN of internal service target group
#    Value: !Ref InternalServiceTargetGroup
stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-infra)"
register_nlb_lambda="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="RegisterNlbIpTargetsLambda") | .OutputValue')"
external_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="ExternalApiTargetGroupArn") | .OutputValue')"
internal_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="InternalApiTargetGroupArn") | .OutputValue')"
internal_service_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="InternalServiceTargetGroupArn") | .OutputValue')"

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-infra

#Outputs of $CLUSTER_NAME-osh4-sec:
#  MasterSecurityGroupId:
#    Description: Master Security Group ID
#    Value: !GetAtt MasterSecurityGroup.GroupId
#  WorkerSecurityGroupId:
#    Description: Worker Security Group ID
#    Value: !GetAtt WorkerSecurityGroup.GroupId
#  MasterInstanceProfile:
#    Description: Master IAM Instance Profile
#    Value: !Ref MasterInstanceProfile
#  WorkerInstanceProfile:
#    Description: Worker IAM Instance Profile
#    Value: !Ref WorkerInstanceProfile

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-sec

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-sec)"
master_sg_id="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="MasterSecurityGroupId") | .OutputValue')"

# Dependent on the region, see openshift/installer repo data/data/rhcos.json
rhcos_ami=ami-00745fcbb14a863ed

bootstrap_file=bootstrap.ign
if [ ! -f $bootstrap_file ]; then
  echo "No bootstrap ignition file: $bootstrap_file"
  exit 1
fi

S3_BUCKET=tigera-openshift-ignition
aws s3api put-object --bucket $S3_BUCKET --acl private --key $INFRASTRUCTURE_NAME/bootstrap.ign --body bootstrap.ign

#Parameters:
#  InfrastructureName:
#  PublicSubnet:
#    Type: AWS::EC2::Subnet::Id
#  VpcId:
#    Type: AWS::EC2::VPC::Id
#  RhcosAmi:
#    Type: AWS::EC2::Image::Id
#  AllowedBootstrapSshCidr:
#    Default: 0.0.0.0/0
#    Description: CIDR block to allow SSH access to the bootstrap node
#  MasterSecurityGroupId:
#    Type: AWS::EC2::SecurityGroup::Id
#  BootstrapIgnitionLocation:
#    Default: s3://my-s3-bucket/bootstrap.ign
#    Description: Location to fetch bootstrap ignition from. (Recommend to use the autocreated cf-templates bucket.)
#  AutoRegisterELB:
#    Default: "yes"
#    Description: Do you want to invoke NLB registration (requires Lambda ARN parameter to be supplied)?
#  RegisterNlbIpTargetsLambdaArn:
#    Description: ARN for NLB IP target registration lambda
#  ExternalApiTargetGroupArn:
#    Description: ARN for external API load balancer target group
#  InternalApiTargetGroupArn:
#    Description: ARN for internal API load balancer target group
#  InternalServiceTargetGroupArn:
#    Description: ARN for internal service load balancer target group
aws cloudformation create-stack --stack-name $CLUSTER_NAME-osh4-bootstrap \
    --template-body file://$(pwd)/cloudformation/04_cluster_bootstrap.yaml \
    --capabilities CAPABILITY_IAM \
    --parameters \
    ParameterKey=InfrastructureName,ParameterValue=$INFRASTRUCTURE_NAME \
    ParameterKey=VpcId,ParameterValue=$vpcid \
    ParameterKey=PublicSubnet,ParameterValue=$public_subnet_ids \
    ParameterKey=RhcosAmi,ParameterValue=$rhcos_ami \
    ParameterKey=MasterSecurityGroupId,ParameterValue=$master_sg_id \
    ParameterKey=BootstrapIgnitionLocation,ParameterValue=s3://$S3_BUCKET/$INFRASTRUCTURE_NAME/bootstrap.ign \
    ParameterKey=RegisterNlbIpTargetsLambdaArn,ParameterValue=$register_nlb_lambda \
    ParameterKey=ExternalApiTargetGroupArn,ParameterValue=$external_group_arn \
    ParameterKey=InternalApiTargetGroupArn,ParameterValue=$internal_group_arn \
    ParameterKey=InternalServiceTargetGroupArn,ParameterValue=$internal_service_group_arn

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-bootstrap
