#!/bin/bash -xe


if [ "$CLUSTER_NAME" == "" ]; then
    echo "Need cluster name set, set CLUSTER_NAME env var"
    exit 1
fi
if [ "$INFRASTRUCTURE_NAME" == "" ]; then
    echo "Need infrastructure name set, set INFRASTRUCTURE_NAME env var"
    echo "That should come from the metadata.json, by doing 'jq -r .infraID metadata.json'"
    exit 1
fi

HOSTED_ZONE_ID=${HOSTED_ZONE_ID:-Z35TLZYX4SGCM9}
HOSTED_ZONE_NAME=${HOSTED_ZONE_NAME:-openshift.crc.aws.eng.tigera.net}

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-vpc

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-vpc)"
vpcid="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="VpcId") | .OutputValue')"
private_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PrivateSubnetIds") | .OutputValue')"

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-infra

### HERE

#Parameters:
#  InfrastructureName:
#    AllowedPattern: ^([a-zA-Z][a-zA-Z0-9\-]{0,26})$
#    MaxLength: 27
#  VpcCidr:
#    Default: 10.0.0.0/16
#  VpcId:
#    Type: AWS::EC2::VPC::Id
#  PrivateSubnets:
#    Type: List<AWS::EC2::Subnet::Id>
aws cloudformation create-stack --stack-name $CLUSTER_NAME-osh4-sec \
    --template-body file://$(pwd)/cloudformation/03_cluster_security.yaml \
    --capabilities CAPABILITY_IAM \
    --parameters \
    ParameterKey=InfrastructureName,ParameterValue=$INFRASTRUCTURE_NAME \
    ParameterKey=VpcId,ParameterValue=$vpcid \
    ParameterKey=PrivateSubnets,ParameterValue=$private_subnet_ids

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-sec

