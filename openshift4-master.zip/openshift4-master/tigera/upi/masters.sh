#!/bin/bash -xe

if [ "$CLUSTER_NAME" == "" ]; then
    echo "Need cluster name set, set CLUSTER_NAME env var"
    exit 1
fi
if [ "$INFRASTRUCTURE_NAME" == "" ]; then
    echo "Need infrastructure name set, set INFRASTRUCTURE_NAME env var"
    echo "That should come from the metadata.json, by doing 'jq -r .infraID metadata.json'"
    exit 1
fi

# Dependent on the region, see openshift/installer repo data/data/rhcos.json
rhcos_ami=ami-00745fcbb14a863ed

S3_BUCKET=tigera-openshift-ignition

HOSTED_ZONE_NAME=${HOSTED_ZONE_NAME:-openshift.crc.aws.eng.tigera.net}

ca_base64=$(cat bootstrap.ign | jq -r '.storage.files[] | select(.path=="/opt/openshift/tls/root-ca.crt") | .contents.source')

#Outputs from $CLUSTER_NAME-osh4-vpc:
#  VpcId:
#    Description: ID of the newly created VPC
#    Value: !Ref VPC
#  PublicSubnetIds:
#    Description: Subnet IDs of the public subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PublicSubnet, !If [DoAz2, !Ref PublicSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PublicSubnet3, !Ref "AWS::NoValue"]]
#      ]
#  PrivateSubnetIds:
#    Description: Subnet IDs of the private subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PrivateSubnet, !If [DoAz2, !Ref PrivateSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PrivateSubnet3, !Ref "AWS::NoValue"]]
#      ]

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-vpc

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-vpc)"
#vpcid="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="VpcId") | .OutputValue')"
#public_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PublicSubnetIds") | .OutputValue')"
private_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PrivateSubnetIds") | .OutputValue')"

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-infra
#Outputs from $CLUSTER_NAME-osh4-infra:
#  PrivateHostedZoneId:
#    Description: Hosted zone ID for the private DNS - needed for private records
#    Value: !Ref IntDns
#  ExternalApiLoadBalancerName:
#    Description: Full name of the External API load balancer created.
#    Value: !GetAtt ExtApiElb.LoadBalancerFullName
#  InternalApiLoadBalancerName:
#    Description: Full name of the Internal API load balancer created.
#    Value: !GetAtt IntApiElb.LoadBalancerFullName
#  ApiServerDnsName:
#    Description: Full hostname of the API server - Needed for ignition configs
#    Value: !Join [".", ["api-int", !Ref ClusterName, !Ref HostedZoneName]]
#  RegisterNlbIpTargetsLambda:
#    Description: Lambda ARN useful to help register/deregister IP targets for these load balancers
#    Value: !GetAtt RegisterNlbIpTargets.Arn
#  ExternalApiTargetGroupArn:
#    Description: ARN of External API target group
#    Value: !Ref ExternalApiTargetGroup
#  InternalApiTargetGroupArn:
#    Description: ARN of Internal API target group
#    Value: !Ref InternalApiTargetGroup
#  InternalServiceTargetGroupArn:
#    Description: ARN of internal service target group
#    Value: !Ref InternalServiceTargetGroup
stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-infra)"
private_hosted_zone_id="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PrivateHostedZoneId") | .OutputValue')"
register_nlb_lambda="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="RegisterNlbIpTargetsLambda") | .OutputValue')"
external_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="ExternalApiTargetGroupArn") | .OutputValue')"
internal_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="InternalApiTargetGroupArn") | .OutputValue')"
internal_service_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="InternalServiceTargetGroupArn") | .OutputValue')"


aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-sec
#Outputs of $CLUSTER_NAME-osh4-sec:
#  MasterSecurityGroupId:
#    Description: Master Security Group ID
#    Value: !GetAtt MasterSecurityGroup.GroupId
#  WorkerSecurityGroupId:
#    Description: Worker Security Group ID
#    Value: !GetAtt WorkerSecurityGroup.GroupId
#  MasterInstanceProfile:
#    Description: Master IAM Instance Profile
#    Value: !Ref MasterInstanceProfile
#  WorkerInstanceProfile:
#    Description: Worker IAM Instance Profile
#    Value: !Ref WorkerInstanceProfile

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-sec)"
master_sg_id="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="MasterSecurityGroupId") | .OutputValue')"
master_profile="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="MasterInstanceProfile") | .OutputValue')"

aws s3api put-object --bucket $S3_BUCKET --acl private --key $INFRASTRUCTURE_NAME/bootstrap.ign --body bootstrap.ign

#Outputs from $CLUSTER_NAME-osh4-bootstrap:
#  BootstrapInstanceId:
#    Description: Bootstrap Instance ID
#    Value: !Ref BootstrapInstance
#
#  BootstrapPublicIp:
#    Description: The bootstrap node public IP address
#    Value: !GetAtt BootstrapInstance.PublicIp
#
#  BootstrapPrivateIp:
#    Description: The bootstrap node private IP address
#    Value: !GetAtt BootstrapInstance.PrivateIp

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-bootstrap

#Parameters:
#  InfrastructureName:
#  RhcosAmi:
#    Description: Current RHEL CoreOS AMI to use for boostrap
#    Type: AWS::EC2::Image::Id
#  MasterSecurityGroupId:
#    Type: AWS::EC2::SecurityGroup::Id
#  AutoRegisterDNS:
#    Default: "yes"
#    Description: Do you want to invoke DNS etcd registration (requires Hosted Zone info provided)?
#  PrivateHostedZoneId:
#    Description: The Route53 private zone ID to register the etcd targets with (e.g Z21IXYZABCZ2A4)
#  PrivateHostedZoneName:
#    Description: The Route53 zone to register the targets with (No trailing dot - e.g. cluster.mycorp.com)
#  Master0Subnet:
#    Description: The subnets (recommend private) to launch the master nodes into
#    Type: AWS::EC2::Subnet::Id
#  Master1Subnet:
#    Description: The subnets (recommend private) to launch the master nodes into
#    Type: AWS::EC2::Subnet::Id
#  Master2Subnet:
#    Description: The subnets (recommend private) to launch the master nodes into
#    Type: AWS::EC2::Subnet::Id
#  IgnitionLocation:
#    Default: https://api-int.$CLUSTER_NAME.$DOMAIN:22623/config/master
#    Description: Location to fetch bootstrap ignition from. (Recommend to use the autocreated ignition config location.)
#    Type: String
#  CertificateAuthorities:
### this could definitely be wrong
#    Default: data:text/plain;charset=utf-8;base64,ABC...xYz==
#  MasterInstanceProfileName:
#    Description: IAM profile to associate with master nodes.
#    Type: String
#  MasterInstanceType:
#    Default: m4.xlarge
#  AutoRegisterELB:
#    Default: "yes"
#  RegisterNlbIpTargetsLambdaArn:
#    Description: ARN for NLB IP target registration lambda (from cluster_infra_upi.yaml; otherwise select "no" for AutoRegisterELB)
#    Type: String
#  ExternalApiTargetGroupArn:
#    Description: ARN for external API load balancer target group (from cluster_infra_upi.yaml; otherwise select "no" for AutoRegisterELB)
#    Type: String
#  InternalApiTargetGroupArn:
#    Description: ARN for internal API load balancer target group (from cluster_infra_upi.yaml; otherwise select "no" for AutoRegisterELB)
#    Type: String
#  InternalServiceTargetGroupArn:
#    Description: ARN for internal service load balancer target group (from cluster_infra_upi.yaml; otherwise select "no" for AutoRegisterELB)
#    Type: String

aws cloudformation create-stack --stack-name $CLUSTER_NAME-osh4-masters \
    --template-body file://$(pwd)/cloudformation/05_cluster_master_nodes.yaml \
    --parameters \
    ParameterKey=InfrastructureName,ParameterValue=$INFRASTRUCTURE_NAME \
    ParameterKey=RhcosAmi,ParameterValue=$rhcos_ami \
    ParameterKey=MasterSecurityGroupId,ParameterValue=$master_sg_id \
    ParameterKey=PrivateHostedZoneId,ParameterValue=$private_hosted_zone_id \
    ParameterKey=PrivateHostedZoneName,ParameterValue=$CLUSTER_NAME.$HOSTED_ZONE_NAME \
    ParameterKey=Master0Subnet,ParameterValue=$private_subnet_ids \
    ParameterKey=Master1Subnet,ParameterValue=$private_subnet_ids \
    ParameterKey=Master2Subnet,ParameterValue=$private_subnet_ids \
    ParameterKey=IgnitionLocation,ParameterValue=https://api-int.$CLUSTER_NAME.$HOSTED_ZONE_NAME:22623/config/master \
    ParameterKey=CertificateAuthorities,ParameterValue=$(echo $ca_base64 | sed -e 's/,/\\,/g') \
    ParameterKey=MasterInstanceProfileName,ParameterValue=$master_profile \
    ParameterKey=RegisterNlbIpTargetsLambdaArn,ParameterValue=$register_nlb_lambda \
    ParameterKey=ExternalApiTargetGroupArn,ParameterValue=$external_group_arn \
    ParameterKey=InternalApiTargetGroupArn,ParameterValue=$internal_group_arn \
    ParameterKey=InternalServiceTargetGroupArn,ParameterValue=$internal_service_group_arn

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-masters
