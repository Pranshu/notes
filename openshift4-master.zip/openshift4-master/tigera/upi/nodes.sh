#!/bin/bash -xe

if [ "$CLUSTER_NAME" == "" ]; then
    echo "Need cluster name set, set CLUSTER_NAME env var"
    exit 1
fi
if [ "$INFRASTRUCTURE_NAME" == "" ]; then
    echo "Need infrastructure name set, set INFRASTRUCTURE_NAME env var"
    echo "That should come from the metadata.json, by doing 'jq -r .infraID metadata.json'"
    exit 1
fi

# Dependent on the region, see openshift/installer repo data/data/rhcos.json
rhcos_ami=ami-00745fcbb14a863ed

S3_BUCKET=tigera-openshift-ignition

HOSTED_ZONE_NAME=${HOSTED_ZONE_NAME:-openshift.crc.aws.eng.tigera.net}

ca_base64=$(cat bootstrap.ign | jq -r '.storage.files[] | select(.path=="/opt/openshift/tls/root-ca.crt") | .contents.source')

#Outputs from $CLUSTER_NAME-osh4-vpc:
#  VpcId:
#    Description: ID of the newly created VPC
#    Value: !Ref VPC
#  PublicSubnetIds:
#    Description: Subnet IDs of the public subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PublicSubnet, !If [DoAz2, !Ref PublicSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PublicSubnet3, !Ref "AWS::NoValue"]]
#      ]
#  PrivateSubnetIds:
#    Description: Subnet IDs of the private subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PrivateSubnet, !If [DoAz2, !Ref PrivateSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PrivateSubnet3, !Ref "AWS::NoValue"]]
#      ]

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-vpc

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-vpc)"
#vpcid="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="VpcId") | .OutputValue')"
#public_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PublicSubnetIds") | .OutputValue')"
private_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PrivateSubnetIds") | .OutputValue')"

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-infra
#Outputs from $CLUSTER_NAME-osh4-infra:
#  PrivateHostedZoneId:
#    Description: Hosted zone ID for the private DNS - needed for private records
#    Value: !Ref IntDns
#  ExternalApiLoadBalancerName:
#    Description: Full name of the External API load balancer created.
#    Value: !GetAtt ExtApiElb.LoadBalancerFullName
#  InternalApiLoadBalancerName:
#    Description: Full name of the Internal API load balancer created.
#    Value: !GetAtt IntApiElb.LoadBalancerFullName
#  ApiServerDnsName:
#    Description: Full hostname of the API server - Needed for ignition configs
#    Value: !Join [".", ["api-int", !Ref ClusterName, !Ref HostedZoneName]]
#  RegisterNlbIpTargetsLambda:
#    Description: Lambda ARN useful to help register/deregister IP targets for these load balancers
#    Value: !GetAtt RegisterNlbIpTargets.Arn
#  ExternalApiTargetGroupArn:
#    Description: ARN of External API target group
#    Value: !Ref ExternalApiTargetGroup
#  InternalApiTargetGroupArn:
#    Description: ARN of Internal API target group
#    Value: !Ref InternalApiTargetGroup
#  InternalServiceTargetGroupArn:
#    Description: ARN of internal service target group
#    Value: !Ref InternalServiceTargetGroup
#stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-infra)"
#private_hosted_zone_id="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PrivateHostedZoneId") | .OutputValue')"
#register_nlb_lambda="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="RegisterNlbIpTargetsLambda") | .OutputValue')"
#external_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="ExternalApiTargetGroupArn") | .OutputValue')"
#internal_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="InternalApiTargetGroupArn") | .OutputValue')"
#internal_service_group_arn="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="InternalServiceTargetGroupArn") | .OutputValue')"


aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-sec
#Outputs of $CLUSTER_NAME-osh4-sec:
#  MasterSecurityGroupId:
#    Description: Master Security Group ID
#    Value: !GetAtt MasterSecurityGroup.GroupId
#  WorkerSecurityGroupId:
#    Description: Worker Security Group ID
#    Value: !GetAtt WorkerSecurityGroup.GroupId
#  MasterInstanceProfile:
#    Description: Master IAM Instance Profile
#    Value: !Ref MasterInstanceProfile
#  WorkerInstanceProfile:
#    Description: Worker IAM Instance Profile
#    Value: !Ref WorkerInstanceProfile

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-sec)"
worker_sg_id="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="WorkerSecurityGroupId") | .OutputValue')"
worker_profile="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="WorkerInstanceProfile") | .OutputValue')"

aws s3api put-object --bucket $S3_BUCKET --acl private --key $INFRASTRUCTURE_NAME/bootstrap.ign --body bootstrap.ign

#Outputs from $CLUSTER_NAME-osh4-bootstrap:
#  BootstrapInstanceId:
#    Description: Bootstrap Instance ID
#    Value: !Ref BootstrapInstance
#
#  BootstrapPublicIp:
#    Description: The bootstrap node public IP address
#    Value: !GetAtt BootstrapInstance.PublicIp
#
#  BootstrapPrivateIp:
#    Description: The bootstrap node private IP address
#    Value: !GetAtt BootstrapInstance.PrivateIp

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-bootstrap

#Outputs from $CLUSTER_NAME-osh4-masters:
#  PrivateIPs:
#    Description: The control-plane node private IP addresses
#    Value:
#      !Join [
#        ",",
#        [!GetAtt Master0.PrivateIp, !GetAtt Master1.PrivateIp, !GetAtt Master2.PrivateIp]
#      ]

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-masters

ignition_loc=https://api-int.$CLUSTER_NAME.$HOSTED_ZONE_NAME:22623/config/worker

#Parameters:
#  InfrastructureName:
#  RhcosAmi:
#    Type: AWS::EC2::Image::Id
#  WorkerSubnet:
#    Type: AWS::EC2::Subnet::Id
#  WorkerSecurityGroupId:
#    Type: AWS::EC2::SecurityGroup::Id
#  IgnitionLocation:
#    Default: https://api-int.$CLUSTER_NAME.$DOMAIN:22623/config/worker
#  CertificateAuthorities:
#    Default: data:text/plain;charset=utf-8;base64,ABC...xYz==
#  WorkerInstanceProfileName:
#    Description: IAM profile to associate with master nodes.
#  WorkerInstanceType:
#    Default: m4.large
aws cloudformation create-stack --stack-name $CLUSTER_NAME-osh4-workers \
    --template-body file://$(pwd)/cloudformation/06_cluster_worker_node.yaml \
    --parameters \
    ParameterKey=InfrastructureName,ParameterValue=$INFRASTRUCTURE_NAME \
    ParameterKey=RhcosAmi,ParameterValue=$rhcos_ami \
    ParameterKey=WorkerSubnet,ParameterValue=$private_subnet_ids \
    ParameterKey=WorkerSecurityGroupId,ParameterValue=$worker_sg_id \
    ParameterKey=IgnitionLocation,ParameterValue=$ignition_loc \
    ParameterKey=CertificateAuthorities,ParameterValue=$(echo $ca_base64 | sed -e 's/,/\\,/g') \
    ParameterKey=WorkerInstanceProfileName,ParameterValue=$worker_profile
