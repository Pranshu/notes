#!/bin/bash -xe

if [ "$CLUSTER_NAME" == "" ]; then
    echo "Need cluster name set, set CLUSTER_NAME env var"
    exit 1
fi
if [ "$INFRASTRUCTURE_NAME" == "" ]; then
    echo "Need infrastructure name set, set INFRASTRUCTURE_NAME env var"
    echo "That should come from the metadata.json, by doing 'jq -r .infraID metadata.json'"
    exit 1
fi

HOSTED_ZONE_ID=${HOSTED_ZONE_ID:-Z35TLZYX4SGCM9}
HOSTED_ZONE_NAME=${HOSTED_ZONE_NAME:-openshift.crc.aws.eng.tigera.net}

#VPC cloud stack outputs
#Outputs:
#  VpcId:
#    Description: ID of the newly created VPC
#    Value: !Ref VPC
#  PublicSubnetIds:
#    Description: Subnet IDs of the public subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PublicSubnet, !If [DoAz2, !Ref PublicSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PublicSubnet3, !Ref "AWS::NoValue"]]
#      ]
#  PrivateSubnetIds:
#    Description: Subnet IDs of the private subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PrivateSubnet, !If [DoAz2, !Ref PrivateSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PrivateSubnet3, !Ref "AWS::NoValue"]]
#      ]

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-vpc

stack_info="$(aws cloudformation describe-stacks --stack-name $CLUSTER_NAME-osh4-vpc)"
vpcid="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="VpcId") | .OutputValue')"
public_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PublicSubnetIds") | .OutputValue')"
private_subnet_ids="$(echo $stack_info | jq --raw-output '.Stacks[0].Outputs[] | select(.OutputKey=="PrivateSubnetIds") | .OutputValue')"

## Parameters:
#  ClusterName:
#    AllowedPattern: ^([a-zA-Z][a-zA-Z0-9\-]{0,26})$
#    MaxLength: 27
#  InfrastructureName:
#    AllowedPattern: ^([a-zA-Z][a-zA-Z0-9\-]{0,26})$
#    MaxLength: 27
#  HostedZoneId:
#    Description: The Route53 public zone ID to register the targets with (e.g Z21IXYZABCZ2A4)
#  HostedZoneName:
#    Description: The Route53 zone to register the targets with (No trailing dot - e.g. mycorp.com)
#  PublicSubnets:
#    Type: List<AWS::EC2::Subnet::Id>
#  PrivateSubnets:
#    Type: List<AWS::EC2::Subnet::Id>
#  VpcId:
#    Type: AWS::EC2::VPC::Id
aws cloudformation create-stack --stack-name $CLUSTER_NAME-osh4-infra \
    --template-body file://$(pwd)/cloudformation/02_cluster_infra.yaml \
    --capabilities CAPABILITY_NAMED_IAM \
    --parameters ParameterKey=ClusterName,ParameterValue=$CLUSTER_NAME \
    ParameterKey=InfrastructureName,ParameterValue=$INFRASTRUCTURE_NAME \
    ParameterKey=HostedZoneId,ParameterValue=$HOSTED_ZONE_ID \
    ParameterKey=HostedZoneName,ParameterValue=$HOSTED_ZONE_NAME \
    ParameterKey=PublicSubnets,ParameterValue=$public_subnet_ids \
    ParameterKey=PrivateSubnets,ParameterValue=$private_subnet_ids \
    ParameterKey=VpcId,ParameterValue=$vpcid

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-infra

