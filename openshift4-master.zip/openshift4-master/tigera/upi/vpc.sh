#!/bin/bash -xe

if [ "$CLUSTER_NAME" == "" ]; then
    echo "Need cluster name set, set CLUSTER_NAME env var"
    exit 1
fi

## Possible parameters for VPC
# VpcCidr:
#   Default: 10.0.0.0/16

### I think increasing this count will increase the SubnetIds that are generated
### in the output which I think some of the other scripts would need updating to
### handle.
# AvailabilityZoneCount:
#   Default: 1
# SubnetBits:
#   Default: 12
aws cloudformation create-stack --stack-name $CLUSTER_NAME-osh4-vpc \
    --template-body file://$(pwd)/cloudformation/01_vpc.yaml
#Outputs:
#  VpcId:
#    Description: ID of the newly created VPC
#    Value: !Ref VPC
#  PublicSubnetIds:
#    Description: Subnet IDs of the public subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PublicSubnet, !If [DoAz2, !Ref PublicSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PublicSubnet3, !Ref "AWS::NoValue"]]
#      ]
#  PrivateSubnetIds:
#    Description: Subnet IDs of the private subnets
#    Value:
#      !Join [
#        ",",
#        [!Ref PrivateSubnet, !If [DoAz2, !Ref PrivateSubnet2, !Ref "AWS::NoValue"], !If [DoAz3, !Ref PrivateSubnet3, !Ref "AWS::NoValue"]]
#      ]

aws cloudformation wait stack-create-complete --stack-name $CLUSTER_NAME-osh4-vpc

