#!/bin/bash -xe

if [ "$CLUSTER_NAME" == "" ]; then
    echo "Need cluster name set, set CLUSTER_NAME env var"
    exit 1
fi
if [ "$INFRASTRUCTURE_NAME" == "" ]; then
    echo "Need infrastructure name set, set INFRASTRUCTURE_NAME env var"
    echo "That should come from the metadata.json, by doing 'jq -r .infraID metadata.json'"
    exit 1
fi

S3_BUCKET=tigera-openshift-ignition

## Workers/Nodes
aws cloudformation delete-stack --stack-name $CLUSTER_NAME-osh4-workers
aws cloudformation wait stack-delete-complete --stack-name $CLUSTER_NAME-osh4-workers

## Masters
aws cloudformation delete-stack --stack-name $CLUSTER_NAME-osh4-masters
aws cloudformation wait stack-delete-complete --stack-name $CLUSTER_NAME-osh4-masters

## Bootstrap
aws cloudformation delete-stack --stack-name $CLUSTER_NAME-osh4-bootstrap
aws cloudformation wait stack-delete-complete --stack-name $CLUSTER_NAME-osh4-bootstrap

aws s3api delete-object --bucket $S3_BUCKET --key $INFRASTRUCTURE_NAME/bootstrap.ign

## Security
aws cloudformation delete-stack --stack-name $CLUSTER_NAME-osh4-sec
aws cloudformation wait stack-delete-complete --stack-name $CLUSTER_NAME-osh4-sec

## Infrastructure
aws cloudformation delete-stack --stack-name $CLUSTER_NAME-osh4-infra
aws cloudformation wait stack-delete-complete --stack-name $CLUSTER_NAME-osh4-infra

## VPC
aws cloudformation delete-stack --stack-name $CLUSTER_NAME-osh4-vpc
aws cloudformation wait stack-delete-complete --stack-name $CLUSTER_NAME-osh4-vpc

