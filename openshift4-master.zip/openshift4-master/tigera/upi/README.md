# Installation with Openshift v4 when using UPI

These steps are for installing Openshift v4 when doing
User Provided Infrastructre (UPI), this is different from the higher level
docs in that they were written to make use of Installer Provided Infrastructure
or more simply for the openshift-installer to create and manage the
infrastructure.

The directions here make use of Cloud Formation templates that were copied from
the openshift/install repo for creating UPI on AWS. There are some assumptions
that the scripts depend on such as:
  * The bucket `tigera-openshift-ignition` exists and is writable by your aws cli.
  * Only one subnet for each private and public are expected.
There are probably other assumptions too.

## Pre-requisites

* You will need openshift-installer 4.1.0 or greater.
* You will need functional aws cli and credentials set up.

## Installation

The directions for UPI installation follow the regular Openshift installation
directions with the same modifications that are called out in ../docs/calico.md.
To prevent repeating the other directions general references will be made here
about when the Calico/TSEE directions should be followed.

### General Configuration Steps

1. Create installation config

   `openshift-install create install-config`

1. Any updates needed for UPI should be performed.
   AWS UPI indicated the following was needed.

   `sed -i '1,/replicas: / s/replicas: .*/replicas: 0/' install-config.yaml`

1. Do Calico/TSEE updates to the install-config.

1. Create manifests

   `openshift-install create manifests`

1. Do any UPI needed updates.
   AWS UPI suggested the following:

   `rm -f openshift/99_openshift-cluster-api_master-machines-*.yaml openshift/99_openshift-cluster-api_worker-machinesets-*.yaml`

1. Do Calico/TSEE updates to the manifests

1. Complete cluster install (see section below)
   Once the API server becomes available it may be necessary to make adjustments
   for bugs in the openshift network-operator, check the Calico/TSEE updates.

1. If installing TSEE, continue with post operator steps. These are no different
   than using an IPI installation so refer to ../docs/calico.md for those steps.

### Completing cluster install on AWS

These are the specific steps to finish a UPI installation on AWS.

1. Create the ignition-configs (this should be common among UPI installs)

   `openshift-install create ignition-configs`

1. Create environment variables for the cluster and infrastructure name

   ```
   INFRASTRUCTURE_NAME=$(jq -r .infraID metadata.json)
   export INFRASTRUCTURE_NAME
   CLUSTER_NAME=$(jq -r .clusterName metadata.json)
   export CLUSTER_NAME
   ```

1. Install VPC Cloud Formation

   `./vpc.sh`

1. Install Infrastructure Cloud Formation

   `./infra.sh`

1. Install Security Cloud Formation (Creates Security Groups)
   The Cloud Formation has been updated to create the rules needed for BGP
   and IPIP traffic that Calico needs.

   `./security.sh`

1. Install Bootstrap Cloud Formation (creates bootstrap node)

   `./bootstrap.sh`

1. Install Master Cloud Formation (creates 3 master nodes)

   `./masters.sh`

1. Monitor for bootstrap-complete and Initialization

   `openshift-install wait-for bootstrap-complete`

1. During the above you can wait for the API server to become available and then
   do the next step.

   ```
   export KUBECONFIG=./auth/kubeconfig
   while ! kubectl get nodes; do sleep 1; done
   ```

1. Do the Calico/TSEE updates for the openshift network-operator bug.

1. Once the wait for bootstrap-complete is finished you may delete the
   bootstrap resources.
   If you do then after the next step it will be necessary to approve the
   CSR requrests for nodes manually.
   (The bootstrap resource should not be left on indefinitely because it will
   auto-approve any new CSR requests.)

1. Install Worker Cloud Formation (creates 1 worker node)

   `./nodes.sh`

1. Approve CSRs

   `oc get csr`

   then approve with

   `oc adm certificate approve <csr-name>`

1. Monitor for cluster completion

   `openshift-install wait-for install-complete`
