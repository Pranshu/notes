# AWS Assumptions

This doc describes the AWS settings that an Openshift v4 cluster relies on.

#### Base Domain

> Amazon's Route53 service is used by the OpenShift installer to configure cluster DNS resolution and provide name lookup for the cluster to the outside world. To use OpenShift, you must have created a public hosted zone in Amazon Route53 in the same account as your OpenShift cluster. You must also ensure the zone is "authoritative" for the domain. There are two ways to do this outlined below: root domain and subdomain. A root domain is openshiftcorp.com. A subdomain is of the form clusters.openshiftcorp.com.

Getting a zone that is authoritative for the domain involves: 
1. Creating a new public hosted zone in Route53 for your cluster
2. Registering the domain so that DNS servers can lookup the hostname

For our CRC Openshift v4 clusters the above steps have already been completed. A public hosted zone has been created in Route53 with domain name `openshift.crc.aws.eng.tigera.net`. 

When you create a new Openshift v4 cluster using the Openshift installer make sure you select the above domain as your Base Domain when prompted. 

You can read more about the DNS requirements from Openshift [here](https://github.com/openshift/installer/blob/master/docs/user/aws/route53.md). 
