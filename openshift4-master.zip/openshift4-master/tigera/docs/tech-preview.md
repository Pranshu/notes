# Tech-preview: OpenShift v4 with Tigera Secure EE

## Prerequisites

1. Host network must allow the required BGP and IP-in-IP traffic for Calico / Tigera Secure EE (if using installer-provisioned infrastructure, this is automated in AWS security groups).
1. You must be using v4.2 version of the openshift-install binary. You may need to [build this from source.](https://github.com/openshift/installer)

## Known issues

None

## Create an appropriate install-config.yaml

1. Create an install-config.yaml file. See the [RedHat documentation](https://docs.openshift.com/container-platform/4.1/welcome/index.html) for more information.

   ```
   openshift-install create install-config
   ```

1. Edit the generated config file to disable OpenShiftSDN for networking

   ```
   sed -i  's/OpenShiftSDN/Calico/' install-config.yaml
   ```

1. Edit the generated config to set a larger worker node size that meets Tigera Secure EE host requirements.

   ```
   sed -i 's/platform: {}/platform:\n    aws:\n      type: m4.xlarge/g' install-config.yaml
   ```

> Note: You can avoid having to repeat this step by creating a backup of the generated file. Otherwise, it will be destroyed in the following steps.


### Reduce default cluster size

To reduce AWS costs, update the install-config to configure a smaller cluster and cheaper storage.
You need [yq installed](https://github.com/mikefarah/yq#install).

```
yq merge --overwrite --inplace install-config.yaml hack/dev-infra-overrides.yaml
```

## Generate manifests to use

1. Now, populate the manifests directory based on the config.

   ```
   openshift-install create manifests
   ```

1. Once complete, add in the Tigera operator manifests:

   ```
   cp hack/calico/* manifests
   ```

1. If installing Tigera Secure EE then copy the following manifests as well:

   ```
   cp hack/tsee/* manifests
   ```

1. If installing Tigera Secure EE update the pull secret manifest with credentials for quay:

   ```
   DOCKER_CFG_ENC=$(cat <DOCKER_CFG> | tr -d '\n\r\t ' | base64 -w 0)
   sed -i "s/DOCKER_CFG/$DOCKER_CFG_ENC/" manifests/02-ps.yaml
   ```

## Create the cluster

The steps here may vary based on platform and installation type. See the RedHat documentation for detailed installation steps for both
user-provisioned infrastructure (UPI) as well as installer provisioned infrastructure (IPI).

- RedHat documentation for [user-provisioned infrastructure (bare-metal)](https://docs.openshift.com/container-platform/4.1/installing/installing_bare_metal/installing-bare-metal.html)
- RedHat documentation for [user-provisioned infrastructure (vSphere)](https://docs.openshift.com/container-platform/4.1/installing/installing_vsphere/installing-vsphere.html)

### Example: Installing using IPI on Amazon

1. Update the manifests directory to use the AWS operator (this includes an init container to configure the Security Groups)

   ```
   cp hack/tigera-operator-ipi/* manifests
   ```

1. Start the cluster creation.

   ```
   openshift-install create cluster
   ```

   This will take a while.

   ```
   INFO Consuming "Openshift Manifests" from target directory
   INFO Consuming "Worker Machines" from target directory
   INFO Consuming "Common Manifests" from target directory
   INFO Consuming "Master Machines" from target directory
   INFO Creating infrastructure resources...
   INFO Waiting up to 30m0s for the Kubernetes API at https://api.casey-ocp.openshift.crc.aws.eng.tigera.net:6443...
   ```

1. Once the above appears, wait for the apiserver to be available in another terminal.

   ```
   export KUBECONFIG=./auth/kubeconfig
   while ! oc get nodes; do sleep 1; done
   ```

1. You should then eventually see all cluster operators become ready and the installer will complete.

   ```
   oc get clusteroperator
   ```

1. You can see the Tigera operator installation status with the following command. Node that some components may be
   listed as "Degraded" until the logging and monitoring components are installed below.

   ```
   oc get tigerastatus
   ```

## After the installation - "day 2 operations"

### Finishing the Tigera Secure installation

If you're installing the Tigera Secure EE components, also execute the following steps.

1. Install the Tigera Secure EE license

   ```
   oc create -f <license_file.yaml>
   ```

1. Enable privileged security context constraints for the default calico-monitoring user.

   ```
   oc adm policy add-scc-to-user --namespace=calico-monitoring privileged -z default
   ```

1. Install the Tigera Secure EE metrics and logging operators.

   ```
   oc create -f hack/tsee-post-operator/operator.yaml
   ```

1. Wait for operator CRDs to be present. Look for the following CRDs to be created:

   ```
   alertmanagers.monitoring.coreos.com
   prometheuses.monitoring.coreos.com
   servicemonitors.monitoring.coreos.com
   prometheusrules.monitoring.coreos.com
   elasticsearchclusters.enterprises.upmc.com
   ```

1. Apply the Tigera Secure EE manifests, which will install the remaining Tigera Secure EE components.

   ```
   oc create -f hack/tsee-post-operator/elastic-storage-local.yaml
   oc create -f hack/tsee-post-operator/monitor-calico.yaml
   ```

1. Wait for all Tigera components to become available.

   ```
   watch oc get tigerastatus
   ```

1. Apply the Tigera network policies.

   ```
   oc create -f hack/tsee-post-operator/policy.yaml
   ```

1. Create a serviceaccount for accessing the manager, replacing <name> with the user's name.

   ```
   oc create sa <name>
   ```

   ```
   oc create clusterrolebinding <name>-admin --clusterrole=cluster-admin --serviceaccount=default:<name>
   ```

### Log in to Tigera Secure EE

1. Get the token for logging into the manager

   ```
   oc sa get-token <name>
   ```

1. Setup port forwarding for easy access to the UI.

   ```
   oc port-forward "$(oc get po -l k8s-app=cnx-manager -n tigera-console -oname)" 9443:9443 -n tigera-console
   ```

1. Open browser to https://localhost:9443/login/token and login with the token.
