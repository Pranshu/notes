## Minimum Requirements
- MacOS
- [VMware Fusion](https://www.vmware.com/products/fusion/fusion-evaluation.html)

> ⚠ __NOTE__: You or your department needs to procure a VMware Fusion license.


## MacOS utilities
On MacOS following utilities must be installed
``` bash
brew install bash
brew install bind
brew install gnu-sed
brew install gnu-getopt
brew install openssl
sudo easy_install pip
sudo pip install passlib
```

## OCP 4 Installer Architecture

![OCP4 Installer](ocp4-arch.svg  "OCP4 Installer")

## Infra
- [Bastion Server Mgmt UI](http://bastion.ocp4.local:9090)
- [Bastion Web Server](http://bastion.ocp4.local:8000)
- [Bastion Load Balancer](http://bastion.ocp4.local:9000)
- [Bastion LB Health Endpoint](http://api.ocp4.local:9000/healthz)
- [Worker Machine Config](https://api-int.ocp4.local:22623/config/worker)
- [Master Machine Config](https://api-int.ocp4.local:22623/config/master)
- [Vendored Media](https://files.caas.ford.com:9443/iso/)

> ⚠ __NOTE__: Note these links only work if you have working pxe/bastion VM running for [details see](#start-bastionpxe-server).


## Server Profiles
For each supporting environment we must build create [`server-profiles.json`](./server-profiles.json) file, this file name be overridden by an environment variable `INVENTORY_FILE`. The information contained in this file is used to generate many configurations file for example:
1. Seed DHCP server so that it doles out correct IP address
1. Generate iPXE chainloader menus
1. Generate and provision install media for network install
1. Generate Ignitions file by OpenShift installer
1. In case of localdev it also used to generate DNS configurations

>💡 __NOTE:__ The file `server-profiles.json` or the filename in the ENV variable `INVENTORY_FILE` refer to a file located at the root of git repository

>⚠  __NOTE:__ You need to on Ford network to download the `bastion.ova` hosted at https://files.caas.ford.com:9443/ova/bastion.ova. Other option would be build the bastion vm using [Red Hat 8 binary DVD](#building-rhel8-bastion-vm-to-host-pxe-container). You can also manually download the file https://files.caas.ford.com:9443/ova/bastion.ova to `<LOCAL-REPO-DIR>/artifacts/vms/bastion.ova`, but if you are on the Ford network this is not necessary


## Download the OpenShift 4.x bits
```bash
./vendor-clients.sh
./vendor-rhcos.sh
```
>💡 __NOTE:__ if you would like to update version of RHCOS and OCP then update the above mentioned scripts

## Start RHEL8 bastion server
```bash
./main.sh --start-vm bastion
```

## Provision Bastion/PXE server
```bash
./main.sh --provision-bastion-server
```

## Build, Provision & Start containers
```bash
./main.sh --build-container-image
./main.sh --provision-container
./main.sh --start-containers
```

## Check if all containers are running
```
ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/bastion" \
    admin@bastion.ocp4.local \
    -t "sudo podman ps"
```

## Create VMs to host OpenShift v4.x
__NOTE:__ The "bootstrap" VM should be destroyed/shutdown after successful deployment of OpenShift v4.x

```bash
./main.sh --start-vm bootstrap
./main.sh --start-vm master-0
./main.sh --start-vm worker-0
```
<!-- >💡 __NOTE:__ By default we start a single node OCP4.x cluster, however if you would like to standup a one master one along with one worker node then export environment variable `OCP_NUM_WORKER` and start the worker-0 vm as well -->

## Install cluster
These must run inside the pxe/bastion VM. For detailed documentation please refer to these upstream [OpenShift v4.1 docs](https://docs.openshift.com/container-platform/4.1/installing/installing_bare_metal/installing-bare-metal.html)

### Start the cluster install and wait for control plane to start
These command must be run inside the bastion VM, to do first ssh into [bastion vm](#ssh-into-bastion)

```bash
sudo su -

eval "$(ssh-agent -s)"
for s in bootstrap master-0 worker-0; do
    ln -sf /mnt/hgfs/share/artifacts/ssh/core /mnt/hgfs/share/artifacts/ssh/${s}
    ssh-add /mnt/hgfs/share/artifacts/ssh/${s}
done

openshift-install \
    wait-for bootstrap-complete \
    --dir=/mnt/hgfs/share/clusters/ocp4 \
    --log-level debug 2>&1 | \
    tee /mnt/hgfs/share/artifacts/logs/bootstrap-complete.log
```

### Remove bootstrap node from LB
These command must be run inside the bastion VM, to do first ssh into [bastion vm](#ssh-into-bastion)
```bash
sudo su -
export KUBECONFIG=/mnt/hgfs/share/clusters/ocp4/auth/kubeconfig
/usr/bin/podman stop haproxy
/usr/bin/podman rm haproxy
sudo sed -i '/^\    server bootstrap/s/^/#/g' /opt/pxe-server-files/haproxy/haproxy.cfg
/usr/bin/podman run \
	--name haproxy \
	--detach=true \
	--cap-add=NET_BIND_SERVICE \
	-p 9000:9000 \
	-p 22623:22623 \
	-p 6443:6443 \
	-p 80:80 \
	-p 443:443 \
	-v /opt/pxe-server-files/haproxy/haproxy.cfg:/usr/local/etc/haproxy/haproxy.cfg:Z \
	docker.io/haproxy:2.0.1-alpine
```

### Stop bootstrap node
This must be run on your MacOS host
```bash
./main.sh --stop-vm bootstrap
```

### Wait for worker nodes to come online
These command must be run inside the bastion VM, to do first run [bastion vm](#ssh-into-bastion)
```bash
sudo su -
openshift-install \
    wait-for install-complete \
    --dir=/mnt/hgfs/share/clusters/ocp4 \
    --log-level debug 2>&1 | \
    tee /mnt/hgfs/share/artifacts/logs/install-complete.log
```
>💡This step will not return even though it say's its 100% complete, since we are building a one master and one worker. Since few components have multiple replicas with anti-affinity rules. Hence the installer report we are 100% complete we will terminate this task and continue.

### Patch OpenShift Internal Registry
While above is running in another session to [bastion vm](#ssh-into-bastion) run
```bash
export KUBECONFIG=/mnt/hgfs/share/clusters/ocp4/auth/kubeconfig
oc patch configs.imageregistry.operator.openshift.io \
    cluster --type merge \
    --patch '{"spec":{"storage":{"emptyDir":{}}}}'
```

### Stop bastion vm and rewire CoreDNS running on host mac
Now that we have working instance of single node OCP4.2 cluster we can stop bastion VM, but we need to update CoreDNS configs so that we can compensate for lack of loadbalancer which is running on bastion VM. We will do so by updating the CoreDNS zone file. Note that these must be run on your Mac.
```
sudo launchctl unload $(pwd)/artifacts/coredns/coredns.plist
sudo mv $(pwd)/artifacts/coredns/zones/db.ocp4.local $(pwd)/artifacts/coredns/zones/db.ocp4.local.lb
sudo mv $(pwd)/artifacts/coredns/zones/5.17.172.db $(pwd)/artifacts/coredns/zones/5.17.172.db.lb
#sudo cp -f $(pwd)/templates/coredns/zones/db.ocp4.local.nolb $(pwd)/artifacts/coredns/zones/db.ocp4.local
sudo cp -f $(pwd)/templates/coredns/zones/db.ocp4.local.aio.nolb $(pwd)/artifacts/coredns/zones/db.ocp4.local
sudo cp -f $(pwd)/templates/coredns/zones/5.17.172.aio.db $(pwd)/artifacts/coredns/zones/5.17.172.db
echo '' | sudo tee $(pwd)/artifacts/coredns/coredns.log > /dev/null
sudo launchctl unload $(pwd)/artifacts/coredns/coredns.plist || :
sudo launchctl load $(pwd)/artifacts/coredns/coredns.plist || :
sudo killall -HUP mDNSResponder
sudo killall mDNSResponderHelper
sudo dscacheutil -flushcache
./main.sh --stop-vm bastion
```

### OpenShift Console
Note that these must be run on your Mac.
```bash
#https://docs.openshift.com/container-platform/4.1/web-console/web-console.html
export PATH=$(pwd)/artifacts/bin:$PATH
export KUBECONFIG=$(pwd)/clusters/ocp4/auth/kubeconfig
export KUBEPASSWD=$(cat $(pwd)/clusters/ocp4/auth/kubeadmin-password)
export OCP4UI="https://console-openshift-console.apps.ocp4.local"

open -a /Applications/Google\ Chrome.app ${OCP4UI}

#oc login -u kubeadmin -p ${KUBEPASSWD}
cat $(pwd)/clusters/ocp4/auth/kubeadmin-password | pbcopy

```
Finally time for us to unfurl the sails ...
<img src="sailboat.png" alt="Finally time for us to unfurl the sails ..." width="150"/>

## Building RHEL8 bastion VM to host PXE container
This step is only needed if you would like to build the bastion vm from scratch. At preset to build this VM you would need access to [Red Hat Subscription Keys](./secrets/RHSM.env.tmpl), [Red Hat Registry token](./secrets/registry.secret.tmpl), and [OpenShift pull secret](./secrets/ocp4.secret.tmpl).

>💡 __NOTE:__ You can define an enviornment variable `OS_ISO_DIR` that point [local clone of these file](https://files.caas.ford.com:9443/iso/) doing so substantially reduces the amount of time it take for this script to download various installation media.

```bash
# Build RHEL8 VM using ISO and local ephemeral webserver to serve KickStart file
./main.sh --build-bastion-server PATH-TO/rhel-8.0-x86_64-dvd.iso

# Stop the vm to unmount ISO
./main.sh --stop-vm bastion

# Disable VMware DHCP server
./main.sh --reset-network

# Disable VMware DHCP server
./main.sh --export-vm bastion
```

<!--
oc get csr
oc get csr -ojson | jq -r '.items[] | select(.status == {} ) | .metadata.name' | xargs oc adm certificate approve
sleep 3
oc get csr
-->

## Debugging

### Scale cluster
```bash
# https://github.com/code-ready/snc/blob/master/snc.sh#L156-L166

#export KUBECONFIG=$(pwd)/clusters/ocp4/auth/kubeconfig
export KUBECONFIG=/mnt/hgfs/share/clusters/ocp4/auth/kubeconfig

# Once it is finished, disable the CVO
oc scale --replicas=0 deployment --all -n openshift-cluster-version

# Disable the deployment/replicaset/statefulset config for openshift-monitoring namespace
oc scale --replicas=1 deployment --all -n openshift-monitoring
oc scale --replicas=1 statefulset --all -n openshift-monitoring

# Delete the pods which are there in Complete state
oc delete pods -l 'app in (installer, pruner)' -n openshift-kube-apiserver
oc delete pods -l 'app in (installer, pruner)' -n openshift-kube-scheduler
oc delete pods -l 'app in (installer, pruner)' -n openshift-kube-controller-manager

# Disable the deployment/replicaset for openshift-machine-api and openshift-machine-config-operator
oc scale --replicas=1 deployment --all -n openshift-machine-api
oc scale --replicas=1 deployment --all -n openshift-machine-config-operator

# Scale route deployment from 2 to 1
oc patch --patch='{"spec": {"replicas": 1}}' --type=merge ingresscontroller/default -n openshift-ingress-operator

# Set default route for registry CRD from false to true.
oc patch config.imageregistry.operator.openshift.io/cluster --patch '{"spec":{"defaultRoute":true}}' --type=merge

# Delete the v1beta1.metrics.k8s.io apiservice since we are already scale down cluster wide monitioring.
# Since this CRD block namespace deletion forever.
##oc delete apiservice v1beta1.metrics.k8s.io
```

### SSH into bastion
```bash
ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/bastion" \
    admin@bastion.ocp4.local

ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/bastion" \
    admin@bastion.ocp4.local \
    -t "sudo rm -rf /opt/pxe-server-files"
```

### Enumerate container images downloaded by bootstrap node
```bash
ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/core" \
    core@bootstrap.ocp4.local \
    -t "sudo podman images"
```

### Enumerate container images downloaded by master node
```bash
ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/core" \
    core@master-0.ocp4.local \
    -t "sudo podman images | wc -l"
```

### Enumerate container images downloaded by worker node
```bash
ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/core" \
    core@worker-0.ocp4.local \
    -t "sudo podman images"
```

### DHCP
```bash
ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/bastion" \
    admin@bastion.ocp4.local \
    -t "sudo podman exec adi bash -c 'cat /var/log/dhcpd.log'"
```

### DNS
```bash
# Service record
dig _etcd-server-ssl._tcp.ocp4.local SRV +short

# A record
dig api.ocp4.local +short
dig api-int.ocp4.local +short
dig console-openshift-console.apps.ocp4.local +short

# Reverse lookup
dig -x 172.17.5.20
```

### Verify TSL certificates
For details see this [Red Hat KB 4232821](https://access.redhat.com/solutions/4232821)
```bash
for crt in $(/usr/local/bin/jq '.storage.files[]? | select(.path | contains (".crt")) | .contents.source' /opt/pxe-server-files/nginx/www/dist/rhcos/ign/bootstrap.ign); do echo $crt | awk -F, '{ print $2 }' | base64 -d | openssl x509 -noout -text | grep -A 3 -i Validity; done
```

### How do I see what is happening with my UPI install.
For details see this [Red Hat KB 4139361](https://access.redhat.com/solutions/4139361)

### Gather installer logs
For details see this [Red Hat Doc](https://docs.openshift.com/container-platform/4.1/installing/installing-gather-logs.html)

```bash
# These command must be run inside PXE/Bastion VM

openshift-install \
    gather bootstrap \
    --dir=/mnt/hgfs/share/clusters/ocp4 \
    --bootstrap bootstrap.ocp4.local \
    --master "master-0.ocp4.local"
ssh -A core@bootstrap.ocp4.local '/usr/local/bin/installer-gather.sh master-0.ocp4.local'
scp core@bootstrap.ocp4.local:~/log-bundle.tar.gz .

export KUBECONFIG=/mnt/hgfs/share/clusters/ocp4/auth/kubeconfig

oc adm must-gather
```


<!--
## vmware
```
vmrun -T fusion addSharedFolder \
"./artifacts/vms/pxe.vmwarevm/pxe.vmx" \
"share" \
"$HOME/Projects/workspace/Containers/openshift4"
```
-->

## Know issues
- ~~RHCOS fails to boot under UEFI - [RH ticket# 02427026](https://access.redhat.com/support/cases/#/case/02427026)~~
- ~~OpenShift installer does not support installing Openshift v4.1.6 in a proxied environment, we do this [Pull Request 1832](https://github.com/openshift/installer/pull/1832) which is not yet made it to the official released version of installer.~~
- ~~OpenShift installer fails to install cluster - [RH ticket# 02431309](https://access.redhat.com/support/cases/#/case/02431309)~~

<!--
sudo launchctl unload $HOME/Projects/workspace/Containers/openshift4/artifacts/coredns/coredns.plist
sudo launchctl load $HOME/Projects/workspace/Containers/openshift4/artifacts/coredns/coredns.plist
-->

## Status
```
kubectl get events --field-selector type=Warning
kubectl get events --field-selector involvedObject.kind!=Pod
oc get events --field-selector involvedObject.kind=Node,involvedObject.name=master0.caas.ford.com
```

## Update DNS
```
#nmcli con show
#nmcli con mod <connectionName> ipv4.dns "8.8.8.8 8.8.4.4"

ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/bastion" \
    admin@bastion.ocp4.local \
    -t "sudo rm -rf /opt/pxe-server-files && \
        sudo nmcli con mod ens160 ipv4.dns \"$(ipconfig getifaddr en0)\" && \
        sudo cat /etc/sysconfig/network-scripts/ifcfg-ens160 && \
        sudo systemctl restart NetworkManager"
```

## Test iPXE container
```bash
podman run \
--name=adi --rm -it \
--entrypoint=/usr/bin/bash \
files.caas.ford.com/caas-infra/adi:1.0.0
```

## Clean up files
```
ssh -o LogLevel=FATAL -o Compression=yes \
    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="./artifacts/ssh/bastion" \
    admin@bastion.ocp4.local \
    -t "sudo rm -rf /opt/pxe-server-files && \
        sudo dnf remove -y --nodocs podman buildah skopeo && \
        sudo dnf install -y --nodocs podman buildah skopeo"
```

# FAQ's
- [OpenShift Container Platform Telemetry Collection](https://access.redhat.com/articles/4384491)
- [Troubleshooting OpenShift Container Platform 4.x: UPI Installation](https://access.redhat.com/articles/4292081)
- [How to add a CA as trusted in all nodes in OpenShift 4.1](https://access.redhat.com/solutions/4383961)
- [How to set hostnames in OCP 4.1?](https://access.redhat.com/solutions/4333421)
- [Deploying OpenShift 4.x on non-tested platforms using the bare metal install method](https://access.redhat.com/articles/4207611)
- [Enable debug loglevel for Authentication Operator in OpenShift Container Platform 4 Cluster](https://access.redhat.com/solutions/4100741)
- [Checking who can perform certain actions in OpenShift cluster](https://access.redhat.com/solutions/3294651)
- [Master KCS Article OpenShift Container Platform 4.x](https://access.redhat.com/articles/4217411)
- [How do I see what is happening with my UPI install](https://access.redhat.com/solutions/4139361)
- [How to shutdown all OpenShift hosts safely in OpenShift 4.1?](https://access.redhat.com/solutions/4218311)
- [Openshift 4 unable to update infra nodes](https://access.redhat.com/solutions/4342791)
- [Example Ignition Configs](https://coreos.com/ignition/docs/latest/examples.html#set-the-hostname)
- [How to configure the Image Registry to use user-created PVC in OpenShift 4.x?](https://access.redhat.com/solutions/4348211)
- [Node is Ignited but Does not Join Cluster](https://access.redhat.com/solutions/4335971)
- [Accessing the RHCOS Console](https://access.redhat.com/solutions/4307591)
- [OpenShift 4 Bare Metal control plane setup fails due to x509: certificate signed by unkonwn authority](https://access.redhat.com/solutions/4271572)


oc get clusteroperator