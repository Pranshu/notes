#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail
#IFS=$'\n\t' # Default the Internal Field Separator to newline and tab

export SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd )
export ARTIFACT_PATH="${SCRIPT_ROOT}/artifacts"
export BIN_PATH="${ARTIFACT_PATH}/bin"
export TEMPLATE_PATH="${SCRIPT_ROOT}/templates"
export PROVISION_SCRIPT_PATH="${SCRIPT_ROOT}/prov-scripts"
export VM_BASE_DIR="${ARTIFACT_PATH}/vms"
#export OPENSHIFT_DOMAIN='ocp4.local'

#export OPENSHIFT_INSTALLER_VERSION='4.1.11'
#export OPENSHIFT_MAJ_VERSION='4'
#export RHCOS_VERSION='4.1.0'
#export RHCOS_REAL_VERSION=${RHCOS_VERSION}
#export RHCOS_MAJ_MIN_VERION='4.1'

export OPENSHIFT_INSTALLER_VERSION="${OPENSHIFT_INSTALLER_VERSION:=4.2.0-0.nightly-2019-09-25-233506}"
export OPENSHIFT_MAJ_VERSION="${OPENSHIFT_MAJ_VERSION:=4}"
export RHCOS_VERSION="${RHCOS_VERSION:=4.2.0-0.nightly-2019-08-28-152644}"
export RHCOS_REAL_VERSION="${RHCOS_REAL_VERSION:=42.80.20190828.2}"
export RHCOS_MAJ_MIN_VERION="${RHCOS_MAJ_MIN_VERION:=4.2}"

export COREDNS_VER="${COREDNS_VER:=1.6.3}"
export JQ_VER="${JQ_VER:=1.6}"
export YQ_VER="${YQ_VER:=2.4.0}"
export OC_VER=${OPENSHIFT_INSTALLER_VERSION}
export GOMPLATE_VER="${GOMPLATE_VER:=3.5.0}"
export MKCERT_VER="${MKCERT_VER:=1.4.0}"

export OCP_TLD="${OCP_TLD:=local}"
export OCP_CLUSTER_NAME="${OCP_CLUSTER_NAME:=ocp4}"
export OCP_NUM_MASTER=${OCP_NUM_MASTER:=1}
export OCP_NUM_WORKER=${OCP_NUM_WORKER:=0}

#export HOST_IP=$(ipconfig getifaddr en0)
export HOST_IP=$(ifconfig "$(route -n get 0.0.0.0 2>/dev/null | awk '/interface: / {print $2}')" | grep "inet " | grep -v 127.0.0.1 | awk '{print $2}')
export HOST_CORE_COUNT=$(sysctl -n hw.ncpu)

export OS_ISO_DIR=${OS_ISO_DIR:=${HOME}/Projects/iso}
export PATH=$PATH:${ARTIFACT_PATH}/bin
export INVENTORY_FILE="${INVENTORY_FILE:-server-profiles.json}"
export ISO_ROOT_URL='https://files.caas.ford.com:9443/iso'
export IPXE_ROOT_URL="${IPXE_ROOT_URL:-http://boot.ipxe.org}"
export VM_REPO_URL='https://files.caas.ford.com:9443/ova/bastion.ova'

export HOSTONLY_VMNET_NUMBER='10'
export HOSTONLY_VMNET_SUBNET='172.17.5.0'
export HOSTONLY_VMNET_NETMASK='255.255.255.0'
export HOSTONLY_VMNET_PREFIX='24'
export HOSTONLY_VMNET_GATEWAY='172.17.5.2'

## DOCS: https://docs.openshift.com/container-platform/4.1/installing/installing_bare_metal/installing-bare-metal.html#installation-bare-metal-config-yaml_installing-bare-metal
export OPENSHIFT_SDN_PROVIDER="${OPENSHIFT_SDN_PROVIDER:=Calico}" #OpenShiftSDN
export OPENSHIFT_POD_CIDR='10.128.0.0/14'
export OPENSHIFT_SERVICE_CIDR='172.30.0.0/16'
export OPENSHIFT_HOSTPREFIX='23'

export DEFAULT_HTTP_PROXY='http://internet.ford.com:83'
export DEFAULT_NO_PROXY='localhost,127.0.0.1,.ford.com,.local,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16'
export DEFAULT_NAMESERVERS='19.106.96.250 19.106.100.250' #'136.2.17.20 136.2.33.20'

# Determine and set up variables needed for fancy color output (if supported).
V_BOLD_RED=
V_BOLD_GREEN=
V_BOLD_YELLOW=
V_BOLD_BLUE=
V_YELLOW=
V_REVERSE=
V_VIDOFF=

if tput colors >&/dev/null; then
  # order matters: we want VIDOFF last so that when we trace with `set -x`,
  # our terminal doesn't bleed colors as bash dumps the values of vars.
  V_BOLD_RED=$(tput bold; tput setaf 1)
  V_BOLD_GREEN=$(tput bold; tput setaf 2)
  V_BOLD_YELLOW=$(tput bold; tput setaf 3)
  V_BOLD_BLUE=$(tput bold; tput setaf 4)
  V_YELLOW=$(tput setaf 3)
  V_REVERSE=$(tput rev)
  V_VIDOFF=$(tput sgr0)
fi

export BASTION_VM_NAME='bastion'
export BASTION_VM_IP=$(jq --raw-output '.bastion.ip' ${SCRIPT_ROOT}/${INVENTORY_FILE})
export BASTION_VM_MAC=$(jq --raw-output '.bastion.mac' ${SCRIPT_ROOT}/${INVENTORY_FILE})
export BASTION_VM_SSHKEY="${ARTIFACT_PATH}/ssh/bastion"

export PATH=/usr/local/opt/ncurses/bin:/usr/local/opt/python/libexec/bin:$PATH

#export PATH=/usr/local/opt/gnu-getopt/bin:/usr/local/opt/gnu-sed/libexec/gnubin:/usr/local/opt/python/libexec/bin:/usr/local/opt/ncurses/bin:$PATH

# VMware Fusion
if [ -d "/Applications/VMware Fusion.app/Contents/Library" ]; then
	export PATH=$PATH:"/Applications/VMware Fusion.app/Contents/Library":"/Applications/VMware Fusion.app/Contents/Library/VMware OVF Tool"
else
	echo -e "${V_BOLD_RED}ERROR: Vmware Fusion is not installed${V_VIDOFF}"
	exit 1
fi

# Vmware fusion version
VMwareFusionVersion=$(defaults read /Applications/VMware\ Fusion.app/Contents/Info CFBundleShortVersionString | cut -c -2)

# Overcommit memory
# DOCS:
#	https://networkinferno.net/vmware-fusion-memory-overcommit
#	https://www.virtuallyghetto.com/2015/02/quick-tip-how-to-enable-memory-overcommitment-in-vmware-fusion.html
#	https://blog.filippo.io/mkcert-valid-https-certificates-for-localhost/
echo "prefvmx.minVmMemPct = 50" | sudo tee "/Library/Preferences/VMware Fusion/config" > /dev/null

# Init our own program name
program_name=$0

# Update existing sudo time stamp if set, otherwise do nothing.
while true; do sudo -n true; sleep 60; kill -0 "$$" || exit; done 2>/dev/null &

# MacOS ships BSD getopt, hence we need install following brew packages and get then in default PATH
# brew install gnu-sed --with-default-names
# brew install gnu-getopt
# brew install openssl
# brew install binutils
OS_PLATFORM="$(uname -s)"
case "${OS_PLATFORM}" in
	Darwin*)
		export PATH=$(brew --prefix bash):$(brew --prefix gnu-getopt)/bin:$(brew --prefix openssl)/bin:$(brew --prefix gnu-sed)/libexec/gnubin:$PATH;
		;;
	Linux*)
		break;
		;;
	*)
		break;
		;;
esac

set +e
HTTP_CODE=$( \
    curl \
    --head \
    --insecure \
    --location \
    --silent \
    --fail \
    --output /dev/null \
    --write-out "%{http_code}" \
    --connect-timeout 10 \
    --proxy ${DEFAULT_HTTP_PROXY} \
    https://google.com
)
if [ "$HTTP_CODE" = "200" ]; then
    export http_proxy="${DEFAULT_HTTP_PROXY}"
    export HTTP_PROXY="${DEFAULT_HTTP_PROXY}"
    export https_proxy="${DEFAULT_HTTP_PROXY}"
    export HTTPS_PROXY="${DEFAULT_HTTP_PROXY}"
    export no_proxy="${DEFAULT_NO_PROXY}"
    export NO_PROXY="${DEFAULT_NO_PROXY}"
else
    export http_proxy=""
    export HTTP_PROXY=""
    export https_proxy=""
    export HTTPS_PROXY=""
    export no_proxy=""
    export NO_PROXY=""
fi
set -e

mkdir -p ${ARTIFACT_PATH}/ssh \
	${ARTIFACT_PATH}/vms \
	${ARTIFACT_PATH}/logs \
	${BIN_PATH}

chmod 0600 ${ARTIFACT_PATH}/ssh/{bastion,core,test}

declare -A TOOLS=( \
	["https://github.com/coredns/coredns/releases/download/v${COREDNS_VER}/coredns_${COREDNS_VER}_darwin_amd64.tgz"]='coredns|coredns.tgz' \
	["https://github.com/stedolan/jq/releases/download/jq-${JQ_VER}/jq-osx-amd64"]='jq' \
	["https://github.com/mikefarah/yq/releases/download/${YQ_VER}/yq_darwin_amd64"]='yq' \
	["https://dl.min.io/client/mc/release/darwin-amd64/mc"]='mc' \
	["https://github.com/FiloSottile/mkcert/releases/download/v${MKCERT_VER}/mkcert-v${MKCERT_VER}-darwin-amd64"]='mkcert' \
	["https://mirror.openshift.com/pub/openshift-v4/clients/ocp-dev-preview/${OC_VER}/openshift-client-mac-${OC_VER}.tar.gz"]='oc|oc.tar.gz' \
	["https://github.com/hairyhenderson/gomplate/releases/download/v${GOMPLATE_VER}/gomplate_darwin-amd64"]='gomplate' \
	["https://github.com/spuranam/tools/releases/download/webserver/webserver"]='webserver'
)

for tool in "${!TOOLS[@]}"; do
	if [[ ${TOOLS[$tool]} =~ \| ]]; then
		tname=$(echo ${TOOLS[$tool]} | cut -d'|' -f1)
		tdlfile=${BIN_PATH}/$(echo ${TOOLS[$tool]} | cut -d'|' -f2)
	else
		tname=${TOOLS[$tool]}
		tdlfile=${BIN_PATH}/${tname}
	fi
	tpath=${BIN_PATH}/${tname}
	turl=${tool}

	if [ ! -f ${tpath} ]; then
		echo "Downloading ${TOOLS[$tool]} from ${tool} ..."
		curl \
			--connect-timeout 20 \
			--retry 5 \
			--retry-delay 0 \
			--retry-max-time 60 \
			--insecure \
			--progress-bar \
			--location \
			--output ${tdlfile} \
			${turl}
		chmod +x ${tdlfile}
		if [[ ${turl} =~ openshift-client-mac-${OC_VER}.tar.gz$ && ! -f ${BIN_PATH}/oc ]]; then
			#tar -xzf ${BIN_PATH}/oc.tar.gz -C ${BIN_PATH} --strip-components=1
			tar -xzf ${BIN_PATH}/oc.tar.gz -C ${BIN_PATH}
			chmod +x ${BIN_PATH}/oc ${BIN_PATH}/kubectl
			rm -rf ${BIN_PATH}/{oc.tar.gz,README.md}
		fi
		if [[ ${turl} =~ coredns_${COREDNS_VER}_darwin_amd64.tgz$ && ! -f ${BIN_PATH}/coredns ]]; then
			tar -xzf ${BIN_PATH}/coredns.tgz -C ${BIN_PATH}
			chmod +x ${BIN_PATH}/coredns
			rm -rf ${BIN_PATH}/coredns.tgz
		fi
	fi
done

## Make sure that INVENTORY_FILE file exists
if [ ! -f ${INVENTORY_FILE} ]; then
	echo -e "${V_BOLD_RED}Missing the server profile file ${INVENTORY_FILE}${V_VIDOFF}"
	exit 1;
fi

function usage {
	local ALL_ALLOWED_HOSTS=$(jq --raw-output 'keys | [ .[] | tostring ] | sort | join(" | ")' ${INVENTORY_FILE})

	cat <<-HEREDOC

	${V_BOLD_YELLOW}usage: $0 [-h|-b|-B|-p|-P|-c|-C|-s|-S|r|e]${V_VIDOFF}

	  -h|--help
	   Print this message

	  -b|--build-bastion-server <PATH-TO-RHEL8-ISO>
	  Build RHEL8 bastion server using ISO

	  -B|--build-container-image
	  Build container image for hosting PXE tooling

	  -p|--provision-bastion-server
	  Install required software packages in Bastion server

	  -P|--provision-container
	  Intall required softaware and configs to run PXE tooling container

	  -c|--start-containers
	  Start PXE tooling containers

	  -C|--stop-containers
	  Stop PXE tooling containers

	  -s|--start-vm <VM-NAME> [${ALL_ALLOWED_HOSTS}]
	  Start VM

	  -S|--stop-vm <VM-NAME> [${ALL_ALLOWED_HOSTS}]
	  Stop

	  -r|--reset-network
	  Disable DHCP support in hostonly network

	  -e|--export-vm <VM-NAME> [${ALL_ALLOWED_HOSTS}]
	  Export VM as OVA

	  -D|--delete-all
	  Delete all VM and supporting configs

	  -n|--start-dns
	  Start local DNS server

	  -N|--stop-dns
	  Stop local DNS server

	${V_BOLD_YELLOW}Example:${V_VIDOFF}

	  $0 -b $HOME/Projects/iso/rhel/rhel-8.0-x86_64-dvd.iso
	  $0 --build-bastion-server $HOME/Projects/iso/rhel/rhel-8.0-x86_64-dvd.iso

	HEREDOC
}

function provsion_ks() {
	if [ -d ${ARTIFACT_PATH}/kickstart ]; then
		rm -rf ${ARTIFACT_PATH}/kickstart
	fi
	mkdir -p ${ARTIFACT_PATH}/kickstart
	cp ${TEMPLATE_PATH}/kickstart/bastion.cfg ${ARTIFACT_PATH}/kickstart/bastion.cfg

	#delim=','
	#UPSTREAM_NAMESERVERS=''
	#readarray -t array <<< "$(scutil --dns | grep -m 2 'nameserver\[[0-9]*\]' | awk '{ print $3 }' | grep -v '127.0.0.1' | uniq )"
	#printf -v UPSTREAM_NAMESERVERS "%s$delim" "${array[@]}"    # yields one:two:three:
	#UPSTREAM_NAMESERVERS="${UPSTREAM_NAMESERVERS%$delim}"      # yields one:two_three
	#local NAMESERVER_NMCLI=$(echo ${UPSTREAM_NAMESERVERS} | sed "s~,~ ~g")

	## Generate SSH key
	mkdir -p ${ARTIFACT_PATH}/ssh
	if [ ! -f ${BASTION_VM_SSHKEY} ]; then
		ssh-keygen -t rsa -b 4096 -f ${BASTION_VM_SSHKEY} -N '' -C 'bastion server admin user' > /dev/null 2>&1
		#ssh-copy-id -i${BASTION_VM_SSHKEY}.pub admin@${BASTION_VM_IP}
	fi
	local ADMIN_SSH_PUBLIC_KEY=$(cat ${BASTION_VM_SSHKEY}.pub)
	sed -i "s~__ADMIN_SSH_PUBLIC_KEY__~${ADMIN_SSH_PUBLIC_KEY}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg

	## Generate a SHA512 root password hash
	## https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html-single/performing_an_advanced_rhel_installation/index
	## Install passlib using "sudo easy_install pip && sudo pip install passlib"
	#local ADMIN_PASSWORD=$(python -c 'from passlib.hash import sha512_crypt;print sha512_crypt.using(rounds=5000).hash("P@ssw0rd")')
	local ADMIN_PASSWORD=$(python -c 'import crypt; print(crypt.crypt("P@ssw0rd", crypt.mksalt(crypt.METHOD_SHA512)))')
	sed -i "s~__ADMIN_PASSWORD__~${ADMIN_PASSWORD}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg

	## Add RHSM creds to register this VM
	if [ -f "${SCRIPT_ROOT}/secrets/RHSM.env" ]; then
		. "${SCRIPT_ROOT}/secrets/RHSM.env"
		sed -i "s~__RHSM_ORG__~${RHSM_ORG}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
		sed -i "s~__RHSM_ACTIVATION_KEY__~${RHSM_ACTIVATION_KEY}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
	else
		echo -e "${V_BOLD_RED}ERROR: Missing Red Hat Subscription Management creds in "${SCRIPT_ROOT}/secrets/RHSM.env"${V_VIDOFF}"
		exit 1
	fi

	sed -i "s~__NAMESERVERS__~${HOST_IP}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
	sed -i "s~__GATEWAY__~${HOSTONLY_VMNET_GATEWAY}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
	sed -i "s~__IP__~${BASTION_VM_IP}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
	sed -i "s~__PREFIX__~${HOSTONLY_VMNET_PREFIX}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
	sed -i "s~__NETMASK__~${HOSTONLY_VMNET_NETMASK}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
	sed -i "s~__OPENSHIFT_DOMAIN__~${OCP_CLUSTER_NAME}.${OCP_TLD}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg
	sed -i "s~__IP_NETMASK__~${BASTION_VM_IP}/${HOSTONLY_VMNET_PREFIX}~g" ${ARTIFACT_PATH}/kickstart/bastion.cfg

	${ARTIFACT_PATH}/bin/webserver -d ${ARTIFACT_PATH}/kickstart &
}

function start_coredns() {
	if [ -d ${ARTIFACT_PATH}/coredns ]; then
		rm -rf ${ARTIFACT_PATH}/coredns
	fi
	mkdir -p ${ARTIFACT_PATH}/coredns/zones

	echo -e "${V_BOLD_YELLOW}Copying CoreDNS template${V_VIDOFF}"
	if [[ ${OCP_NUM_WORKER} -eq 0 ]]; then
		cp ${TEMPLATE_PATH}/coredns/zones/db.${OCP_CLUSTER_NAME}.${OCP_TLD}.aio ${ARTIFACT_PATH}/coredns/zones/db.${OCP_CLUSTER_NAME}.${OCP_TLD}
	else
		cp ${TEMPLATE_PATH}/coredns/zones/db.${OCP_CLUSTER_NAME}.${OCP_TLD} ${ARTIFACT_PATH}/coredns/zones/db.${OCP_CLUSTER_NAME}.${OCP_TLD}
	fi
	sed -i "s~__OPENSHIFT_DOMAIN__~${OCP_CLUSTER_NAME}.${OCP_TLD}~g" ${ARTIFACT_PATH}/coredns/zones/db.${OCP_CLUSTER_NAME}.${OCP_TLD}

	cp ${TEMPLATE_PATH}/coredns/zones/5.17.172.db ${ARTIFACT_PATH}/coredns/zones/5.17.172.db
	sed -i "s~__OPENSHIFT_DOMAIN__~${OCP_CLUSTER_NAME}.${OCP_TLD}~g" ${ARTIFACT_PATH}/coredns/zones/5.17.172.db

	echo -e "${V_BOLD_YELLOW}Generating CoreDNS plist file${V_VIDOFF}"
	cp ${TEMPLATE_PATH}/coredns/coredns.plist ${ARTIFACT_PATH}/coredns/coredns.plist
	sed -i "s~__ARTIFACT_PATH__~${ARTIFACT_PATH}~g" ${ARTIFACT_PATH}/coredns/coredns.plist
	#sed -i "s~__ARTIFACT_PATH__~${ARTIFACT_PATH}~g" ${ARTIFACT_PATH}/coredns/dnsconf.plist

	echo -e "${V_BOLD_YELLOW}Generating CoreDNS Corefile${V_VIDOFF}"
	export UPSTREAM_NAMESERVERS=""

	## https://gist.github.com/jjnilton/add1eeeb3a9616f53e4c
	#ipconfig getifaddr en0
	#ipconfig getoption en0 domain_name_server
	#scutil --dns | grep -m 2 'nameserver\[[0-9]*\]'  | awk '{ print  $3 }' | uniq
	#OLDIFS=$IFS
	#IFS='\n'
	#IFS=$OLDIFS
	#scutil --dns | grep -m 2 'nameserver\[[0-9]*\]' | awk '{ print $3 }' | uniq | while read -r line; do UPSTREAM_NAMESERVERS+="${line}:53 "; done || true
	#scutil --dns | grep -m 2 'nameserver\[[0-9]*\]' | awk '{ print $3 }' | uniq | while read -r line; do dns+=( "$line:53" ); done || true
	delim=' '
	readarray -t array <<< "$(scutil --dns | grep -m 2 'nameserver\[[0-9]*\]' | awk '{ print $3 }' | grep -v '127.0.0.1' | uniq )"
	printf -v UPSTREAM_NAMESERVERS "%s:53$delim" "${array[@]}" # yields one:two:three:
	UPSTREAM_NAMESERVERS="${UPSTREAM_NAMESERVERS%$delim}"      # yields one:two_three
	echo ${UPSTREAM_NAMESERVERS} | sed 's/:53//g' > ${ARTIFACT_PATH}/coredns/current
	cp ${TEMPLATE_PATH}/coredns/Corefile ${ARTIFACT_PATH}/coredns/Corefile
	sed -i "s~__ARTIFACT_PATH__~${ARTIFACT_PATH}~g" ${ARTIFACT_PATH}/coredns/Corefile
	sed -i "s~__UPSTREAM_NAMESERVERS__~${UPSTREAM_NAMESERVERS}~g" ${ARTIFACT_PATH}/coredns/Corefile
	sed -i "s~__OPENSHIFT_DOMAIN__~${OCP_CLUSTER_NAME}.${OCP_TLD}~g" ${ARTIFACT_PATH}/coredns/Corefile
	sed -i "s~__HOSTONLY_VMNET_SUBNET__~${HOSTONLY_VMNET_SUBNET}~g" ${ARTIFACT_PATH}/coredns/Corefile
	sed -i "s~__HOSTONLY_VMNET_PREFIX__~${HOSTONLY_VMNET_PREFIX}~g" ${ARTIFACT_PATH}/coredns/Corefile

	echo -e "${V_BOLD_YELLOW}Updating CoreDNS config file permissions${V_VIDOFF}"
	sudo chown root:wheel ${ARTIFACT_PATH}/coredns/coredns.plist
	sudo chmod o-w ${ARTIFACT_PATH}/coredns/coredns.plist
	#sudo chown root:wheel ${ARTIFACT_PATH}/coredns/dnsconf.plist
	#sudo chmod o-w ${ARTIFACT_PATH}/coredns/dnsconf.plist

	#echo -e "${V_BOLD_YELLOW}Updating local resolvers${V_VIDOFF}"
	#if [ ! -d /etc/resolver ]; then
	#	sudo mkdir -p /etc/resolver
	#fi
	#sudo tee /etc/resolver/${OCP_CLUSTER_NAME}.${OCP_TLD} > /dev/null <<-EOF
	#domain ${OCP_CLUSTER_NAME}.${OCP_TLD}
	#port 53
	#nameserver 127.0.0.1
	#search_order 1
	#EOF

	# https://github.com/anduintransaction/anduin-kube/blob/master/lib/common.sh#L91
	# https://github.com/dentsu-aegis/getting-started/blob/master/OSX/OSX.sh#L299
	# https://github.com/nacos-group/nacos-coredns-plugin/tree/master
	# https://github.com/snaproute-mino/user-tools/blob/master/virtualization/provision-vm-cluster.sh

	echo -e "${V_BOLD_YELLOW}Starting CoreDNS service${V_VIDOFF}"
	sudo launchctl unload ${ARTIFACT_PATH}/coredns/coredns.plist > /dev/null 2>&1 || true
	sudo launchctl load ${ARTIFACT_PATH}/coredns/coredns.plist || :

	#echo -e "${V_BOLD_YELLOW}Flushing local DNS cache${V_VIDOFF}"
	#sudo launchctl unload /System/Library/LaunchDaemons/com.apple.mDNSResponder.plist
	#sudo defaults write /Library/Preferences/com.apple.mDNSResponder.plist StrictUnicastOrdering -bool YES
	#sudo launchctl load /System/Library/LaunchDaemons/com.apple.mDNSResponder.plist

	set +e
	#echo -e "${V_BOLD_YELLOW}Pointing your dns servers to the newly created coredns server${V_VIDOFF}"
	#wired=$(networksetup -listnetworkserviceorder | grep en1 | awk -F : '{print $2}' | awk -F , '{print $1}' | sed -e 's/ //1')
	#if [ ! -z ${wired} ]; then
	#	networksetup -setdnsservers "${wired}" 127.0.0.1
	#fi
	#wireless=$(networksetup -listnetworkserviceorder | grep en0 | awk -F : '{print $2}' | awk -F , '{print $1}' | sed -e 's/ //1')
	#if [ ! -z ${wireless} ]; then
	#	networksetup -setdnsservers "${wireless}" 127.0.0.1
	#fi

	networksetup -listallnetworkservices | grep -v '\*' | while read line; do
		currentNS=$(networksetup -getdnsservers "$line")
		if [[ $currentNS == There* ]]; then
			currentNS=$(cat ${ARTIFACT_PATH}/coredns/current | head -n 1)
		fi
		if [[ $currentNS != *127.0.0.1* ]]; then
			currentNS="127.0.0.1 $(cat ${ARTIFACT_PATH}/coredns/current | head -n 1)"
			networksetup -setdnsservers "$line" $currentNS
		fi
	done
	set -e

	echo -e "${V_BOLD_YELLOW}Flushing local DNS cache${V_VIDOFF}"
	sudo killall -HUP mDNSResponder > /dev/null 2>&1 || true
	sudo killall mDNSResponderHelper > /dev/null 2>&1 || true
	sudo dscacheutil -flushcache > /dev/null 2>&1 || true

	# Ref: https://github.com/jnewsome/stemdns/blob/master/dig.sh
	# Test if the DNS resolution is woriking
	local test_ip=$(dig @localhost bastion.ocp4.local +short)
	if [ "${test_ip}" != "${BASTION_VM_IP}" ]; then
		echo -e "${V_BOLD_RED}DNS resolver is not setup properly..${V_VIDOFF}"
		exit 1
	fi
}

function stop_coredns() {
	if [ -f /etc/resolver/${OCP_CLUSTER_NAME}.${OCP_TLD} ]; then
		sudo rm /etc/resolver/${OCP_CLUSTER_NAME}.${OCP_TLD}
	fi

	echo -e "${V_BOLD_YELLOW}Stopping CoreDNS service${V_VIDOFF}"
	sudo launchctl unload ${ARTIFACT_PATH}/coredns/coredns.plist > /dev/null 2>&1 || true
	#sudo launchctl unload ${ARTIFACT_PATH}/coredns/coredns.plist > /dev/null 2>&1 || true

	set +e
	#echo -e "${V_BOLD_YELLOW}Pointing your dns servers to canonical upstream${V_VIDOFF}"
	#DNS_SERVER=$(cat ${ARTIFACT_PATH}/coredns/current | head -n 1)
	#wired=$(networksetup -listnetworkserviceorder | grep en1 | awk -F : '{print $2}' | awk -F , '{print $1}' | sed -e 's/ //1')
	#if [ ! -z ${wired} ]; then
	#	networksetup -setdnsservers "${wired}" ${DNS_SERVER}
	#fi
	#wireless=$(networksetup -listnetworkserviceorder | grep en0 | awk -F : '{print $2}' | awk -F , '{print $1}' | sed -e 's/ //1')
	#if [ ! -z ${wireless} ]; then
	#	networksetup -setdnsservers "${wireless}" ${DNS_SERVER}
	#fi

	if [ ! -z "${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}" ]; then
		DNS_SERVER=${DEFAULT_NAMESERVERS}
	fi

	networksetup -listallnetworkservices | grep -v '\*' | while read line; do
		currentNS=$(networksetup -getdnsservers "$line")
		if [[ $currentNS != There* ]] || [[ $currentNS == *127.0.0.1* ]]; then
			currentNS=$(echo $currentNS | sed 's/127.0.0.1//g' | sed 's/\s*//')
			#networksetup -setdnsservers "$line" $currentNS
			networksetup -setdnsservers "$line" empty
		fi
		#networksetup -setdnsservers "$line" $currentNS
	done
	set -e

	echo -e "${V_BOLD_YELLOW}Flushing local DNS cache${V_VIDOFF}"
	sudo killall -HUP mDNSResponder > /dev/null 2>&1 || true
	sudo killall mDNSResponderHelper > /dev/null 2>&1 || true
	sudo dscacheutil -flushcache > /dev/null 2>&1 || true

	if [ -d ${ARTIFACT_PATH}/coredns ]; then
		rm -rf ${ARTIFACT_PATH}/coredns
	fi
}

function create_hostonly_network() {
	## Add network
	if [ ! -d "/Library/Preferences/VMware Fusion/vmnet${HOSTONLY_VMNET_NUMBER}" ]; then
		set +e
		echo -e "${V_BOLD_YELLOW}Creating HostOnly network vmnet${HOSTONLY_VMNET_NUMBER}${V_VIDOFF}"
		sudo vmnet-cfgcli vnetcfgadd VNET_${HOSTONLY_VMNET_NUMBER}_DHCP no > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgadd VNET_${HOSTONLY_VMNET_NUMBER}_HOSTONLY_SUBNET ${HOSTONLY_VMNET_SUBNET} > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgadd VNET_${HOSTONLY_VMNET_NUMBER}_HOSTONLY_NETMASK ${HOSTONLY_VMNET_NETMASK} > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgadd VNET_${HOSTONLY_VMNET_NUMBER}_VIRTUAL_ADAPTER yes > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgadd VNET_${HOSTONLY_VMNET_NUMBER}_NAT yes > /dev/null 2>&1
		sudo vmnet-cli --configure > /dev/null 2>&1
		sudo vmnet-cli --stop > /dev/null 2>&1
		sudo vmnet-cli --start > /dev/null 2>&1
		set -e
	fi
}

function enable_hostonly_dhcp() {
	echo -e "${V_BOLD_YELLOW}Enable DHCP support in HostOnly network vmnet${HOSTONLY_VMNET_NUMBER}${V_VIDOFF}"
	set +e
	sudo vmnet-cfgcli vnetcfgadd VNET_${HOSTONLY_VMNET_NUMBER}_DHCP yes > /dev/null 2>&1
	sudo vmnet-cli --configure > /dev/null 2>&1
	sudo vmnet-cli --stop > /dev/null 2>&1
	sudo vmnet-cli --start > /dev/null 2>&1

	# reserve a static IP for PXE server
	sudo tee -a "/Library/Preferences/VMware Fusion/vmnet${HOSTONLY_VMNET_NUMBER}/dhcpd.conf"  <<-EOF
	host ${BASTION_VM_NAME} {
		hardware ethernet ${BASTION_VM_MAC};
		fixed-address ${BASTION_VM_IP};
	}
	EOF

	sudo vmnet-cli --configure > /dev/null 2>&1
	sudo vmnet-cli --stop > /dev/null 2>&1
	sudo vmnet-cli --start > /dev/null 2>&1
	set -e
}

function disable_hostonly_dhcp() {
	set +e
	echo -e "${V_BOLD_YELLOW}Disable DHCP support in HostOnly network vmnet${HOSTONLY_VMNET_NUMBER}${V_VIDOFF}"
	sudo vmnet-cfgcli vnetcfgadd VNET_${HOSTONLY_VMNET_NUMBER}_DHCP no > /dev/null 2>&1
	sudo vmnet-cli --configure > /dev/null 2>&1
	sudo vmnet-cli --stop > /dev/null 2>&1
	sudo vmnet-cli --start > /dev/null 2>&1
	set -e
}

function remove_hostonly_network() {
	## Add network
	if [ -d "/Library/Preferences/VMware Fusion/vmnet${HOSTONLY_VMNET_NUMBER}" ]; then
		set +e
		echo -e "${V_BOLD_YELLOW}Removing HostOnly network vmnet${HOSTONLY_VMNET_NUMBER}${V_VIDOFF}"
		sudo vmnet-cfgcli vnetcfgremove VNET_${HOSTONLY_VMNET_NUMBER}_DHCP > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgremove VNET_${HOSTONLY_VMNET_NUMBER}_HOSTONLY_SUBNET > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgremove VNET_${HOSTONLY_VMNET_NUMBER}_HOSTONLY_NETMASK > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgremove VNET_${HOSTONLY_VMNET_NUMBER}_VIRTUAL_ADAPTER > /dev/null 2>&1
		sudo vmnet-cfgcli vnetcfgremove VNET_${HOSTONLY_VMNET_NUMBER}_NAT > /dev/null 2>&1
		sudo vmnet-cli --configure > /dev/null 2>&1
		sudo vmnet-cli --stop > /dev/null 2>&1
		sudo vmnet-cli --start > /dev/null 2>&1
		set -e
	fi
}

function create_vm_infra() {
	if ! sudo launchctl list | grep -E -q '\d+\s+0\s+localdev.coredns'; then
		start_coredns
	fi
	# sudo vmnet-cfgcli getdhcpparam vmnet8 defleasetime
	# sudo vmnet-cfgcli vnetcfgget VNET_10_DHCP
	if sudo vmnet-cfgcli vnetcfgget VNET_${HOSTONLY_VMNET_NUMBER}_DHCP | head -n 2 | tail -n 1 | grep -q 'No answer'; then
		create_hostonly_network
	fi
}

function delete_vm_infra() {
	stop_coredns
	remove_hostonly_network
}

function create_vm() {
	local VMNAME=$1
	local vm_disk_size=$2
	local nic0_mac=$3
	local nic0_net=$4
	local firmware=$5

	local vm_dir="${VM_BASE_DIR}/${VMNAME}.vmwarevm"

	local vm_vmx_file="${VMNAME}.vmx"
	local vm_vmx_path="${vm_dir}/${vm_vmx_file}"

	local vm_vmdk_file="${VMNAME}.vmdk"
	local vm_vmdk_path="${vm_dir}/${vm_vmdk_file}"

	#$HOME/Documents/Virtual Machines.localized/${VMNAME}.vmwarevm/${VMNAME}.vmx
	echo -e "${V_BOLD_YELLOW}Creating VM in ${vm_dir}${V_VIDOFF}"
	mkdir -p ${vm_dir}

	# https://www.vmware.com/support/ws45/doc/disks_vdiskmanager_eg_ws.html
	set +e
	echo -e "${V_BOLD_YELLOW}Creating VM disk in ${vm_vmdk_path}${V_VIDOFF}"
	if [ -f "${vm_vmdk_path}" ]; then
		rm -rf "${vm_vmdk_path}"
	fi
	vmware-vdiskmanager -c -s "${vm_disk_size}GB" -a lsilogic -t 0 "${vm_vmdk_path}"
	set -e

	## https://github.com/vmware/govmomi/blob/master/scripts/vcsa/create-esxi-vm.sh#L114
	## https://github.com/OpenSLX/mltk/blob/master/core/modules/vmware-common/data/opt/openslx/vmchooser/plugins/vmware/includes/write_final_vmx.inc
	#	nvram = "${VMNAME}.nvram"
	#	ethernet0.connectionType = "nat"
	#	extendedConfigFile = "${VMNAME}.vmxf"
	#	mks.enable3d = "TRUE"
	#	ethernet0.wakeOnPcktRcv = "FALSE"
	#	ethernet0.linkStatePropagation.enable = "TRUE"
	echo -e "${V_BOLD_YELLOW}Creating VMX in ${vm_vmx_path}${V_VIDOFF}"
	cat > "${vm_vmx_path}" <<-EOF
	.encoding = "UTF-8"
	config.version = "8"
	virtualHW.version = "13"
	pciBridge0.present = "TRUE"
	pciBridge4.present = "TRUE"
	pciBridge4.virtualDev = "pcieRootPort"
	pciBridge4.functions = "8"
	pciBridge5.present = "TRUE"
	pciBridge5.virtualDev = "pcieRootPort"
	pciBridge5.functions = "8"
	pciBridge6.present = "TRUE"
	pciBridge6.virtualDev = "pcieRootPort"
	pciBridge6.functions = "8"
	pciBridge7.present = "TRUE"
	pciBridge7.virtualDev = "pcieRootPort"
	pciBridge7.functions = "8"
	vmci0.present = "TRUE"
	hpet0.present = "TRUE"
	usb.vbluetooth.startConnected = "FALSE"
	displayName = "${VMNAME}"
	guestOS = "rhel8-64"
	nvram = "${VMNAME}.nvram"
	virtualHW.productCompatibility = "hosted"
	powerType.powerOff = "soft"
	powerType.powerOn = "soft"
	powerType.suspend = "soft"
	powerType.reset = "soft"
	# https://communities.vmware.com/thread/396766
	# https://communities.vmware.com/thread/3110
	rtc.diffFromUTC = 0
	tools.syncTime = "FALSE"
	#time.synchronize.continue = "FALSE"
	#time.synchronize.restore = "FALSE"
	#time.synchronize.resume.disk = "FALSE"
	#time.synchronize.shrink = "FALSE"
	#time.synchronize.tools.startup = "FALSE"
	#time.synchronize.tools.enable = "FALSE"
	#time.synchronize.resume.host = "FALSE"
	#tools.upgrade.policy = "upgradeAtPowerCycle"
	tools.upgrade.policy = "manual"
	sound.autoDetect = "TRUE"
	sound.startConnected = "FALSE"
	sound.fileName = "-1"
	sata0.present = "TRUE"
	sata0:0.fileName = "${vm_vmdk_file}"
	nvme0.present = "TRUE"
	nvme0:0.fileName = "${vm_vmdk_file}"
	svga.graphicsMemoryKB = "786432"
	ethernet0.address = "${nic0_mac}"
	ethernet0.present = "TRUE"
	ethernet0.connectionType = "custom"
	ethernet0.addressType = "static"
	#ethernet0.addressType = "generated"
	ethernet0.virtualDev = "vmxnet3"
	ethernet0.vnet = "${nic0_net}"
	serial0.fileType = "thinprint"
	serial0.fileName = "thinprint"
	#serial0.present = "TRUE"
	#serial0.fileType = "network"
	#serial0.fileName = "telnet://127.0.0.1:10000"
	serial0.startConnected = "FALSE"
	ehci:0.parent = "-1"
	ehci:0.port = "0"
	ehci:0.deviceType = "video"
	floppy0.present = "FALSE"
	scsi0.virtualDev = "lsilogic"
	#scsi0.virtualDev = "pvscsi"
	scsi0.present = "TRUE"
	scsi0:0.fileName = "${vm_vmdk_file}"
	scsi0:0.present = "TRUE"
	#gui.fitGuestUsingNativeDisplayResolution = "FALSE"
	#gui.perVMWindowAutofitMode = "stretch"
	#gui.perVMFullscreenAutofitMode = "stretch"
	gui.fitGuestUsingNativeDisplayResolution = "FALSE"
	gui.perVMWindowAutofitMode = "useAppPref"
	gui.perVMFullscreenAutofitMode = "useAppPref"
	firmware = "${firmware}"
	#extendedConfigFile = "${VMNAME}.vmxf"
	vcpu.hotadd = "TRUE"
	mem.hotadd = "TRUE"
	vhv.enable = "TRUE"
	#vvtd.enable = "TRUE"
	isolation.tools.hgfs.disable = "FALSE"
	isolation.tools.dnd.disable = "TRUE"
	isolation.tools.copy.enable = "TRUE"
	isolation.tools.paste.enabled = "TRUE"

	#sched.mem.pshare.enable = "FALSE"
	#monitor.virtual_mmu = "hardware"
	#monitor.virtual_exec = "hardware"

	#Boot order
	#bios.bootOrder = "ethernet0"
	#bios.bootOrder = "HDD"
	EOF

	# Hack resolution if we know the desired one is not in the default list of vmx_svga
	# For now, only do it on the odd ones, as we don't know if this has any side effects
	RESOLUTION=1600x900
	X=${RESOLUTION%x*}
	Y=${RESOLUTION#*x}
	BYTES=$(( ( ( X * Y * 4  + 65535 ) / 65536 ) * 65536 ))
	[ "$BYTES" -lt 16777216 ] && BYTES=16777216
	cat >> "${VM_VMX_PATH}" <<-EOF
	svga.autodetect = "FALSE"
	svga.vramSize = $BYTES
	svga.maxWidth = $X
	svga.maxHeight = $Y
	EOF
}

function build_bastion_server() {
	iso_path=$1

	local VM_CORES_PER_SOCKET='1'
	local VM_NET="vmnet${HOSTONLY_VMNET_NUMBER}"
	local VM_VMX_PATH="${VM_BASE_DIR}/${BASTION_VM_NAME}.vmwarevm/${BASTION_VM_NAME}.vmx"
	local VM_DISK_SIZE=$(jq --raw-output '.bastion.disk' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_CPU_CORE=$(jq --raw-output '.bastion.cpu' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_MEMORY=$(jq --raw-output '.bastion.memory' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_NET0_MAC=$(jq --raw-output '.bastion.mac' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_FIRMWARE=$(jq --raw-output '.bastion.firmware' ${SCRIPT_ROOT}/${INVENTORY_FILE})

	#"/Users/spuranam/Projects/iso/rhel/rhel-8.0-x86_64-dvd.iso"
	create_vm ${BASTION_VM_NAME} ${VM_DISK_SIZE} ${VM_NET0_MAC} ${VM_NET} ${VM_FIRMWARE}

	## Ref: https://github.com/OpenSLX/mltk/blob/master/core/modules/vmware-common/data/opt/openslx/vmchooser/plugins/vmware/includes/write_final_vmx.inc

	## attach ISO to VM
	if [ -f ${iso_path} ]; then
		cat >> "${VM_VMX_PATH}" <<-HEREEND
		sata0:1.deviceType = "cdrom-image"
		sata0:1.fileName = ${iso_path}
		sata0:1.present = "TRUE"
		HEREEND
	fi

	cat >> "${VM_VMX_PATH}" <<-HEREEND
	numvcpus = "$VM_CPU_CORE"
	memsize = "${VM_MEMORY}"

	HEREEND

	start_vm "${BASTION_VM_NAME}" "gui"
}

function provision_bastion_server() {
	local vmx="${VM_BASE_DIR}/${BASTION_VM_NAME}.vmwarevm/${BASTION_VM_NAME}.vmx"
	local host_shared_folder="${SCRIPT_ROOT}"
	#local shared_name="${SCRIPT_ROOT##*/}"
	#local vm_share_folder="/mnt/hgfs/${shared_name}"
	local shared_name="share"
	local vm_share_folder="/mnt/hgfs/${shared_name}"

	## Make project root folder avilable inside the VM
	vmrun -T fusion enableSharedFolders "${vmx}" runtime > /dev/null 2>&1 || true
	vmrun -T fusion addSharedFolder "${vmx}" "$shared_name" "$host_shared_folder" > /dev/null 2>&1 || true

	## Execute provsioning script
	if [ ! -f ${BASTION_VM_SSHKEY} ]; then
		echo -e "${V_BOLD_RED}ERROR: Missing SSH Private key '${BASTION_VM_SSHKEY}' ${V_VIDOFF}"
		exit 1
	fi
	ssh -o LogLevel=FATAL -o Compression=yes \
		-o DSAAuthentication=yes -o IdentitiesOnly=yes \
		-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
		-o IdentityFile="${BASTION_VM_SSHKEY}" \
		admin@${BASTION_VM_IP} \
		-t "sudo DEFAULT_DNS_SERVER=${HOST_IP} \
			INVENTORY_FILE=${INVENTORY_FILE} \
			ISO_ROOT_URL=${ISO_ROOT_URL} \
			OCP_TLD=${OCP_TLD} \
			OCP_CLUSTER_NAME=${OCP_CLUSTER_NAME} \
			${vm_share_folder}/prov-scripts/bastion-server.sh 2>&1 | \
			stdbuf -i0 -o0 -e0 tee ${vm_share_folder}/artifacts/logs/prov.log"

	vmrun -T fusion removeSharedFolder ${vmx} ${shared_name}
}

function build_container_image() {
	local vmx="${VM_BASE_DIR}/${BASTION_VM_NAME}.vmwarevm/${BASTION_VM_NAME}.vmx"
	local host_shared_folder="${SCRIPT_ROOT}"
	local shared_name="share"
	local vm_share_folder="/mnt/hgfs/${shared_name}"

	## Make project root folder avilable inside the VM
	vmrun -T fusion enableSharedFolders "${vmx}" runtime > /dev/null 2>&1 || true
	vmrun -T fusion addSharedFolder "${vmx}" "$shared_name" "$host_shared_folder" > /dev/null 2>&1 || true

	## Execute provsioning script
	if [ ! -f ${BASTION_VM_SSHKEY} ]; then
		echo -e "${V_BOLD_RED}ERROR: Missing SSH Private key '${BASTION_VM_SSHKEY}' ${V_VIDOFF}"
		exit 1
	fi

	# Build container image for "adi"
	ssh -o LogLevel=FATAL -o Compression=yes \
		-o DSAAuthentication=yes -o IdentitiesOnly=yes \
		-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
		-o IdentityFile="${BASTION_VM_SSHKEY}" \
		admin@${BASTION_VM_IP} \
		-t "sudo DEFAULT_DNS_SERVER=${HOST_IP} \
			INVENTORY_FILE=${INVENTORY_FILE} \
			${vm_share_folder}/container-images/adi/build-image.sh 2>&1 | \
			stdbuf -i0 -o0 -e0 tee ${vm_share_folder}/artifacts/logs/container-build.log"

	## Build container image for "haproxy"
	#ssh -o LogLevel=FATAL -o Compression=yes \
	#    -o DSAAuthentication=yes -o IdentitiesOnly=yes \
	#    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
	#    -o IdentityFile="${BASTION_VM_SSHKEY}" \
	#    admin@${BASTION_VM_IP} \
	#    -t "sudo ${vm_share_folder}/container-images/haproxy/build-image.sh 2>&1 | \
	#        stdbuf -i0 -o0 -e0 tee -a ${vm_share_folder}/artifacts/logs/container-build.log"

	## Remove shared folder
	vmrun -T fusion removeSharedFolder ${vmx} ${shared_name}
}

function provision_container(){
	local vmx="${VM_BASE_DIR}/${BASTION_VM_NAME}.vmwarevm/${BASTION_VM_NAME}.vmx"
	local host_shared_folder="${SCRIPT_ROOT}"
	local shared_name="share"
	local vm_share_folder="/mnt/hgfs/share"

	## Make project root folder avilable inside the VM
	vmrun -T fusion enableSharedFolders "${vmx}" runtime > /dev/null 2>&1 || true
	vmrun -T fusion addSharedFolder "${vmx}" "$shared_name" "$host_shared_folder" > /dev/null 2>&1 || true

	#suffix="${dir##*/}"
	#prefix="${dir#*/}"

	set +e
	if [ ! -z ${OS_ISO_DIR} ] && [ -d ${OS_ISO_DIR} ]; then
		vmrun -T fusion addSharedFolder "${vmx}" "iso" "${OS_ISO_DIR}" > /dev/null 2>&1 || true
	fi
	set -e

	if [ ! -f ${BASTION_VM_SSHKEY} ]; then
		echo -e "${V_BOLD_RED}ERROR: Missing SSH Private key '${BASTION_VM_SSHKEY}' ${V_VIDOFF}"
		exit 1
	fi
	ssh -o LogLevel=FATAL -o Compression=yes \
		-o DSAAuthentication=yes -o IdentitiesOnly=yes \
		-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
		-o IdentityFile="${BASTION_VM_SSHKEY}" \
		admin@${BASTION_VM_IP} \
		-t "sudo DEFAULT_DNS_SERVER=${HOST_IP} \
			OPENSHIFT_DOMAIN=${OCP_CLUSTER_NAME}.${OCP_TLD} \
			OCP_TLD=${OCP_TLD} \
			OCP_CLUSTER_NAME=${OCP_CLUSTER_NAME} \
			OCP_NUM_MASTER=${OCP_NUM_MASTER} \
			OCP_NUM_WORKER=${OCP_NUM_WORKER} \
			INVENTORY_FILE=${INVENTORY_FILE} \
			ISO_ROOT_URL=${ISO_ROOT_URL} \
			IPXE_ROOT_URL=${IPXE_ROOT_URL} \
			OPENSHIFT_INSTALLER_VERSION=${OPENSHIFT_INSTALLER_VERSION} \
			RHCOS_VERSION=${RHCOS_VERSION} \
			RHCOS_REAL_VERSION=${RHCOS_REAL_VERSION} \
			RHCOS_MAJ_MIN_VERION=${RHCOS_MAJ_MIN_VERION} \
			OPENSHIFT_MAJ_VERSION=${OPENSHIFT_MAJ_VERSION} \
			OPENSHIFT_SDN_PROVIDER=${OPENSHIFT_SDN_PROVIDER} \
			OPENSHIFT_POD_CIDR=${OPENSHIFT_POD_CIDR} \
			OPENSHIFT_SERVICE_CIDR=${OPENSHIFT_SERVICE_CIDR} \
			OPENSHIFT_HOSTPREFIX=${OPENSHIFT_HOSTPREFIX} \
			HOST_IP=${HOST_IP} \
			${vm_share_folder}/prov-scripts/provision-pxe-container.sh 2>&1 | \
			stdbuf -i0 -o0 -e0 tee -a ${vm_share_folder}/artifacts/logs/prov_container.log"
}

function start_containers(){
	local vm="${VM_BASE_DIR}/${BASTION_VM_NAME}.vmwarevm/${BASTION_VM_NAME}.vmx"
	local host_shared_folder="${SCRIPT_ROOT}"
	local shared_name="share"
	local vm_share_folder="/mnt/hgfs/share"

	## Make project root folder avilable inside the VM
	vmrun -T fusion enableSharedFolders "${vm}" runtime > /dev/null 2>&1 || true
	vmrun -T fusion addSharedFolder "${vm}" "$shared_name" "$host_shared_folder" > /dev/null 2>&1 || true

	#suffix="${dir##*/}"
	#prefix="${dir#*/}"

	if [ ! -f ${BASTION_VM_SSHKEY} ]; then
		echo -e "${V_BOLD_RED}ERROR: Missing SSH Private key '${BASTION_VM_SSHKEY}' ${V_VIDOFF}"
		exit 1
	fi
	ssh -o LogLevel=FATAL -o Compression=yes \
		-o DSAAuthentication=yes -o IdentitiesOnly=yes \
		-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
		-o IdentityFile="${BASTION_VM_SSHKEY}" \
		admin@${BASTION_VM_IP} \
		-t "sudo ${vm_share_folder}/prov-scripts/start-pxe-container.sh 2>&1 | \
			stdbuf -i0 -o0 -e0 tee -a ${vm_share_folder}/artifacts/logs/container.log"
}

function stop_containers() {
	local vm="${VM_BASE_DIR}/${BASTION_VM_NAME}.vmwarevm/${BASTION_VM_NAME}.vmx"

	if [ ! -f ${BASTION_VM_SSHKEY} ]; then
		echo -e "${V_BOLD_RED}ERROR: Missing SSH Private key '${BASTION_VM_SSHKEY}' ${V_VIDOFF}"
		exit 1
	fi
	ssh -o LogLevel=FATAL -o Compression=yes \
		-o DSAAuthentication=yes -o IdentitiesOnly=yes \
		-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
		-o IdentityFile="${BASTION_VM_SSHKEY}" \
		admin@${BASTION_VM_IP} \
		-t "echo 'Stopping all containers' && \
			sudo podman stop -a && sudo podman rm -a"
}

function download_vm() {
	local vm=$1

	if [ ! -d "${VM_BASE_DIR}/${vm}.vmwarevm" ]; then
		if [ ! -f ${VM_BASE_DIR}/${vm}.ova ]; then
			echo "Downloading VM ${vm} from ${VM_REPO_URL}"
			curl \
				--connect-timeout 20 \
				--retry 5 \
				--retry-delay 0 \
				--retry-max-time 60 \
				--insecure \
				--progress-bar \
				--location \
				--output ${VM_BASE_DIR}/${vm}.ova \
				${VM_REPO_URL}
		fi
	fi
}

function start_vm() {
	local vm=$1
	local vmx="${VM_BASE_DIR}/${vm}.vmwarevm/${vm}.vmx"

	local host_shared_folder="${SCRIPT_ROOT}"
	local shared_name="share"
	local vm_share_folder="/mnt/hgfs/share"

	## Create Hostonly network and Start CoreDNS
	create_vm_infra

	if ! vmrun -T fusion list | grep -v "Total running VMs" | awk -F/ '{print $(NF -1)}' | grep -q "${vm}.vmwarevm"; then
		# Download vm image if its missing
		if [ "${vm}" = "bastion" ] && [ ! -f "${vmx}" ]; then
			download_vm "bastion"
			mkdir -p ${VM_BASE_DIR}/${vm}.vmwarevm
			ovftool ${VM_BASE_DIR}/${vm}.ova ${vmx}

			if grep --quiet -e 'ethernet0.addressType = "generated"' ${vmx}; then
				sed -Ei "/^ethernet0.addressType.*$/d" ${vmx}
				sed -Ei "/^ethernet0.connectionType.*$/d" ${vmx}
				echo "ethernet0.addressType = \"static\"" >> ${vmx}
				echo "ethernet0.address = \"00:50:56:2B:B7:10\"" >> ${vmx}
				echo "ethernet0.connectionType = \"custom\"" >> ${vmx}
				echo "ethernet0.vnet = \"vmnet${HOSTONLY_VMNET_NUMBER}\"" >> ${vmx}
			fi
		fi

		##vmrun writeVariable seems easy, but you can't change the name if it's powered off, so sed to the rescue
		#vmrun -T fusion writeVariable ${vmx} runtimeConfig ethernet0.vnet vmnet${HOSTONLY_VMNET_NUMBER}

		# jq -r 'keys | [ .[] | tostring ] | @csv' ${INVENTORY_FILE}
		# jq -r 'keys | [ .[] | tostring ] | join("|")' ${INVENTORY_FILE}
		# jq -r 'del(.bastion ) | keys | [ .[] | tostring ] | join("|")' ${INVENTORY_FILE}

		## Generate the VMX file and virtual disk for this VM
		VM_LIST=$(jq -r 'keys | [ .[] | tostring ] | join("|")' ${SCRIPT_ROOT}/${INVENTORY_FILE})
		if [[ ${vm} =~ ^(${VM_LIST})$ ]]; then
			if [ ! -f "${vmx}" ]; then
				build_vm ${vm}
			fi
		fi

		if [ ! -f "${vmx}" ]; then
			echo -e "${V_BOLD_RED}ERROR: Missing VMX file for the VM ${vm} in ${VM_BASE_DIR}${V_VIDOFF}"
			exit 1
		fi

		echo -e "${V_BOLD_GREEN}Starting VM ${vm}${V_VIDOFF}"
		vmrun -T fusion start "${vmx}" "gui"
		#guestIP=$(vmrun -T fusion getGuestIPAddress ${vmx} -wait)

		## Make project root folder avilable inside the VM
		if [[ ! ${HOSTNAME} =~ ^master-[0-9]+$ ]] || [[ ! ${HOSTNAME} =~ ^worker-[0-9]+$ ]]; then
			vmrun -T fusion enableSharedFolders "${vmx}" runtime > /dev/null 2>&1 || true
			vmrun -T fusion addSharedFolder "${vmx}" "$shared_name" "$host_shared_folder" > /dev/null 2>&1 || true
		fi
	fi
}

function stop_vm() {
	local vm=$1
	local vmx="${VM_BASE_DIR}/${vm}.vmwarevm/${vm}.vmx"

	if vmrun -T fusion list | grep -v "Total running VMs" | awk -F/ '{print $(NF -1)}' | grep -q "${vm}.vmwarevm"; then
		if [ ! -f "${vmx}" ]; then
			echo -e "${V_BOLD_RED}ERROR: Missing VMX file for the VM ${vm} in ${VM_BASE_DIR}${V_VIDOFF}"
			exit 1
		fi

		echo -e "${V_BOLD_GREEN}Stopping VM ${vm}${V_VIDOFF}"
		if [[ ${HOSTNAME} =~ ^master-[0-9]+$ ]] || [[ ${HOSTNAME} =~ ^worker-[0-9]+$ ]]; then
			vmrun -T fusion stop "${vmx}" "hard"
		else
			vmrun -T fusion stop "${vmx}" "soft"
		fi

		## Remove any iso attached as CD-ROM
		#sed -i "s~^sata0:1.fileName = .*.iso~sata0:1.fileName = \"auto detect\"~g" "${vmx}"
		sed -Ei "/^sata0:1.*$/d" ${vmx}

		## Remove all shared folders
		#sharedFolder0.present = "TRUE"
		sed -Ei "/^sharedFolder.*$/d" ${vmx}
	fi
}

function export_vm() {
	local vm=$1
	local vmx="${VM_BASE_DIR}/${vm}.vmwarevm/${vm}.vmx"
	local ova="${SCRIPT_ROOT}/ova/${vm}.ova"

	if [ ! -f "${vmx}" ]; then
		echo -e "${V_BOLD_RED}ERROR: Missing VMX file for the VM ${vm} in ${VM_BASE_DIR}${V_VIDOFF}"
		exit 1
	fi

	## Stop VM
	stop_vm ${vm} || true

	## Update the VMX file, and change vm boot order
	#bios.bootOrder = "ethernet0"
	#bios.bootOrder = "HDD"
	#sed -i 's~bios.bootOrder = "ethernet0"~bios.bootOrder = "HDD"~g' ${vmx}
	cp ${vmx} ${vmx}.orig
	if ! grep --quiet -e 'bios.bootOrder = "HDD"' ${vmx}; then
		echo 'bios.bootOrder = "HDD"' >> ${vmx}
	fi

	#ovftool --noSSLVerify --acceptAllEulas --overwrite --powerOffTarget $ovf vcsa.vmx
	#ovf="./VMware-vCenter-Server-Appliance-5.5.0.10300-2000350_OVA10.ova"
	#ovftool $ovf ./vcsa.vmx
	#ip=$(vmrun getGuestIPAddress vcsa.vmx -wait)

	## Export the VM as OVA
	rm -rf ${ova}

	mkdir -p ${SCRIPT_ROOT}/ova

	##ovftool --acceptAllEulas --overwrite --powerOffSource --powerOffTarget ${vmx} ${ova}
	ovftool --acceptAllEulas --overwrite --powerOffSource --powerOffTarget "${vmx}" "${ova}"
	echo "Wrote OVA file to ${ova}"
}

function build_vm() {
	local VM_NAME=$1

	#declare -A local TEST_VMS=
	#TEST_VMS=( \
	#    [test]='2|2048|00:50:56:2B:B7:20|bios|500' \
	#    [bootstrap]='8|2048|00:50:56:2B:B7:30|bios|500' \
	#    [master0]='16|2048|00:50:56:2B:B7:40|bios|500'
	#)
	#OLDIFS=$IFS
	#IFS='|' read -a VM_PROPS <<< "$(echo ${TEST_VMS[${VM_NAME}]})"
	#IFS=$OLDIFS
	##echo "${VM_PROPS[0]}"

	local VM_CPU_CORE=$(jq --raw-output --arg ARG "${VM_NAME}" '.[$ARG].cpu' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_MEMORY=$(jq --raw-output --arg ARG "${VM_NAME}" '.[$ARG].memory' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_NET0_MAC=$(jq --raw-output --arg ARG "${VM_NAME}" '.[$ARG].mac' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_FIRMWARE=$(jq --raw-output --arg ARG "${VM_NAME}" '.[$ARG].firmware' ${SCRIPT_ROOT}/${INVENTORY_FILE})
	local VM_DISK_SIZE=$(jq --raw-output --arg ARG "${VM_NAME}" '.[$ARG].disk' ${SCRIPT_ROOT}/${INVENTORY_FILE})

	local VM_VMX_PATH="${VM_BASE_DIR}/${VM_NAME}.vmwarevm/${VM_NAME}.vmx"
	local VM_CORES_PER_SOCKET='1'
	local VM_NET="vmnet${HOSTONLY_VMNET_NUMBER}"

	## Ref: https://github.com/OpenSLX/mltk/blob/master/core/modules/vmware-common/data/opt/openslx/vmchooser/plugins/vmware/includes/write_final_vmx.inc
	### https://github.com/dminkovsky/coreos-vmware-cluster/blob/master/cluster (cloud-init)

	create_vm ${VM_NAME} ${VM_DISK_SIZE} ${VM_NET0_MAC} ${VM_NET} ${VM_FIRMWARE}

	cat >> "${VM_VMX_PATH}" <<-HEREEND
	numvcpus = "$VM_CPU_CORE"
	memsize = "${VM_MEMORY}"

	HEREEND
}

short='hb:BpPcCs:S:re:DnN'
long='help,build-bastion-server:,build-container-image,provision-bastion-server,\
	provision-container,start-containers,stop-containers,\
	start-vm:,stop-vm:,reset-network,export-vm:,delete-all,start-dns,stop-dns'

# Execute getopt on the arguments passed to this program, identified by the special character $@
PARSED_OPTIONS=$(getopt --name "$(basename $0)" --options "${short}" --longoptions "${long}" --alternative -- "$@")

if [[ $# -lt 1 ]]; then
   echo -e "${V_BOLD_RED}ERROR: Incorrect number of parameters${V_VIDOFF}"
   usage
fi

# Note the quotes around $args; they are essential!
eval set -- "$PARSED_OPTIONS"

while true; do
	case "$1" in
		-h|--help)
			usage
			shift
			exit 0
			;;
		-b|--build-bastion-server)
			if [ -z "$2" ]; then
				>&2 echo -e "${V_BOLD_RED}ERROR: empty argument to -b|--build-bastion-server${V_VIDOFF}";
				exit 2;
			fi
			#if [ -n "$2" ]; then
			#    echo "Argument: $2"
			#fi
			#exit
			start_coredns
			echo ""
			create_hostonly_network
			echo ""
			enable_hostonly_dhcp
			echo ""
			provsion_ks
			echo ""
			sleep 1
			echo -e "${V_BOLD_GREEN}After PXE VM is build run following command to terminate background webserver:${V_VIDOFF}"
			echo -e "${V_BOLD_RED} kill -9 \$(pgrep webserver)${V_VIDOFF}"
			echo ""
			echo -e "${V_BOLD_GREEN}When the initial screen appears, select Install Red Hat Enterprise Linux 8.0${V_VIDOFF}"
			echo -e "${V_BOLD_GREEN}press the Tab key to append the following stanza and press Enter:${V_VIDOFF}"
			echo ""
			echo -e "${V_BOLD_RED}   inst.ks=http://${HOST_IP}:8100/bastion.cfg${V_VIDOFF}"
			build_bastion_server $(echo "$2" | awk '{gsub(/^ +| +$/,"")} {print $0}')
			shift 2
			;;
		-p|--provision-bastion-server)
			echo ""
			provision_bastion_server
			shift
			;;
		-B|--build-container-image)
			echo ""
			build_container_image
			shift
			;;
		-P|--provision-container)
			echo ""
			provision_container
			shift
			;;
		-c|--start-containers)
			echo ""
			start_containers
			shift
			;;
		-C|--stop-containers)
			echo ""
			stop_containers
			shift
			;;
		-s|--start-vm)
			echo ""
			#OLDIFS=$IFS
			#IFS=' ' read -a CMDARGS <<< "$(echo $2 | awk '{$2=$2};1')"
			#IFS=$OLDIFS
			#build_vm ${CMDARGS[0]} ${CMDARGS[1]} ${CMDARGS[2]} ${CMDARGS[3]} ${CMDARGS[4]}
			##start_vm ${CMDARGS[0]} "gui"
			##string='test-server 2 1024 qq:12:12 bios'
			##array=$(echo $1 | awk -F ' ' '{ s = $1; for (i = 2; i <= NF; i++) s = s "\n"$i; print s; }')
			start_vm "$(echo "$2" | awk '{gsub(/^ +| +$/,"")} {print $0}')" "nogui"
			shift 2
			;;
		-S|--stop-vm)
			echo ""
			stop_vm "$(echo "$2" | awk '{gsub(/^ +| +$/,"")} {print $0}')"
			shift 2
			;;
		-r|--reset-network)
			echo ""
			disable_hostonly_dhcp
			shift
			;;
		-e|--export-vm)
			echo ""
			export_vm "$(echo "$2" | awk '{gsub(/^ +| +$/,"")} {print $0}')"
			shift 2
			;;
		-D|--delete-all)
			echo ""
			delete_vm_infra
			shift
			;;
		-n|--start-dns)
			echo ""
			start_coredns
			shift
			;;
		-N|--stop-dns)
			echo ""
			stop_coredns
			shift
			;;
		--)
			shift
			break
			;;
		*)
			usage "Unknown parameter: $*"
			;;
	esac
done