#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

DEFAULT_HTTP_PROXY="http://internet.ford.com:83"
DEFAULT_NO_PROXY="127.0.0.1,localhost,.ford.com,local,.svc"

set +e
HTTP_CODE=$( \
    curl \
    --head \
    --insecure \
    --location \
    --silent \
    --fail \
    --output /dev/null \
    --write-out "%{http_code}" \
    --connect-timeout 10 \
    --proxy ${DEFAULT_HTTP_PROXY} \
    https://google.com
)
if [ "$HTTP_CODE" = "200" ]; then
    export http_proxy="${DEFAULT_HTTP_PROXY}"
    export HTTP_PROXY="${DEFAULT_HTTP_PROXY}"
    export https_proxy="${DEFAULT_HTTP_PROXY}"
    export HTTPS_PROXY="${DEFAULT_HTTP_PROXY}"
    export no_proxy="${DEFAULT_NO_PROXY}"
    export NO_PROXY="${DEFAULT_NO_PROXY}"
else
    export http_proxy=""
    export HTTP_PROXY=""
    export https_proxy=""
    export HTTPS_PROXY=""
    export no_proxy=""
    export NO_PROXY=""
fi
set -e

OCP4_NIGHTLY_RELEASE_VERSION='4.2.0-0.nightly-2019-09-25-233506'

DOWNLOAD_BASE_URL='https://mirror.openshift.com/pub/openshift-v4'
OCP4_DOWNLOAD_BASE_URL="${DOWNLOAD_BASE_URL}/clients/ocp-dev-preview/${OCP4_NIGHTLY_RELEASE_VERSION}"

LOCAL_ISO_DIR="${HOME}/Projects/iso/openshift-v4"
LOCAL_CLIENT_BASE_DIR="${LOCAL_ISO_DIR}/clients/ocp"

mkdir -p ${LOCAL_CLIENT_BASE_DIR}

# Download OCP4 client and installer
curl \
    --connect-timeout 20 \
    --retry 5 \
    --retry-delay 0 \
    --retry-max-time 60 \
    --insecure \
    --progress-bar \
    --location \
    --output /tmp/sha256sum.txt \
    ${OCP4_DOWNLOAD_BASE_URL}/sha256sum.txt

for line in $(cat /tmp/sha256sum.txt | awk '{print $1 "," $2}'); do
    SHA256SUM=$(echo $line | awk -F "," '{print $1}')
    BINARY=$(echo $line | awk -F "," '{print $2}')
    OUTPUT_FILE_PATH="${LOCAL_CLIENT_BASE_DIR}/${OCP4_NIGHTLY_RELEASE_VERSION}/${BINARY}"

    mkdir -p "${LOCAL_CLIENT_BASE_DIR}/${OCP4_NIGHTLY_RELEASE_VERSION}"
    if [ ! -f ${OUTPUT_FILE_PATH} ]; then
        curl \
            --connect-timeout 20 \
            --retry 5 \
            --retry-delay 0 \
            --retry-max-time 60 \
            --insecure \
            --progress-bar \
            --location \
            --output ${OUTPUT_FILE_PATH} \
            ${OCP4_DOWNLOAD_BASE_URL}/${BINARY}
        ## Check the checksum of the binary
        #echo "${SHA256SUM} ${OUTPUT_FILE_PATH}" | sha256sum -c -
        shasum -a 256 -c <<< "${SHA256SUM} *${OUTPUT_FILE_PATH}"
    fi
done
mv /tmp/sha256sum.txt "${LOCAL_CLIENT_BASE_DIR}/${OCP4_NIGHTLY_RELEASE_VERSION}"
