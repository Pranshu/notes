###
# name: prepare_server.py
# description: create a profile using server template
# and retrieves the list all mac addresses and returns to user
# date: Jun 2019
# author: Prakash Mirji, HPE
###

from pprint import pprint
from hpOneView.oneview_client import OneViewClient
from hpOneView.exceptions import HPOneViewException
import config_loader as cf
from ilo_client import  iLoClient
from collections import defaultdict
import time
import argparse
import os
import json
import sys

config = {
    "ip": "19.34.94.28",
    "api_version": 800,
    "credentials": {
        "userName": "pmirji",
        "password": "",
        "authLoginDomain": "LOCAL"
    }
}
# common inputs needed for server setup
enclosure_group_name = "ENCL_GRP"
server_hardware_type_name = "SY 480 Gen10 1"
server_template_name = "caas-template"
scope_name = "HPE"
server_profile_prefix = "CAAS-"

# These variables will be populated based on the same you specified above
enclosure_group_uri = ""
server_hardware_type_uri = ""
server_template_uri = ""
oneview_client = ""

# name of the output json file
json_macs_filename = "macs.json"

#json output template
# sample json looks like this
# {
#   "type": "server_macs",
#   "servers":[
#     {
#       "name": "bay1",
#       macs:[
#         {"Mezz 2:1-a":"72:04:84:60:01:57"},
#         {"Mezz 3:1-a":"72:04:84:60:01:58"}
#       ]
#     },
#     {
#       "name": "bay2",
#       macs:[
#         {"Mezz 2:1-a":"72:04:84:60:01:57"},
#         {"Mezz 3:1-a":"72:04:84:60:01:58"}
#       ]
#     }
#     ]
# }
json_dict = {
    "type": "server_macs",
    "servers": []
}

# Get the scope resource by name
def get_scope(scope_name):
    scope = oneview_client.scopes.get_by_name(scope_name)
    return scope

# Get the enclosure_group details by name
def get_enclosure_group(name):
    enclosure = {}
    try:
        enclosure = oneview_client.enclosure_groups.get_by('name', name)[0]
    except HPOneViewException as e:
        print(e.msg)
    return enclosure

# Get hardware type details by name
def get_hardware_type(name):
    hw_type = {}
    try:
        hw_type = oneview_client.server_hardware_types.get_by('name', name)[0]
    except HPOneViewException as e:
        print(e.msg)
    return hw_type

# Get the server template details by name
def get_server_template(name):
    server_template = {}
    try:
        server_template = oneview_client.server_profile_templates.get_by('name', name)[0]
    except HPOneViewException as e:
        print(e.msg)
    return server_template

# Get list of all server hardware resources
def get_all_servers():
    server_hardware_all = oneview_client.server_hardware.get_all()
    return server_hardware_all

# Get server by name
def get_server_by_name(name):
    server_byName = oneview_client.server_hardware.get_by(
        'name', name)[0]
    print("\nFound server at uri '%s'\n  by name = '%s'" %
        (server_byName['uri'], server_byName['name']))
    return server_byName

# Get server id from server_hardware
def get_server_id(server_name):
    server = get_server_by_name(server_name)
    if (server['uri'] is None):
        print("ERROR: Server uri is not found, exiting...")
        exit(1)

    server_hardware_id = server['uri'].split("/")[-1]
    return server_hardware_id

# Get server id from server_hardware
def get_server_hardware_uri(server_name):
    server = get_server_by_name(server_name)
    if (server['uri'] is None):
        print("ERROR: Server uri is not found, exiting...")
        exit(1)

    server_hardware_uri = server['uri']
    return server_hardware_uri

# Get servers by scope
def get_servers_by_scope(scope_name):
    scope = get_scope(scope_name)
    servers_by_scope = defaultdict(dict)
    url_with_scope = "/rest/server-hardware" + "?" + "scopeUris=" + scope['uri']
    try:
        servers_by_scope = oneview_client.server_hardware.get(url_with_scope)
    except HPOneViewException as e:
        print(e.msg)
    return servers_by_scope

# Get list of BIOS/UEFI Values
def get_bios_uefi_details(server_hardware_id):
    try:
        print("Get list of BIOS/UEFI Values")
        bios = oneview_client.server_hardware.get_bios(
            server_hardware_id)
        pprint(bios)
    except HPOneViewException as e:
        print(e.msg)

# Request power operation to change the power state of the physical server.
def server_power_state(state, server_hardware_id):
    try:
        configuration = {
            "powerState": state,
            "powerControl": "MomentaryPress"
        }
        server_power = oneview_client.server_hardware.update_power_state(configuration, server_hardware_id)
        print("Successfully changed the power state of server '{name}' to '{powerState}'".format(**server_power))
    except HPOneViewException as e:
        print(e.msg)

# create server template from json file
def create_server_template(name):
    template_options = {}
    template_response = {}
    try:
        template_options = cf.load_template_from_file(template_options)
        template_options['name'] = name
        #print("template json before creating: ", template_options)
        template_response = oneview_client.server_profile_templates.create(template_options)
    except Exception as e:
        print("ERROR: error while creating server template from json file : ", e)
    print("server template response = ", template_response)

# create server profile from template
def create_server_profile(name, server_hardwar_uri):
    profile = {}
    affinity = ""
    connectionSettings = dict(connections=[])
    boot = {}
    bootMode = {}
    firmware = {}
    bios = {}
    localStorage = {}
    server_template = {}
    initialScopeUris = []

    try:
        # get the server template details and create the payload for profile
        server_template = get_server_template(server_template_name)

        if (server_template is None):
            print("ERROR: no server profile template found with name: ", server_template_name)
            exit(1)
        if (server_template['uri'] is not None):
            global server_template_uri
            server_template_uri = server_template['uri']
        else:
            print("Server template uri not found, exiting...")
            exit(1)
        
        # copy the data from server_template object
        for conn in server_template['connectionSettings']['connections']:
            del conn['boot']['bootVlanId']
            del conn['lagName']
            connectionSettings["connections"].append(conn)

        affinity = server_template['affinity']

        # for scope in server_template['initialScopeUris']:
        #     initialScopeUris.append(scope)

        # Example to override template values

        # boot = {
        #     "manageBoot": True,
        #     "order": [
        #     "HardDisk"
        #     ]
        # }
        # bios = server_template['bios']
        # bios['manageBios'] = True
        # bootMode = {
        #     "manageMode": True,
        #     "mode": "UEFIOptimized",
        #     "pxeBootPolicy": "Auto",
        #     "secureBoot": "Disabled"
        # }
        bios = server_template['bios']
        boot = server_template['boot']
        bootMode = server_template['bootMode'] 
        firmware = server_template['firmware']
        localStorage = server_template['localStorage']

        print("\nCreating a server profile with name : ", name)

        profile_options = dict(
            name=name,
            serverProfileTemplateUri=server_template_uri,
            serverHardwareTypeUri=server_hardware_type_uri,
            enclosureGroupUri=enclosure_group_uri,
            serialNumberType="Physical",
            serverHardwareUri=server_hardwar_uri,
            type="ServerProfileV9",
            connectionSettings=connectionSettings,
            bios=bios,
            boot=boot,
            bootMode=bootMode,
            firmware=firmware,
            localStorage=localStorage,
            affinity=affinity
        )
        profile = oneview_client.server_profiles.create(profile_options, force=True)
    except HPOneViewException as e:
        print(e.msg)
    return profile

# delete the profile:
# example call : delete_server_profile("/rest/server-profiles/3268adcb-5f17-4357-b9c9-f4e0d133fd88")
def delete_server_profile(profile):
    try:
        # profile_dict = dict(
        #     uri=profile_uri
        # )
        # Delete the created server profile
        print("\nDeleting the server profile = ", profile['uri'])
        oneview_client.server_profiles.delete(profile)
        print("\nThe server profile was successfully deleted.")
    except HPOneViewException as e:
        print(e.msg)

# Get server-profile details by name
def get_server_profile(name):
    print("\nGetting a server profile details using name = ", name)
    profile = oneview_client.server_profiles.get_by_name(name)
    return profile

# Get the list of networks and network sets that are available 
# to a server profile along with their respective ports
def get_profile_conns():
    try:
        print("\nList all Ethernet networks associated with a server hardware type and enclosure group")
        available_networks = oneview_client.server_profiles.get_available_networks(
            enclosureGroupUri=enclosure_group_uri, serverHardwareTypeUri=server_hardware_type_uri, view='Ethernet')
        pprint(available_networks)
    except HPOneViewException as e:
        print(e.msg)

# get the mac address
# print the mac address with portId
# to get the first interface mac id, 
# if Synergy has two interconnects at bay 3 and 6 
# first interface mac address is with portId = 'Mezz 3:1-a'
# if Synergy has 4 interconnects, then first interface mac address
# with portId = 'Mezz 2:1-a'

def get_mac_addresses(conns):
    macdict = defaultdict(dict)
    for c in conns:
        if c['functionType'] == 'Ethernet':
            if not (c['mac'] is None):
                macdict[c['portId']] = c['mac']

    # all mac adress
    #print("dictory values %s\n", macdict)

    # first interfact mac address
    #print("first interface mac address: %s", macdict["Mezz 3:1-a"])

    return macdict

# function reads the json and returns the mac addresses [array] of 
# matching server name
def get_macs_by_server_name(server_name):
    json_data = {}
    with open(json_macs_filename, 'r', encoding='utf-8') as outfile:
        json_data = json.load(outfile)
    for svr in json_data["servers"]:
        if svr["name"] == server_name:
            return svr["macs"][0]
    return []

# function reads the json and returns the matching mac address based on 
# matching server name and mezz card
def get_mac_by_sname_mezzcard(server_name, mezz_card):
    macs = get_macs_by_server_name(server_name)
    for k, v in macs.items():
        if k == mezz_card:
            return v
    return ""

# function to check given server name and mac address present in the json file
def check_mac_address_exists(server_name, mac_address):
    macs = get_macs_by_server_name(server_name)
    if macs is None:
        return False
    for k, v in macs.items():
        if v == mac_address:
            return True
    return False

# create base json file
def create_base_json():
    global json_dict
    global json_macs_filename
    if os.path.isfile(json_macs_filename):
        os.remove(json_macs_filename)
    with open(json_macs_filename, "w") as outfile:
        json.dump(json_dict, outfile, indent=4, sort_keys=True)

# write list of mac addresses to a json file
def write_to_json(server_name, macdict):
    global json_macs_filename
    tmp_dict = {}
    server_data = {
        "name":"",
        "macs":[]
    }
    server_data["name"] = server_name + "-" + "profile"
    
    for key, value in macdict.items():
        tmp_dict[key] = value
    server_data["macs"].append(tmp_dict)
    
    base_json = {}
    with open(json_macs_filename, 'r', encoding='utf-8') as outfile:
        base_json = json.load(outfile)
        base_json["servers"].append(server_data)
    with open(json_macs_filename, 'w', encoding='utf-8') as outfile:
        json.dump(base_json, outfile, indent=4, sort_keys=True)

# for OV 4.20, you can use below function for onetime boot
# not available in OV 4.10, instead use ilo_client.py
def set_onetime_boot(self, srv_hardware_uri, onetime_boot):
		body = [{"op":"replace","path":"/oneTimeBoot","value":onetime_boot}]
		resp = oneview_client.connection.patch(srv_hardware_uri, body)
		return resp
		# resp  = self.function("/rest/server-hardware/39313738-3034-4753-4838-33345444304E", "NETWORK")

# start preparing the server
def prepare_server(server_name, profile_name):

    # get the enclosure group uri
    enc = get_enclosure_group(enclosure_group_name)
    if ( enc['uri'] is not None):
        global enclosure_group_uri
        enclosure_group_uri = enc['uri']
    else:
        print("Enclosure group uri not found, exiting...")
        exit(1)

    # get the server hardware type uri
    hw_type = get_hardware_type(server_hardware_type_name)
    if ( hw_type['uri'] is not None):
        global server_hardware_type_uri
        server_hardware_type_uri = hw_type['uri']
    else:
        print("Server hardware type uri not found, exiting...")
        exit(1)

    server_hardware_id = get_server_id(server_name)

    # power off the server before applying profile
    server_power_state("Off", server_hardware_id)
    time.sleep(10)

    server_hardware_uri = get_server_hardware_uri(server_name)
    
    profile = create_server_profile(profile_name, server_hardware_uri)
    if profile is None:
        print("Create profile failed, check the exception message")
        exit(1)

# demo function
def demo():
    # example of getting macs by server name, returns list of macs
    server_name = 'USE720C2MP_RK8_U11, bay 4'
    macs = get_macs_by_server_name(server_name)
    print("\nList of all mac address of server '{}'".format(server_name))
    for k,v in macs.items():
        print(k,v)

    # example of getting matching mac by server name and mezzcard, return just mac
    mezz_card = 'Mezz 3:1-a'
    # To get the first mac address, pass mezz_card as 'Mezz 3:1-a'
    mac = get_mac_by_sname_mezzcard(server_name, mezz_card)
    print("\nServer '{}' has mac address '{}' with mezz card  '{}'".format(server_name, mac, mezz_card))

    # example to check given server name and mac present in json
    mac_address = '72:04:84:60:01:5C'
    exists = check_mac_address_exists(server_name, mac_address)
    if exists:
        print("\nfound matching mac address '{}' in the json".format(mac_address))
    else:
        print("\nmac address '{}' not found in the json".format(mac_address))

def print_usage():
    print("usage: export OV_USERNAME, OV_PASSWD, OV_DOMAIN, OV_HOSTNAME environment varibale")
    print("then, run below command with one of the options")
    print("usage: to create server template: python -t <template name> provision_hardware.py")
    print("usage: to get all servers: python -S provision_hardware.py")
    print("usage: to get all servers in scope: python -s provision_hardware.py")
    print("usage: to create a profile: python -c provision_hardware.py")
    print("usage: to delete a profile: python -r <profle name> provision_hardware.py")
    print("usage: to power on server in normal mode: python -o provision_hardware.py")
    print("usage: to power on server in network boot mode: python -n provision_hardware.py")
    print("usage: to get all mac addresses of a server: python -M provision_hardware.py")
    print("usage: to get first mac address of a server: python -m provision_hardware.py")
    print("usage: to recreate macs.json for all servers in scope: python -j provision_hardware.py")

def main():

    parser = argparse.ArgumentParser(add_help=True, description='Usage')

    if len(sys.argv)==1:
        print_usage()
        parser.print_help()
        sys.exit(1)

    parser.add_argument('-u', '--username',
        dest='username',
        required=False,
        help='pass OneView username as an argument')

    parser.add_argument('-p', '--passwd',
        dest='passwd',
        required=False,
        help='pass OneView password as an argument')

    parser.add_argument('-a', '--hostname',
        dest='hostname',
        required=False,
        help='pass OneView ip address or hostname as an argument')
 
    parser.add_argument('-d', '--domain',
        dest='domain',
        required=False,
        help='pass OneView username login domain as an argument')

    parser.add_argument('-t', '--template', 
        dest='template',
        required=False,
        help='pass OneView server template as an argument')

    parser.add_argument('-b', '--boot',
        dest='bootnormal',
        required=False,
        help='pass server-hardware name too boot server in normal mode')

    parser.add_argument('-n', '--networkboot',
        dest='bootnetwork',
        required=False,
        help='pass server-hardware name too boot server in network boot mode')

    parser.add_argument('-r', '--profilename', 
        dest='profilename',
        required=False,
        help='pass server-profile name to delete it')

    parser.add_argument('-M', '--macallservername',
        dest='macallservername',
        required=False,
        help='pass server name to get all mac addresses of a server')

    parser.add_argument('-m', '--macservername',
        dest='macservername',
        required=False,
        help='pass server name to get first mac address of a server')
 
    parser.add_argument('-c', action='store_true',
        help='option to create server profile')
    parser.add_argument('-S', action='store_true',
        help='get all servers')
    parser.add_argument('-s', action='store_true',
        help='get servers in a given scope')
    parser.add_argument('-e', action='store_true',
        help='run demo')

    parser.add_argument('-j', action='store_true',
       help='create json')
     

    parsed_args = parser.parse_args()
    OV_USERNAME = parsed_args.username
    OV_PASSWD = parsed_args.passwd
    OV_HOSTNAME = parsed_args.hostname
    OV_DOMAIN = parsed_args.domain
    OV_SERVER_TEMPLATE = ""
    if parsed_args.template:
        OV_SERVER_TEMPLATE = parsed_args.template
    else:
        OV_SERVER_TEMPLATE = server_template_name

    if OV_PASSWD is None:
        OV_PASSWD = os.getenv('OV_PASSWD')
    if OV_USERNAME is None:
        OV_USERNAME = os.getenv('OV_USERNAME')
    if OV_HOSTNAME is None:
        OV_HOSTNAME = os.getenv('OV_HOSTNAME')
    if OV_DOMAIN is None:
        OV_DOMAIN = os.getenv('OV_DOMAIN')

    if OV_USERNAME is None:
        print("ERROR: OneView username is empty! " +
        "specify username as an argument, " + " or " +
        "export OV_USERNAME env variable and rerun")
        exit(1)

    if OV_PASSWD is None:
        print("ERROR: OneView password is empty! " +
        "specify password as an argument, " + " or " +
        "export OV_PASSWD env variable and rerun")
        exit(1)
    
    if OV_HOSTNAME is None:
        print("ERROR: OneView hostname is empty! " +
        "specify hostname as an argument, " + " or " +
        "export OV_HOSTNAME env variable and rerun")
        exit(1)
 
    if OV_DOMAIN is None:
        print("ERROR: OneView domain is empty! " +
        "specify domain as an argument, " + " or " +
        "export OV_DOMAIN env variable and rerun")
        exit(1)
 
    #update the conf object with OV CREDENTIALS
    config['credentials']['userName'] = OV_USERNAME
    config['credentials']['password'] = OV_PASSWD
    config['ip'] = OV_HOSTNAME
    config['credentials']['authLoginDomain'] = OV_DOMAIN

    global oneview_client
    try:
        oneview_client = OneViewClient(config)
    except HPOneViewException as e:
        print(e.msg)
        print("Please check OneView credentials and rerun")
        exit(1)

    if parsed_args.S:
        # get the list of server names available for CaaS
        servers_all = get_all_servers()
        print("\nList of available servers in OneView")
        for s in servers_all:
            print(s['name'])

    if parsed_args.s:
        servers_in_scope = get_servers_by_scope(scope_name)
        print("\nList of available servers in given scope : ", scope_name)
        for s in servers_in_scope['members']:
            print(s['name'])

    if parsed_args.template:
        create_server_template(OV_SERVER_TEMPLATE)

    # Let us use servers in scope and start applying profile
    if parsed_args.c:
        profile_appending_str = ""
        inc_cnt = 0
        create_base_json()
        servers_in_scope = get_servers_by_scope(scope_name)
        for svr in servers_in_scope['members']:
            inc_cnt = inc_cnt + 1
            profile_appending_str = '{num:0{width}}'.format(num=inc_cnt, width=3)
 
            # TODO: check the preference on profile name policy
            # for now, use prefix and number
            #profile_name = server_profile_prefix + profile_appending_str
            server_name = svr['name']
            profile_name = server_name + "-" + "profile"
            print("\nGoing to create a server profile with name = ", profile_name)
            

            # TODO - uncomment after testing
            prepare_server(server_name, profile_name)

            # get the server id to perform power or delete operations
            server_hardware_id = get_server_id(server_name)
            # power on the server
            #server_power_state("On", server_hardware_id)
            #time.sleep(10)
 
            # Get the mac address
            profile = get_server_profile(profile_name)
            if (profile is None):
                print("ERROR: no profile found with name : %s", profile_name)
                #exit(1)
                continue
 
            if (len(profile['connectionSettings']['connections']) == 0):
                print("ERROR: no profile connections found. exiting....")
                exit(1)

            macdict = get_mac_addresses(profile['connectionSettings']['connections'])
            # DEBUG statements
            # print("\nList of mac addresses")
            # for key, value in macdict.items():
            #     print("{} = {}".format(key, value))
            # print("\nfirst interface mac address =", macdict["Mezz 3:1-a"])
            write_to_json(server_name, macdict)
            print("\n severs mac addresses are dumped to json file : ", json_macs_filename)

    # to demo mac address, run below function
    if parsed_args.e:
        demo()

    # delete a profile
    if parsed_args.profilename:
        profile = get_server_profile(parsed_args.profilename)
        delete_server_profile(profile)

    # boot server in normal mode
    if parsed_args.bootnormal:
        s_name = parsed_args.bootnormal
        # get the server id to perform power or delete operations
        server_hardware_id = get_server_id(s_name)
        # power on the server
        server_power_state("On", server_hardware_id)
        time.sleep(10)

    # boot server in network boot mode
    if parsed_args.bootnetwork:
        s_name = parsed_args.bootnetwork
        print("boot network ", s_name)
        # get the server id to perform power or delete operations
        server_hardware_id = get_server_id(s_name)
        i_client =  iLoClient(oneview_client)
        resp = i_client.set_onetime_pxe_boot("/rest/server-hardware/"+server_hardware_id)
        if resp:
            print("\nSuccessfully Set onetime network boot.")
        else:
            print("\n ERROR: failed to setup onetime network boot")
        # power on the server
        server_power_state("On", server_hardware_id)
        time.sleep(10)

    # to get all mac address
    if parsed_args.macallservername:
        macs = get_macs_by_server_name(parsed_args.macallservername)
        print("\nList of all mac address of server '{}'".format(parsed_args.macallservername))
        for k,v in macs.items():
            print(k,v)

    # to get first mac address
    if parsed_args.macservername:
        # mezz port number. In most cases Mezz 3:1-a has first mac address
        # change it if it not in your case
        mezz_card = 'Mezz 3:1-a'
        s_name = parsed_args.macservername
        mac = get_mac_by_sname_mezzcard(s_name, mezz_card)
        print("\nServer '{}' has mac address '{}' with mezz card  '{}'".format(s_name, mac, mezz_card))


    # to recreate json file
    if parsed_args.j:
        create_base_json()
        servers_in_scope = get_servers_by_scope(scope_name)
    for svr in servers_in_scope['members']:
        server_name = svr['name']
        profile_name = server_name + "-" + "profile"
        profile = get_server_profile(profile_name)
        if profile is not None:
            macdict = get_mac_addresses(profile['connectionSettings']['connections'])
            write_to_json(server_name, macdict)


    

if __name__ == "__main__":
    main()
