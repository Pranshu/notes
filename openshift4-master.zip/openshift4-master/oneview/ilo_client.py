# -*- coding: utf-8 -*-
###
# (C) Copyright (2019 - 2024) Hewlett Packard Enterprise Development LP
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
###


import requests
import json
import time

from hpOneView.exceptions import HPOneViewException
from hpOneView.oneview_client import OneViewClient

# Suppress warning - InsecureRequestWarning: Unverified HTTPS request is being made
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

#######################################
# Class for iLO operations using SSO
#######################################
class iLoClient():
    def __init__(self, ov_client):
        self._oneview_client = ov_client
        self._iLO_IP = None
        self._sessionID = None

    ##################################
    # Get iLO IP using oneview_client
    ##################################
    def get_iLOIp(self, srvHardwareUri):
        srvHardware = self._oneview_client.connection.get(srvHardwareUri)
        try:
            iLOIpAddresses = srvHardware["mpHostInfo"]["mpIpAddresses"]
            iLOIp = [ ip["address"] for ip in iLOIpAddresses if ip["type"] in ("DHCP", "Static") ][0] 
        except Exception as e:
            raise Exception("Could not get iLO IP. Error message: {}".format(e))

        return iLOIp
    
    ##################################
    # Get SSO session ID
    ##################################
    def get_SSO_sessionID(self, srvHardwareUri):

        # Get SSO session ID
        url = srvHardwareUri + "/remoteConsoleUrl"
        resp = self._oneview_client.connection.get(url)
        # TODO: Sometimes the "remoteConsoleUrl" is blank, retry the operation to fix it.
        try:
            iLOSessionID = [ x.split("=")[1] for x in resp["remoteConsoleUrl"].split("&") if x.startswith("sessionkey")][0]
        except Exception as e:    
            raise Exception("Couldn't get session ID. remoteConsoleUrl = {}\nerrMessage : {}".format(resp["remoteConsoleUrl"], e))

        return iLOSessionID
        
    ##################################
    # Do rest/redfish GET
    ##################################
    def login(self, srvHardwareUri):
        self._iLO_IP = self.get_iLOIp(srvHardwareUri)
        self._sessionID = self.get_SSO_sessionID(srvHardwareUri)
        
    ##################################
    # Do rest/redfish GET
    ##################################
    def do_get(self, uri):
        reqUrl = "https://" + self._iLO_IP + uri
        headers = { 'X-Auth-Token': self._sessionID }

        resp = requests.get(reqUrl, headers=headers, verify = False)
        if isinstance(resp.status_code ,str):
            # The response status received is a string. So converted to this format.
            if (resp.status_code != str(200)):
                raise Exception("Failed to do GET. Status code = {}\nError Message = {}.".format(resp.status_code, resp.text))
        else:
            if (resp.status_code != 200):
                raise Exception("Failed to do GET. Status code = {}\nError Message = {}.".format(resp.status_code, resp.text))
            
        return resp.json()
        
    ##################################
    # Do rest/redfish PATCH
    ##################################
    def do_patch(self, uri, body):
        reqUrl = "https://" + self._iLO_IP + uri
        headers = { 'X-Auth-Token': self._sessionID }

        resp = requests.patch(reqUrl, headers=headers, json=body, verify = False)

        if (resp.status_code != 200):
            raise Exception("Failed to do PATCH. Status code = {}\nError Message = {}.".format(resp.status_code, resp.text))

        return resp.json()

    ##################################
    # Set Onetime PXE Boot
    ##################################
    def set_onetime_pxe_boot(self, srvHardwareUri):
        #Login to iLO using SSO
        self.login(srvHardwareUri)

        # Gwt Systems
        systems = self.do_get('/redfish/v1/Systems')
        for system in systems["Members"]:
            # Set onetime PXE boot
            oneTimeBoot = {
                'BootSourceOverrideEnabled': 'Once',
                'BootSourceOverrideTarget': 'Pxe'
                }

            body = {'Boot' : oneTimeBoot }
            resp = self.do_patch(system['@odata.id'], body)
            break

        return resp
    
    ##################################
    # Mount iso to iLO virtual media
    ##################################
    def mount_vmedia_iLO(self, srvHardwareUri, isoUrl, BootOnNextServerReset):
        #Login to iLO using SSO
        self.login(srvHardwareUri)

        managers = self.do_get('/redfish/v1/Managers')

        for manager in managers["Members"]:
            resp = self.do_get(manager['@odata.id'])
            if not resp["VirtualMedia"]:
                continue

            vmediaUri = resp["VirtualMedia"]["@odata.id"]
            resp = self.do_get(vmediaUri)
            for member in resp["Members"]:
                resp = self.do_get(member['@odata.id'])
                if 'DVD' not in resp['MediaTypes']: 
                    continue

                body = {"Image": isoUrl }
                body["Oem"] = {"Hpe": {"BootOnNextServerReset": BootOnNextServerReset}}

                resp = self.do_patch(resp['@odata.id'], body)
        return resp

    ##################################
    # get the host ip 
    ##################################
    def get_host_ip(self, srvHardwareUri, mac, timeout):
        #Login to iLO using SSO
        self.login(srvHardwareUri)

        print("\nWaiting to get Host IP...")
        systems = self.do_get('/redfish/v1/Systems')

        interface_uri = ""
        for system in systems["Members"]:
            response = self.do_get(system["@odata.id"])
            EthInterfaces = self.do_get(response['EthernetInterfaces']['@odata.id'])
            while True:
                try:
                    if not EthInterfaces["Members"]:
                        time.sleep(10)
                    elif EthInterfaces["Members"]:
                        break
                except KeyError:
                    time.sleep(10)
                EthInterfaces = self.do_get(response['EthernetInterfaces']['@odata.id'])

            timeout = time.time() + 60*timeout
            while time.time() < timeout:
                for EthInterface in EthInterfaces["Members"]:
                    try:
                        interface = self.do_get(EthInterface["@odata.id"])
                    except:
                        continue
        
                    if interface:
                        if interface.get('MACAddress') and interface.get('IPv4Addresses'):
                            if interface['MACAddress']:
                                if interface['MACAddress'].lower() == mac.lower():
                                    ipaddr = interface['IPv4Addresses'][0].get('Address')
                                    if ipaddr:
                                        return ipaddr
                    time.sleep(20)
        return ""
