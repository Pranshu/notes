#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

# convinient script to invoke oneview python code to get the mac address

# example to create a server profile for list of servers which are in scope
# uncomment when you are ready to create profiles
#provision_response=$(python provision_hardware.py -p '<passwd>')
#echo ""
#echo "$provision_response"

# example of getting macs by server name, returns list of macs
# below line returns the array of mac addresses of a given server name
# Note : make another call to get the list of servers
# dependency: make sure you have executed python main() function which creates
# server profile and generates json file

macs=$(python -c "import provision_hardware; print(provision_hardware.get_macs_by_server_name('USE720C2MP_RK8_U11, bay 4'))")

echo "list of macs : $macs"

echo ""
# example to get the specific mac address ( like first mac address )
first_mac=$(python -c "import provision_hardware; print(provision_hardware.get_mac_by_sname_mezzcard('USE720C2MP_RK8_U11, bay 4', 'Mezz 3:1-a'))")

echo "first mac address : $first_mac"

