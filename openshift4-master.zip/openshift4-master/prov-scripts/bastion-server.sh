#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

export ENABLE_PROXY=false
LOCAL_USER='admin'
LOCAL_USER_HOMEDIR="/home/${LOCAL_USER}"

# Update the bastion DNS server to point to MacOS host IP
rm -rf /opt/pxe-server-files || true
nmcli con mod ens160 ipv4.dns "${DEFAULT_DNS_SERVER}"
cat /etc/sysconfig/network-scripts/ifcfg-ens160
systemctl restart NetworkManager

set +e
HTTP_CODE=$( \
	curl \
	--head \
	--insecure \
	--location \
	--silent \
	--fail \
	--output /dev/null \
	--write-out "%{http_code}" \
	--connect-timeout 10 \
	--proxy http://internet.ford.com:83 \
	https://google.com
)
if [ "$HTTP_CODE" = "200" ]; then
	export ENABLE_PROXY=true
fi
set -e

if [ "$ENABLE_PROXY" = "true" ]; then
	export http_proxy="http://internet.ford.com:83"
	export HTTP_PROXY="http://internet.ford.com:83"
	export https_proxy="http://internet.ford.com:83"
	export HTTPS_PROXY="http://internet.ford.com:83"
	export no_proxy="localhost,127.0.0.1,.ford.com,.local,.svc"
	export NO_PROXY="localhost,127.0.0.1,.ford.com,.local,.svc"
else
	export http_proxy=""
	export HTTP_PROXY=""
	export https_proxy=""
	export HTTPS_PROXY=""
	export no_proxy=""
	export NO_PROXY=""
fi

set +u
rm -f /etc/environment
if [ "${ENABLE_PROXY}" = "true" ]; then
	cat <<-EOF | sudo tee /etc/profile.d/proxy.sh
		HTTP_PROXY="${HTTP_PROXY}"
		HTTPS_PROXY="${HTTPS_PROXY}"
		NO_PROXY="${NO_PROXY}"
		REGISTRY_AUTH_FILE=${LOCAL_USER_HOMEDIR}/.docker/config.json
		#REGISTRY_AUTH_FILE=${XDG_RUNTIME_DIR}/containers/auth.json
		#REGISTRY_AUTH_FILE=/run/containers/0/auth.json
	EOF
else
	unset HTTP_PROXY HTTPS_PROXY NO_PROXY http_proxy https_proxy no_proxy
	cat <<- EOF | sudo tee /etc/profile.d/proxy.sh
		REGISTRY_AUTH_FILE=${LOCAL_USER_HOMEDIR}/.docker/config.json
	EOF
fi
set -u

## Setup http proxy variables
set +u
if [ ! -z "${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}" ]; then
	export http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
	export https_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
	export no_proxy="${NO_PROXY:-${no_proxy}}"

	# Configure Yum proxy
	sed -i "/^proxy=.*/d" /etc/yum.conf
	sed -i "/\[main\]/a proxy=${http_proxy}" /etc/yum.conf

	if [ "${RHSM_ORG}" != "" ] && [ "${RHSM_ACTIVATION_KEY}" != "" ]; then
		http_proxy_re='^https?://(([^:]{1,128}):([^@]{1,256})@)?([^:/]{1,255})(:([0-9]{1,5}))?/?'
		# http_proxy_re='^http:\/\/(([^:]+):?(\S+)?@)?([^:]+)(:(\d+))?\/?$'
		if [[ "$http_proxy" =~ $http_proxy_re ]]; then
			# skip parent nesting groups 1 and 5
			export proxy_user=${BASH_REMATCH[2]}
			export proxy_pass=${BASH_REMATCH[3]}
			export proxy_host=${BASH_REMATCH[4]}
			export proxy_port=${BASH_REMATCH[6]}
		fi
		subscription-manager config --server.proxy_hostname="${proxy_host}" --server.proxy_port="${proxy_port}" --server.no_proxy="${no_proxy}"
	fi
else
	# Delete the line, with proxy configuration from /etc/yum.conf
	sed -i "/^proxy=.*/d" /etc/yum.conf
	subscription-manager config --server.proxy_hostname='' --server.proxy_port='' --server.no_proxy=''
fi

# Test internet connectivity
set -e
CONNECTION_TEST_URL='https://google.com'
HTTP_CODE=$(curl \
				--connect-timeout 20 \
				--retry 5 \
				--retry-max-time 60 \
				--retry-delay 0 \
				--head --insecure \
				--location \
				--silent \
				--fail \
				--output /dev/null \
				--write-out "%{http_code}" \
				$CONNECTION_TEST_URL
)
if [ "$HTTP_CODE" != "200" ]; then
	echo "Please check your internet connectivity"
	exit 1
else
	echo "Your internet connectivity has been successfully verified !"
fi
set +e

set -u

hostnamectl set-hostname bastion.${OCP_CLUSTER_NAME}.${OCP_TLD}

# Source Redhat Subscription Information if available
if [ -f "/root/.RHSM.env" ]; then
	. "/root/.RHSM.env"
	echo "Enrolling VM with Red Hat Subscription-Manager"
	subscription-manager register --org="${RHSM_ORG}" --activationkey="${RHSM_ACTIVATION_KEY}" || true
fi

#dnf install -y \
#    --enablerepo=rhel-8-for-x86_64-baseos-rpms \
#    --enablerepo=rhel-8-for-x86_64-appstream-rpms \
#    --enablerepo=ansible-2.8-for-rhel-8-x86_64-rpms \
#    --nodocs sshpass

# Install container tools
dnf install -y --nodocs podman buildah skopeo

# https://www.redhat.com/en/blog/managing-virtual-machines-rhel-8-web-console
# cockpit-machines to manage VMs
dnf install -y --nodocs cockpit cockpit-storaged cockpit-pcp pcp-selinux
systemctl enable cockpit.socket
systemctl start cockpit.socket
/usr/bin/firewall-cmd --permanent --remove-port=9090/tcp
/usr/bin/firewall-cmd --reload

# This package provides BIOS booting tools, python
dnf install -y --nodocs syslinux python36 rsync openssl
alternatives --set python /usr/bin/python3

# Install tools
declare -A TOOLS=( \
	['https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64']='/usr/local/bin/jq' \
	['https://github.com/mikefarah/yq/releases/download/2.4.0/yq_linux_amd64']='/usr/local/bin/yq' \
	['https://dl.minio.io/client/mc/release/linux-amd64/mc']='/usr/local/bin/mc' \
	['https://github.com/a8m/envsubst/releases/download/v1.1.0/envsubst-Linux-x86_64']='/usr/local/bin/go-envsubst' \
	['https://github.com/FiloSottile/mkcert/releases/download/v1.4.0/mkcert-v1.4.0-linux-amd64']='/usr/local/bin/mkcert'
)

for tool in "${!TOOLS[@]}"; do
	if [ ! -f ${TOOLS[$tool]} ]; then
		echo "Downloading ${TOOLS[$tool]} from ${tool} ..."
		curl \
			--connect-timeout 20 \
			--retry 5 \
			--retry-delay 0 \
			--retry-max-time 60 \
			--insecure \
			--progress-bar \
			--location \
			--output ${TOOLS[$tool]} \
			${tool}
		chmod +x ${TOOLS[$tool]}
	fi
done

# sudo ss -tulpn | grep :9090

# Register with redhat registry
# https://access.redhat.com/terms-based-registry/
REG_SECRET='/mnt/hgfs/share/secrets/registry.secret'
if [ -f ${REG_SECRET} ] && [ ! -f ${LOCAL_USER_HOMEDIR}/.docker/config.json ]; then
	mkdir -p ${LOCAL_USER_HOMEDIR}/.docker
	cp ${REG_SECRET} ${LOCAL_USER_HOMEDIR}/.docker/config.json
	chown ${LOCAL_USER}:${LOCAL_USER} ${LOCAL_USER_HOMEDIR}/.docker/config.json

	mkdir -p /root/.docker
	cp ${REG_SECRET} /root/.docker/config.json
	chown root:root /root/.docker/config.json
elif [ ! -f ${REG_SECRET} ] && [ ! -f ${LOCAL_USER_HOMEDIR}/.docker/config.json ]; then
	echo "Missing file ${REG_SECRET}"
	exit 1
fi

# Bug FIX: http://chris.collins.is/2019/01/25/podman-overlay-is-not-supported-over-xfs/
#PODMAN_STORAGE_CFG='${LOCAL_USER_HOMEDIR}/.config/containers/storage.conf'
#if [ -f ${PODMAN_STORAGE_CFG} ]; then
#	if grep -q 'RunRoot' ${PODMAN_STORAGE_CFG}; then
#		mv ${PODMAN_STORAGE_CFG} ${PODMAN_STORAGE_CFG}.orig
#		cat <<- EOF > ${PODMAN_STORAGE_CFG}
#		[storage]
#		   driver = "overlay"
#		   runroot = "$(id -u ${LOCAL_USER})"
#		   graphroot = "${LOCAL_USER_HOMEDIR}/.local/share/containers/storage"
#		   [storage.options]
#		     mount_program = "/usr/bin/fuse-overlayfs"
#		EOF
#	fi
#fi
