#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

export HOST_SHARE_PATH='/mnt/hgfs/share'
source ${HOST_SHARE_PATH}/prov-scripts/common.sh

## Deploy firewall rule
echo "Configuring fireall rules"

if [ $(systemctl is-active firewalld) = "active" ]; then
	# tcp/9000        -> HA Proxy Stats
	# tcp/22623       -> OpenShift Machine Config Operator
	# tcp/6443        -> OpenShift/K8S API Server
	# tcp/53          -> Bind (DNS)
	# tcp/20-21       -> VSFTP
	# tcp/21100-21110 -> VSFTP
	for port in 9000 22623 6443 8000; do
		#/usr/bin/firewall-cmd --zone="$(/usr/bin/firewall-cmd --get-default-zone)" --add-port=${port}/tcp --permanent
		sudo /usr/bin/firewall-cmd --add-port=${port}/tcp --permanent
	done

	# tcp/80          -> Openshift Router (http)
	# tcp/443         -> Openshift Router (https)
	for service in http https; do
		sudo /usr/bin/firewall-cmd --add-service=${service} --permanent
	done

	# udp/69     -> TFTP
	# udp/67     -> DHCP
	for port in 69 67; do
		sudo /usr/bin/firewall-cmd --add-port=${port}/udp --permanent
	done

	## Configure firewall to forward 8443 to 443 and 8080 to 80
	#/usr/bin/firewall-cmd --zone="$(/usr/bin/firewall-cmd --get-default-zone)" --add-forward-port=port=443:proto=tcp:toport=8443 --permanent
	#/usr/bin/firewall-cmd --zone="$(/usr/bin/firewall-cmd --get-default-zone)" --add-forward-port=port=80:proto=tcp:toport=8080 --permanent

	sudo /usr/bin/firewall-cmd --reload > /dev/null 2>&1
fi

podman stop -a # Stop all running containers
podman rm -a   # Remove all containers

# files.caas.ford.com/caas-infra/haproxy:2.0.2
## DOCS:
##  https://github.com/containers/libpod/blob/master/docs/podman-run.1.md
/usr/bin/podman run \
		--name haproxy \
		--detach=true \
		--cap-add=NET_BIND_SERVICE \
		-p 9000:9000 \
		-p 22623:22623 \
		-p 6443:6443 \
		-p 80:80 \
		-p 443:443 \
		-v ${HAPROXY_ROOT_DIR}/haproxy.cfg:/usr/local/etc/haproxy/haproxy.cfg:Z \
		docker.io/haproxy:2.0.1-alpine

ifaces=($(ip link show | grep -v link | awk {'print $2'} | sed 's/://g' | grep -v lo))
interface0="${ifaces[0]}"
/usr/bin/podman run \
		--name=adi \
		--detach=true \
		--network=host \
		-v ${PXE_ROOT_DIR}/vsftpd/conf/vsftpd.conf:/etc/vsftpd/adi-vsftpd.conf:Z \
		-v ${PXE_ROOT_DIR}/nginx/conf/nginx.conf:/etc/nginx/adi-nginx.conf:Z \
		-v ${PXE_ROOT_DIR}/dhcp/conf/dhcpd.conf:/etc/dhcp/dhcpd.conf:Z \
		-v ${TFTP_ROOT_DIR}:/var/lib/tftpboot:Z \
		-v ${NGINX_ROOT_DIR}:/usr/share/nginx/html:Z \
		-e DHCP_SERVER_IFACE="${interface0}" \
		-e HTTP_PROXY="${http_proxy}" \
		-e HTTPS_PROXY="${https_proxy}" \
		-e NO_PROXY="${no_proxy}" \
		-e http_proxy="${http_proxy}" \
		-e https_proxy="${https_proxy}" \
		-e no_proxy="${no_proxy}" \
		files.caas.ford.com/caas-infra/adi:1.0.0
