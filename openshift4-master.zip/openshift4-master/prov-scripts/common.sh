export DOMAIN='ocp4.local'
export PXE_SERVER_ADDRESS="http://bastion.${DOMAIN}:8000"
export PXE_CHAINLOADER_ADDRESS="http://bastion.${DOMAIN}:10080"

export PXE_ROOT_DIR_SKEL="/mnt/hgfs/share/pxe-server-files-skel"

export PXE_ROOT_DIR="/opt/pxe-server-files"

export NGINX_ROOT_DIR="${PXE_ROOT_DIR}/nginx/www"
export TFTP_ROOT_DIR="${PXE_ROOT_DIR}/tftp"
export HAPROXY_ROOT_DIR="${PXE_ROOT_DIR}/haproxy"

export OS_DIST_DIR="${NGINX_ROOT_DIR}/dist"
export PXELINUX_DIR="${TFTP_ROOT_DIR}/pxelinux"
export PXEMENU_DIR="${TFTP_ROOT_DIR}/pxelinux.cfg"
export UEFIMENU_DIR="${NGINX_ROOT_DIR}/ipxe"
export IPXEMENU_DIR="${NGINX_ROOT_DIR}/ipxe"

export TFTP_UEFI_DIR="${TFTP_ROOT_DIR}/uefi"

export TFTP_GRUB_DIR="${TFTP_ROOT_DIR}/grub"
export TFTP_GRUB2_DIR="${TFTP_ROOT_DIR}/grub2"

export DEFAULT_HTTP_PROXY='http://internet.ford.com:83'
export DEFAULT_NO_PROXY='localhost,127.0.0.1,.ford.com,.local,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16'

## Detect HTTP Proxy
echo "Detecting HTTP proxy"
set +e
HTTP_CODE=$( \
    curl \
    --head \
    --insecure \
    --location \
    --silent \
    --show-error \
    --fail \
    --output /dev/null \
    --write-out "%{http_code}" \
    --connect-timeout 10 \
    --proxy ${DEFAULT_HTTP_PROXY} \
    https://google.com
)
if [ "$HTTP_CODE" = "200" ]; then
    export http_proxy="${DEFAULT_HTTP_PROXY}"
    export HTTP_PROXY="${DEFAULT_HTTP_PROXY}"
    export https_proxy="${DEFAULT_HTTP_PROXY}"
    export HTTPS_PROXY="${DEFAULT_HTTP_PROXY}"
    export no_proxy="${DEFAULT_NO_PROXY}"
    export NO_PROXY="${DEFAULT_NO_PROXY}"
else
    export http_proxy=""
    export HTTP_PROXY=""
    export https_proxy=""
    export HTTPS_PROXY=""
    export no_proxy=""
    export NO_PROXY=""
fi
set -e