#!/usr/bin/env bash

set -o errexit
set -o nounset
set -o pipefail

export PATH="/usr/local/bin:$PATH"

export HOST_SHARE_PATH='/mnt/hgfs/share'
export HOST_ISO_PATH='/mnt/hgfs/iso'

source ${HOST_SHARE_PATH}/prov-scripts/common.sh

export SERVER_PROFILE="$HOST_SHARE_PATH/${INVENTORY_FILE}"

## Override the ISO_ROOT_URL if its avilable on the host
if [ -d ${HOST_ISO_PATH} ]; then
	ISO_ROOT_URL="file://${HOST_ISO_PATH}"
fi

## Set up directories
echo "Configuring base directories"
mkdir -p \
	${PXE_ROOT_DIR} ${NGINX_ROOT_DIR} ${TFTP_ROOT_DIR} \
	${OS_DIST_DIR} ${PXELINUX_DIR} ${PXEMENU_DIR} \
	${UEFIMENU_DIR} ${TFTP_UEFI_DIR} ${IPXEMENU_DIR} \
	${TFTP_GRUB_DIR} ${TFTP_GRUB2_DIR}

# Create pxe config dir
echo "Copying PXE skeleton directory"
mkdir -p ${PXE_ROOT_DIR}
#echo yes | cp -r ${PXE_ROOT_DIR_SKEL}/* ${PXE_ROOT_DIR}/
rsync -rt ${PXE_ROOT_DIR_SKEL}/ ${PXE_ROOT_DIR}/

if [[ ${OCP_NUM_WORKER} -eq 0 ]]; then
	mv ${PXE_ROOT_DIR}/haproxy/haproxy.cfg ${PXE_ROOT_DIR}/haproxy/haproxy-bkp.cfg
	mv ${PXE_ROOT_DIR}/haproxy/haproxy-aio.cfg ${PXE_ROOT_DIR}/haproxy/haproxy.cfg
fi

## Download IPXE chainloader
echo "Download IPXE chainloader"
declare -a ipxe_bins=(\
	${IPXE_ROOT_URL}/ipxe.iso \
	${IPXE_ROOT_URL}/ipxe.dsk \
	${IPXE_ROOT_URL}/ipxe.usb \
	${IPXE_ROOT_URL}/ipxe.efi \
	${IPXE_ROOT_URL}/ipxe.pxe \
	${IPXE_ROOT_URL}/ipxe.lkrn \
	${IPXE_ROOT_URL}/undionly.kpxe \
	${IPXE_ROOT_URL}/snponly.efi
)

for ipxe_bin in "${ipxe_bins[@]}"; do
	binary="${ipxe_bin##*/}"
	if [ ! -f ${TFTP_ROOT_DIR}/${binary} ]; then
		echo "Downloading ${binary} from ${ipxe_bin%/*} ..."
		curl \
			--connect-timeout 20 \
			--retry 5 \
			--retry-delay 0 \
			--retry-max-time 60 \
			--insecure \
			--progress-bar \
			--location \
			--output ${TFTP_ROOT_DIR}/${binary} \
			${ipxe_bin}
	fi
done

NTP_UPDATE_REQUIRED=false
NTP_STRING='pool pool.ntp.org iburst minpoll 6 maxpoll 10'

if [ ! -z "${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}" ]; then
	NTP_STRING='server time.ford.com iburst minpoll 6 maxpoll 10'
fi

if ! grep -q "^${NTP_STRING}$" /etc/chrony.conf; then
	NTP_UPDATE_REQUIRED=true
fi

if [ ${NTP_UPDATE_REQUIRED} ]; then
	if [ $(systemctl is-active chronyd) = "active" ]; then
		systemctl stop chronyd >/dev/null
	fi

	## Comment out the Red Hat default NTP pool
	sed -i '/^pool 2.rhel.pool.ntp.org iburst$/s/^/#/g' /etc/chrony.conf

	## Delete existing configs
	sed -Ei "/^(server|pool) .*$/d" /etc/chrony.conf

	## Add new configs
	sed -i "4s/^/${NTP_STRING}\n/" /etc/chrony.conf

	if ! systemctl is-active chronyd >/dev/null; then
		systemctl enable chronyd >/dev/null || true
		systemctl start chronyd >/dev/null
	fi
fi

function extract_iso() {
	local iso_src=$1
	local extract_to=$2

	umount /mnt/iso > /dev/null 2>&1 || true
	mkdir -p /mnt/iso
	mount -o loop,ro -t iso9660 ${iso_src} /mnt/iso
	mkdir -p ${extract_to}
	#https://superuser.com/a/547166
	#cp -ruv /mnt/iso/* ${extract_to}/
	rsync -rtv /mnt/iso/ ${extract_to}/
	umount /mnt/iso
}

function build_ipxe_menu(){
	local IPXE_MENU_PATH=$1

		## iPXE chainloader
		## DOCS:
		##  https://ipxe.org/docs
		##  http://ipxe.org/howto/chainloading
		##  http://ipxe.org/appnote/buildtargets
		## Refs:
		##  https://github.com/and3rsonlu1z/bind-dhcp/blob/master/entrypoint.sh#L72
		##  https://github.com/antonym/netboot.xyz/blob/master/src/rhel.ipxe
		##  https://github.com/oxedions/bluebanquise/tree/master/roles/pxe_stack/templates
		##  https://github.com/donnielee/razor-server/blob/master/pxeserver/bootstrap.ipxe
		#kernel ${PXE_SERVER_ADDRESS}/dist/rhel8/media/images/pxeboot/vmlinuz inst.repo=${PXE_SERVER_ADDRESS}/dist/rhel8/media/ \${console} BOOTIF=${MAC} ip=dhcp ipv6.disable initrd=initrd.img devfs=nomount ks=${PXE_SERVER_ADDRESS}/dist/rhel8/ks/${MACDASH}.cfg
		cat > "${IPXE_MENU_PATH}" <<-HEREEND
		#!ipxe

		# Set graphics mode and configure colours
		#console --x 800 --y 600 --picture http://10.10.0.1/texture.png #--left 32 --right 32 --top 32 --bottom 48
		#console --picture http://${next-server}/riddick.png

		# The number of tries made to obtain DHCP configuration to date, and the
		# maximum number to make before we give up.  Each time DHCP failed we will
		# sleep one secord per attempt already made, starting at one second, and
		# ramping up as we go.
		set tries:uint32    0
		set maxtries:uint32 60

		:retry

		###################### MAIN MENU ####################################

		# Some menu defaults
		set menu-timeout 10000
		set submenu-timeout \${menu-timeout}
		isset \${menu-default} || set menu-default bootosdeploy
		set esc:hex 1b
		set bold \${esc:string}[1m
		set orange \${esc:string}[33;0m
		set yellow \${esc:string}[33;1m
		set cyan \${esc:string}[36;1m
		set resetfg \${esc:string}[39m
		set resetbg \${esc:string}[49m
		set resetbold \${esc:string}[22m
		set reset \${esc:string}[0m

		# Figure out if client is 64-bit capable
		cpuid --ext 29 && set arch x86_64 || set arch x86
		cpuid --ext 29 && set archb 64 || set archb 32
		cpuid --ext 29 && set archl x86_64 || set archl i386

		:start
		menu iPXE boot menu for \${manufacturer} \${product} (\${archb}bit)
		item --gap                Main boot
		item bootosdeploy         Deploy OS (This will deploy/redeploy operating system)
		item bootdisk             Boot on disk (This will boot on local disk)
		#item --gap                Tools
		#item minimal_live_linux   Minimal Live Linux
		#item memtest              Memtest (To check Memory)
		item --gap                Other
		item startshell           iPXE shell (Go to an iPXE shell)
		item showinfo             Display system infos
		choose --timeout \${menu-timeout} --default \${menu-default} selected || goto cancel
		set menu-timeout 0
		goto \${selected}

		############ MAIN MENU ITEMS ############

		:startshell
		echo Type 'exit' to get the back to the menu.
		shell
		set menu-timeout 0
		set submenu-timeout 0
		goto start

		:showinfo
		echo
		echo +---------------- System information ----------------+
		echo |
		echo | platform:     \${platform}
		echo | hostname:     \${hostname}
		echo | mac:          \${net0/mac}
		echo | mac:          \${mac:hexhyp}
		echo | ip:           \${net0.dhcp/ip:ipv4}
		echo | netmask:      \${net0.dhcp/netmask:ipv4}
		echo | dhcp-server:  \${net0.dhcp/dhcp-server:ipv4}
		echo | gateway:      \${net0.dhcp/gateway:ipv4}
		echo | dns-server:   \${net0.dhcp/dns:ipv4}
		echo | domain:       \${net0.dhcp/domain:string}
		echo | next-server:  \${net0.dhcp/next-server:ipv4}
		echo |
		echo +----------------------------------------------------+
		echo
		prompt Press any key to continue
		set menu-timeout 0
		set submenu-timeout 0
		goto start

		:bootdisk
		iseq \${platform} efi && goto bootdisk-efi || goto bootdisk-legacy

		:bootdisk-legacy
		echo Booting on disk in legacy bios way
		sleep 2
		sanboot --no-describe --drive 0x80 || shell
		exit

		:bootdisk-efi
		echo Booting on disk in EFI way
		exit 1

		:error
		iseq \${tries} \${maxtries} && goto failed
		inc tries
		sleep \${tries}
		goto retry

		:failed
		echo failed to obtain DHCP data after \${tries} attempts, giving up.
		sleep 60
		reboot

		HEREEND
}

function configure_dhcp() {
	echo "  DHCP configurations"
	local ifaces=($(ip link show | grep -v link | awk {'print $2'} | sed 's/://g' | grep -v lo))
	local interface0="${ifaces[0]}"
	local dnsip=$(nmcli dev show ${interface0} | grep 'IP4.DNS\[1\]:' | awk '{ print $2}')
	local gwip=$(nmcli dev show ${interface0} | grep 'IP4.GATEWAY:' | awk '{ print $2}')

	sed -i "s/__DNS_SERVER_IPS__/${dnsip}/g" ${PXE_ROOT_DIR}/dhcp/conf/dhcpd.conf
	sed -i "s/__GATEWAY_IP__/${gwip}/g" ${PXE_ROOT_DIR}/dhcp/conf/dhcpd.conf

	## TODO: Is there a better way to accomplish this?
	## Generate host entries from DHCP config
	local DHCP_HOST_ENTRY=''
	for s in $(/usr/local/bin/jq --raw-output 'keys | .[] | tostring' ${SERVER_PROFILE}); do
		local MAC=$(/usr/local/bin/jq --raw-output --arg ARG "${s}" '.[$ARG].mac' ${SERVER_PROFILE})
		local IP=$(/usr/local/bin/jq --raw-output --arg ARG "${s}" '.[$ARG].ip' ${SERVER_PROFILE})
		local FQDN="${s}.$(/usr/local/bin/jq --raw-output --arg ARG "${s}" '.[$ARG].domain' ${SERVER_PROFILE})"
		## NOTE: Empty lines are required, not remove
		DHCP_HOST_ENTRY+=$(cat <<-HEREDOC


			host ${s} {
			    hardware ethernet ${MAC};
			    fixed-address     ${IP};
			    option host-name "${FQDN}";
			}
			HEREDOC
		)
	done
	echo "${DHCP_HOST_ENTRY}" >> ${PXE_ROOT_DIR}/dhcp/conf/dhcpd.conf
}

function prepare_rhel8() {
	echo "Seeding RHEL 8 ..."
	local IMAGE_DIR="${TFTP_ROOT_DIR}/images/RHEL-8.0"
	local INSTALL_MEDIA_DIR="${OS_DIST_DIR}/rhel8/media"
	local ANSWSER_DIR="${OS_DIST_DIR}/rhel8/ks"
	local ANSWSER_FILE_TEMPLATE="${ANSWSER_DIR}/ks.cfg"
	local ISO_DIR="${OS_DIST_DIR}/rhel8/iso"
	local ISO_SRC="${ISO_ROOT_URL}/rhel/rhel-8.0-x86_64-dvd.iso"
	local ISO_DST="${ISO_DIR}/rhel-8.0-x86_64-dvd.iso"

	mkdir -p ${INSTALL_MEDIA_DIR} ${ANSWSER_DIR} ${ISO_DIR} ${IMAGE_DIR}

	if [[ ${ISO_SRC} =~ ^file://.* ]]; then
		SRC=$(echo ${ISO_SRC} | sed "s~file://~~g")
		rsync -rt --progress ${SRC} ${ISO_DIR}/
	fi

	if [ ! -f ${ISO_DST} ]; then
		echo "  Download ISO"
		curl \
			--connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
			--retry "${CURL_RETRY:-5}" \
			--retry-delay "${CURL_RETRY_DELAY:-0}" \
			--retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
			--insecure \
			--progress-bar \
			--location \
			--output ${ISO_DST} \
			${ISO_SRC}
	fi

	echo "  Extract ISO"
	if [ ! -f ${ISO_DST} ]; then
		echo "ERROR: Missing ISO '${ISO_DST}'"
	fi
	extract_iso ${ISO_DST} ${INSTALL_MEDIA_DIR}

	# https://github.com/choopsit/bashit/blob/master/primal_servers/pxe.sh
	# https://github.com/tenfourty/tenfourty-infrastructure-mgmt/blob/master/files/qnap/pxelinux/pxelinux.cfg/x86_64_Servers
	# https://github.com/mikefrostov/infrastructure_scripts/blob/master/vmscripts/pxe_tftpd_install.sh

	for row in $(/usr/local/bin/jq --raw-output 'to_entries[] | select (.value.os=="rhel8") | "\(.key),\(.value.mac),\(.value.cpu),\(.value.memory),\(.value.disk),\(.value.ip),\(.value.prefix),\(.value.gateway),\(.value.net),\(.value.iface),\(.value.firmware),\(.value.domain)"' ${SERVER_PROFILE}); do
		local HOSTNAME=$(echo $row | cut -f1 -d',')
		local MAC="$(echo $row | cut -f2 -d',' | tr '[:upper:]' '[:lower:]')"
		local MACDASH="$(echo ${MAC} | tr ':' '-' )"
		local MACMENU=$(echo "01-${MACDASH}")
		local CPU=$(echo $row | cut -f3 -d',')
		local MEMORY=$(echo $row | cut -f4 -d',')
		local DISK=$(echo $row | cut -f5 -d',')
		local IP=$(echo $row | cut -f6 -d',')
		local PREFIX=$(echo $row | cut -f7 -d',')
		local GATEWAY=$(echo $row | cut -f8 -d',')
		local NET=$(echo $row | cut -f9 -d',')
		local IFACE=$(echo $row | cut -f10 -d',')
		local FIRMWARE=$(echo $row | cut -f11 -d',')
		local DOMAIN=$(echo $row | cut -f12 -d',')

		echo "  Generate iPXE Menu for ${HOSTNAME}"

		## iPXE Menu
		build_ipxe_menu "${IPXEMENU_DIR}/$MACDASH"

		## Append OS Specific boot config to iPXE Menu
		cat >> "${IPXEMENU_DIR}/$MACDASH" <<-HEREEND
		:bootosdeploy
		#chain http://\${net0.dhcp/next-server:ipv4}/preboot_execution_environment/nodes/\${hostname}_bootosdeploy.ipxe || shell
		echo next-server: \${next-server}
		echo hostname: \${hostname}
		set console console=ttyS1,115200n8
		set server_root ${PXE_SERVER_ADDRESS}/dist/rhel8/media
		kernel \${server_root}/images/pxeboot/vmlinuz repo=\${server_root}/ BOOTIF=${MAC} ip=dhcp ipv6.disable initrd=initrd.img devfs=nomount ks=${PXE_SERVER_ADDRESS}/dist/rhel8/ks/${MACDASH}.cfg
		initrd \${server_root}/images/pxeboot/initrd.img
		#md5sum vmlinuz initrd.img
		boot || shell

		HEREEND

		#kernel http://10.0.12.1/sw/linux root=/dev/ram0 load_ramdisk=1 initrd=initrd showopts ramdisk_size=65535  install=http://10.0.12.1/sw/iso textmode=1 autoyast=http://10.0.12.1/sw/baremetal.php?MAC=00:50:56:9a:00:1d
		#initrd http://10.0.12.1/sw/initrd

		echo "  Generate kickstat file"
		local ADMIN_PASSWORD=$(python -c 'import crypt; print(crypt.crypt("P@ssw0rd", crypt.mksalt(crypt.METHOD_SHA512)))')
		local SSHKEY="${HOST_SHARE_PATH}/artifacts/ssh/${HOSTNAME}"
		mkdir -p ${HOST_SHARE_PATH}/artifacts/ssh
		if [ ! -f ${SSHKEY} ]; then
			ssh-keygen -t rsa -b 4096 -f ${SSHKEY} -N '' -C "${HOSTNAME} server admin user" > /dev/null 2>&1
		fi
		local ADMIN_SSH_PUBLIC_KEY=$(cat ${SSHKEY}.pub)
		local ANSWSER_FILE="${ANSWSER_DIR}/${MACDASH}.cfg"
		cp ${ANSWSER_FILE_TEMPLATE} ${ANSWSER_FILE}
		if [ "${FIRMWARE}" = "efi" ]; then
			sed -i "s~__CREATE_EFI_PARTITION__~part /boot/efi --fstype=efi --size=1024 --ondisk=sda~g" ${ANSWSER_FILE}
		else
			sed -i "/^__CREATE_EFI_PARTITION__/d" ${ANSWSER_FILE}
		fi
		sed -i "s~__ADMIN_PASSWORD__~${ADMIN_PASSWORD}~g" ${ANSWSER_FILE}
		sed -i "s~__ADMIN_SSH_PUBLIC_KEY__~${ADMIN_SSH_PUBLIC_KEY}~g" ${ANSWSER_FILE}
		sed -i "s~__DOWNLOAD_SERVER__~${PXE_SERVER_ADDRESS}/dist~g" ${ANSWSER_FILE}
		sed -i "s~__HOSTNAME__~${HOSTNAME}.${DOMAIN}~g" ${ANSWSER_FILE}
	done
}

function prepare_rhcos() {
	local CLUSTER_NAME=$1

	local MEDIA_DIR="${OS_DIST_DIR}/rhcos/media"
	local IGN_DIR="${OS_DIST_DIR}/rhcos/ign"
	local ISO_DIR="${OS_DIST_DIR}/rhcos/iso"

	local OPENSHIFT_CLUSTER_DEF="${HOST_SHARE_PATH}/clusters/${CLUSTER_NAME}"
	local OPENSHIFT_PULL_SECRET="${HOST_SHARE_PATH}/secrets/ocp4.secret"

	local BASE_URL="${ISO_ROOT_URL}/openshift-v${OPENSHIFT_MAJ_VERSION}"

	if [ -d "${HOST_ISO_PATH}/openshift-v${OPENSHIFT_MAJ_VERSION}" ]; then
		BASE_URL="${ISO_ROOT_URL}/openshift-v${OPENSHIFT_MAJ_VERSION}"
	fi
	local RHCOS_BASE_URL="${BASE_URL}/dependencies/rhcos/${RHCOS_MAJ_MIN_VERION}/${RHCOS_VERSION}"
	local INSTALLER_BASE_URL="${BASE_URL}/clients/ocp/${OPENSHIFT_INSTALLER_VERSION}"

	local SSHKEY_DIR="${HOST_SHARE_PATH}/artifacts/ssh"
	local SSHKEY_FILE="${SSHKEY_DIR}/core"

	local RHCOS_SUFFIX='-x86_64'
	if [ "${RHCOS_MAJ_MIN_VERION}" = "4.2" ]; then
		RHCOS_SUFFIX=''
		RHCOS_VERSION=${RHCOS_REAL_VERSION}
	fi

	echo "Seeding RHCOS ..."
	mkdir -p ${MEDIA_DIR} ${IGN_DIR} ${ISO_DIR}

	if [ ! -f "${OPENSHIFT_PULL_SECRET}" ]; then
		echo -e "ERROR: Missing 'pull secret' in ${OPENSHIFT_PULL_SECRET}"
		exit 1
	fi

	## Download and install openshift-install utility
	echo "  Download and install openshift-install utility"
	mkdir -p ${OPENSHIFT_CLUSTER_DEF}

	if [ -f "/usr/local/bin/openshift-install" ]; then
		if ! /usr/local/bin/openshift-install version | head -n 1 | grep -q v${OPENSHIFT_INSTALLER_VERSION}; then
			rm -rf "/usr/local/bin/openshift-install"
		fi
	fi

	if [ -f "/usr/local/bin/openshift-install" ]; then
		if ! /usr/local/bin/oc version --short | grep -q v${OPENSHIFT_INSTALLER_VERSION}; then
			rm -rf "/usr/local/bin/oc"
		fi
	fi

	if [ ! -f "/usr/local/bin/openshift-install" ] || [ ! -f "/usr/local/bin/oc" ]; then
		rm -rf /tmp/ocp4
		mkdir -p /tmp/ocp4
		pushd /tmp/ocp4 > /dev/null 2>&1

		curl \
			--connect-timeout 20 \
			--retry 5 \
			--retry-delay 0 \
			--retry-max-time 60 \
			--insecure \
			--progress-bar \
			--location \
			--output sha256sum.txt \
			${INSTALLER_BASE_URL}/sha256sum.txt

		echo "Downloading openshift-install v${OPENSHIFT_INSTALLER_VERSION}"
		curl \
			--connect-timeout 20 \
			--retry 5 \
			--retry-delay 0 \
			--retry-max-time 60 \
			--insecure \
			--progress-bar \
			--location \
			--output openshift-install-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz \
			${INSTALLER_BASE_URL}/openshift-install-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz

		echo "Downloading oc v${OPENSHIFT_INSTALLER_VERSION}"
		curl \
			--connect-timeout 20 \
			--retry 5 \
			--retry-delay 0 \
			--retry-max-time 60 \
			--insecure \
			--progress-bar \
			--location \
			--output openshift-client-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz \
			${INSTALLER_BASE_URL}/openshift-client-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz

		echo "Installing openshift-install v${OPENSHIFT_INSTALLER_VERSION}"
		SHASUM=$(grep -i ".*openshift-install-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz$" sha256sum.txt | cut -d ' ' -f1)
		echo "${SHASUM} openshift-install-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz" | sha256sum -c - > /dev/null 2>&1
		tar -zxvf openshift-install-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz -C /tmp/ocp4 > /dev/null 2>&1
		mv /tmp/ocp4/openshift-install /usr/local/bin/
		chmod +x /usr/local/bin/openshift-install

		echo "Installing oc v${OPENSHIFT_INSTALLER_VERSION}"
		SHASUM=$(grep -i ".*openshift-client-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz$" sha256sum.txt | cut -d ' ' -f1)
		echo "${SHASUM} openshift-client-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz" | sha256sum -c - > /dev/null 2>&1
		tar -zxvf openshift-client-linux-${OPENSHIFT_INSTALLER_VERSION}.tar.gz -C /tmp/ocp4 > /dev/null 2>&1
		mv /tmp/ocp4/oc /usr/local/bin/
		chmod +x /usr/local/bin/oc

		popd > /dev/null 2>&1
		rm -rf /tmp/ocp4
	fi

	## Create SSH key for 'core' user in RHCOS
	## DOCS: https://docs.openshift.com/container-platform/4.1/installing/installing_bare_metal/installing-bare-metal.html#ssh-agent-using_installing-bare-metal
	echo "  Create SSH key for 'core' user in RHCOS"
	mkdir -p ${SSHKEY_DIR}
	if [ ! -f ${SSHKEY_FILE} ]; then
		ssh-keygen -t rsa -b 4096 -f ${SSHKEY_FILE} -N '' -C "core user" > /dev/null 2>&1
	fi

	## Create a symbolic link for each server in OpenShift
	## DOCS: https://www.ssh.com/ssh/add
	eval "$(ssh-agent -s)"
	for s in $(/usr/local/bin/jq --raw-output '. as $object | keys[] | select($object[.].os == "rhcos") | tostring' ${SERVER_PROFILE}); do
		ln -sf ${SSHKEY_FILE} ${SSHKEY_DIR}/${s}
		ssh-add ${SSHKEY_DIR}/${s}
	done

	## Download RHCOS install media
	rm -rf /tmp/rhcos_sha256sum.txt
	if [ ! -f /tmp/rhcos_sha256sum.txt ]; then
		curl \
			--connect-timeout 20 \
			--retry 5 \
			--retry-delay 0 \
			--retry-max-time 60 \
			--insecure \
			--progress-bar \
			--location \
			--output /tmp/rhcos_sha256sum.txt \
			${RHCOS_BASE_URL}/sha256sum.txt
	fi
	for line in $(cat /tmp/rhcos_sha256sum.txt | awk '{print $1 "," $2}'); do
		local SHA256SUM=$(echo $line | awk -F "," '{print $1}')
		local BINARY=$(echo $line | awk -F "," '{print $2}')
		local OUTPUT_FILE_PATH=''

		if [[ ${BINARY} =~ (\.vmdk|\.tar|\.qcow2|\.vhd|\.ova)$ ]]; then
			continue
		elif [[ ${BINARY} =~ (\.iso|\.ova)$ ]]; then
			OUTPUT_FILE_PATH=${ISO_DIR}/${BINARY}
		else
			OUTPUT_FILE_PATH=${MEDIA_DIR}/${BINARY}
		fi

		if [[ ${RHCOS_BASE_URL} =~ ^file://.* ]]; then
				SRC=$(echo ${RHCOS_BASE_URL} | sed "s~file://~~g")
				rsync -rt --progress \
					--exclude '*.iso' --exclude '*.ova' \
					--exclude '*.vmdk' --exclude '*.tar' \
					--exclude '*.qcow2' --exclude '*.vhd' \
					${SRC}/ ${MEDIA_DIR}/

				rsync -rt --progress  --include '*.iso' \
					--exclude '*.ova' --exclude '*.vmdk' \
					--exclude '*.tar' --exclude '*.qcow2' \
					--exclude '*.vhd' --exclude '*.img' \
					--exclude '*.raw.gz' --exclude '*.installer-kernel' \
					${SRC}/ ${ISO_DIR}/
		elif [ ! -f ${OUTPUT_FILE_PATH} ]; then
			curl \
				--connect-timeout 20 \
				--retry 5 \
				--retry-delay 0 \
				--retry-max-time 60 \
				--insecure \
				--progress-bar \
				--location \
				--output ${OUTPUT_FILE_PATH} \
				${RHCOS_BASE_URL}/${BINARY}
			## Check the checksum of the binary
			echo "${SHA256SUM} ${OUTPUT_FILE_PATH}" | sha256sum -c -
		fi
	done
	rm -rf /tmp/rhcos_sha256sum.txt

	## DOCS:
	##  openshift-install create install-config --dir ocp4_$(date +%Y%m%d) --log-level debug
	##  https://docs.openshift.com/container-platform/4.1/installing/installing_bare_metal/installing-bare-metal.html#installation-bare-metal-config-yaml_installing-bare-metal
	##  https://cloud.redhat.com/openshift/install/metal/user-provisioned
	##	https://github.com/openshift/installer/blob/master/docs/dev/proxy.md
	##	https://github.com/openshift/installer/blob/master/pkg/asset/manifests/proxy.go#L97
	##	https://github.com/openshift/installer/pull/1832/files
	##	https://godoc.org/github.com/openshift/installer/pkg/types#InstallConfig
	##	https://docs.openshift.com/container-platform/4.1/telemetry/opting-out-of-telemetry.html

	## OPENSHIFT_INSTALL_RELEASE_IMAGE_OVERRIDE

	## Generate cluster definition
	echo "  Generate openshift cluster definition"
	if [ -d "${OPENSHIFT_CLUSTER_DEF}" ]; then
		rm -rf "${OPENSHIFT_CLUSTER_DEF}"
	fi
	mkdir -p "${OPENSHIFT_CLUSTER_DEF}"
	INSTALL_CONFIG="${OPENSHIFT_CLUSTER_DEF}/install-config.yaml"
	cat > "${INSTALL_CONFIG}" <<-EOF
	apiVersion: v1
	## The base domain of the cluster.All DNS records will be sub-domains
	## of this base and will also include the cluster name.
	baseDomain: ${OCP_TLD}
	proxy:
	  httpsProxy: "${http_proxy}"
	  httpProxy: "${http_proxy}"
	  noProxy: "${no_proxy}"
	compute:
	- hyperthreading: Enabled
	  name: worker
	  replicas: ${OCP_NUM_WORKER}
	controlPlane:
	  hyperthreading: Enabled
	  name: master
	  replicas: ${OCP_NUM_MASTER}
	metadata:
	  name: ${CLUSTER_NAME}
	networking:
	  clusterNetworks:
	  - cidr: ${OPENSHIFT_POD_CIDR}
	    hostPrefix: ${OPENSHIFT_HOSTPREFIX}
	  networkType: ${OPENSHIFT_SDN_PROVIDER}
	  serviceNetwork:
	  - ${OPENSHIFT_SERVICE_CIDR}
	platform:
	  none: {}
	pullSecret: '$(cat ${OPENSHIFT_PULL_SECRET})'
	## The default SSH key that will be programmed for core user.
	sshKey: '$(cat ${SSHKEY_FILE}.pub)'
	EOF
	if [ -z "${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}" ]; then
		yq delete --inplace ${INSTALL_CONFIG} proxy
	fi
	cp -rf ${INSTALL_CONFIG} ${INSTALL_CONFIG}.txt

	## Cluster Customization
	## DOCS: https://github.com/openshift/installer/blob/master/docs/user/customization.md
	/usr/local/bin/openshift-install --dir=${OPENSHIFT_CLUSTER_DEF} --log-level=info create manifests

	## https://github.com/code-ready/snc/blob/master/99_master-kubelet-no-taint.yaml
	## https://github.com/code-ready/snc/blob/master/snc.sh#L156-L166
	## https://github.com/openshift/installer/blob/master/docs/user/customization.md#control-plane-with-no-taints
	## https://github.com/openshift/machine-config-operator/blob/master/templates/master/01-master-kubelet/_base/units/kubelet.yaml
	#if [[ ${OCP_NUM_WORKER} -eq 0 ]]; then
	#	cat > ${OPENSHIFT_CLUSTER_DEF}/openshift/99-master-kubelet-no-taint.yaml <<-'EOF'
	#	apiVersion: machineconfiguration.openshift.io/v1
	#	kind: MachineConfig
	#	metadata:
	#	  labels:
	#	    machineconfiguration.openshift.io/role: master
	#	  name: 02-master-kubelet
	#	spec:
	#	  config:
	#	    ignition:
	#	      version: 2.2.0
	#	    systemd:
	#	      units:
	#	      - contents: |
	#	          [Unit]
	#	          Description=Kubernetes Kubelet
	#	          Wants=rpc-statd.service
	#	          [Service]
	#	          Type=notify
	#	          ExecStartPre=/bin/mkdir --parents /etc/kubernetes/manifests
	#	          ExecStartPre=/bin/rm -f /var/lib/kubelet/cpu_manager_state
	#	          EnvironmentFile=-/etc/kubernetes/kubelet-workaround
	#	          EnvironmentFile=-/etc/kubernetes/kubelet-env
	#	          ExecStart=/usr/bin/hyperkube \
	#	              kubelet \
	#	                --config=/etc/kubernetes/kubelet.conf \
	#	                --bootstrap-kubeconfig=/etc/kubernetes/kubeconfig \
	#	                --rotate-certificates \
	#	                --kubeconfig=/var/lib/kubelet/kubeconfig \
	#	                --container-runtime=remote \
	#	                --container-runtime-endpoint=/var/run/crio/crio.sock \
	#	                --allow-privileged \
	#	                --node-labels=node-role.kubernetes.io/master,node.openshift.io/os_id=${ID} \
	#	                --minimum-container-ttl-duration=6m0s \
	#	                --client-ca-file=/etc/kubernetes/ca.crt \
	#	                --cloud-provider= \
	#	                --volume-plugin-dir=/etc/kubernetes/kubelet-plugins/volume/exec \
	#	                \
	#	                --anonymous-auth=false \
	#	                --v=3 \
	#	          Restart=always
	#	          RestartSec=10
	#	          [Install]
	#	          WantedBy=multi-user.target
	#	        enabled: true
	#	        name: kubelet.service
	#	EOF
	#fi

	## ADD Calico/Tigera customization
	## DOCS: https://github.com/tigera/customer-ford/blob/master/openshiftv4/docs/tech-preview.md
	if [ "${OPENSHIFT_SDN_PROVIDER}" = "Calico" ]; then
		local TIGERA_PULL_SECRET="${HOST_SHARE_PATH}/secrets/tigera.secret"
		if [ ! -f "${TIGERA_PULL_SECRET}" ]; then
			echo "Missing tigera pull secret"
			exit 1
		fi
		local DOCKER_CFG_ENC=$(cat "${TIGERA_PULL_SECRET}" | tr -d '\n\r\t ' | base64 -w 0)
		cp -f ${HOST_SHARE_PATH}/tigera/hack/calico/* ${OPENSHIFT_CLUSTER_DEF}/manifests/
		cp -f ${HOST_SHARE_PATH}/tigera/hack/tsee/* ${OPENSHIFT_CLUSTER_DEF}/manifests/
		sed -i "s~DOCKER_CFG~${DOCKER_CFG_ENC}~" ${OPENSHIFT_CLUSTER_DEF}/manifests/02-ps*.yaml
	fi

	# Save the snapshot of cluster defs after manifest generation
	cp -r ${OPENSHIFT_CLUSTER_DEF} ${OPENSHIFT_CLUSTER_DEF}.stage1

	## Run cluster target to create the cluster using the custom manifests - only works with terraform
	#openshift-install --dir=${OPENSHIFT_CLUSTER_DEF} --log-level=info create cluster

	## Generate cluster ignition files
	echo "  Generate cluster configurations"
	/usr/local/bin/openshift-install --dir=${OPENSHIFT_CLUSTER_DEF} --log-level=info create ignition-configs

	## STEP 6: Generate iPXE Menu
	for row in $(/usr/local/bin/jq --raw-output 'to_entries[] | select (.value.os=="rhcos") | "\(.key),\(.value.mac),\(.value.cpu),\(.value.memory),\(.value.disk),\(.value.ip),\(.value.prefix),\(.value.gateway),\(.value.net),\(.value.iface),\(.value.firmware),\(.value.domain)"' ${SERVER_PROFILE}); do
		local HOSTNAME=$(echo $row | cut -f1 -d',')
		local MACDASH="$(echo $row | cut -f2 -d',' | tr '[:upper:]' '[:lower:]' | tr ':' '-' )"
		local MAC="$(echo $row | cut -f2 -d',' | tr '[:upper:]' '[:lower:]')"
		local CPU=$(echo $row | cut -f3 -d',')
		local MEMORY=$(echo $row | cut -f4 -d',')
		local DISK=$(echo $row | cut -f5 -d',')
		local IP=$(echo $row | cut -f6 -d',')
		local PREFIX=$(echo $row | cut -f7 -d',')
		local GATEWAY=$(echo $row | cut -f8 -d',')
		local NET=$(echo $row | cut -f9 -d',')
		local IFACE=$(echo $row | cut -f10 -d',')
		local FIRMWARE=$(echo $row | cut -f11 -d',')
		local DOMIAN=$(echo $row | cut -f12 -d',')
		local MACMENU=$(echo "01-${MACDASH}")

		local IGN_FILE_NAME="${HOSTNAME}.ign"
		local IGN_FILE_PATH="${IGN_DIR}/${HOSTNAME}.ign"
		local SOURCE_IGN_FILE_PATH=''

		if [[ ${HOSTNAME} =~ ^bootstrap$ ]]; then
			SOURCE_IGN_FILE_PATH="${OPENSHIFT_CLUSTER_DEF}/bootstrap.ign"
			cp ${SOURCE_IGN_FILE_PATH} ${IGN_FILE_PATH}
		elif [[ ${HOSTNAME} =~ ^master-[0-9]+$ ]]; then
			SOURCE_IGN_FILE_PATH="${OPENSHIFT_CLUSTER_DEF}/master.ign"
			cp ${SOURCE_IGN_FILE_PATH} ${IGN_FILE_PATH}
		elif [[ ${HOSTNAME} =~ ^worker-[0-9]+$ ]]; then
			SOURCE_IGN_FILE_PATH="${OPENSHIFT_CLUSTER_DEF}/worker.ign"
			cp ${SOURCE_IGN_FILE_PATH} ${IGN_FILE_PATH}
		fi

		## DOCS:
		## https://github.com/e-minguez/ocp4-upi-bm-pxeless-staticips/blob/master/docs/7-ignition-files.md
		## https://access.redhat.com/solutions/4175151
		## https://github.com/coreos/ignition/blob/spec2x/doc/configuration-v2_0.md
		## https://github.com/coreos/ignition/blob/master/doc/configuration-v3_0.md

		## Update ignition files to assign static IP
		## https://computingforgeeks.com/adding-a-secondary-ip-address-to-rhel-centos-8-network-interface/
		echo "  Patch ignition files ${HOSTNAME}"
		local NIC1="/tmp/${HOSTNAME}-ifcfg-${IFACE}"
		local NIC1_JSON="${NIC1}.json"
		cat > ${NIC1} <<- EOF
		NAME=${IFACE}
		DEVICE=${IFACE}
		TYPE="Ethernet"
		NM_CONTROLLED=yes
		BOOTPROTO=none
		ONBOOT=yes
		IPADDR=${IP}
		PREFIX=${PREFIX}
		GATEWAY=${GATEWAY}
		DEFROUTE=yes
		PEERDNS=no
		#PEERROUTES=no
		DNS1=${DEFAULT_DNS_SERVER}
		#DNS2=${DEFAULT_DNS_SERVER}
		IPV6INIT=no
		IPV6_AUTOCONF=no
		IPV6_DEFROUTE=no
		IPV6_FAILURE_FATAL=no
		PROXY_METHOD=none
		BROWSER_ONLY=no
		USERCTL=no
		EOF
		local NIC1_BASE64=$(cat ${NIC1} | base64 -w0)
		cat > "${NIC1_JSON}" <<- EOF
		{
		  "append" : false,
		  "mode" : 420,
		  "filesystem" : "root",
		  "path" : "/etc/sysconfig/network-scripts/ifcfg-${IFACE}",
		  "contents" : {
			"source" : "data:text/plain;charset=utf-8;base64,${NIC1_BASE64}",
			"verification" : {}
		  },
		  "user" : {
			"name" : "root"
		  },
		  "group": {
			"name": "root"
		  }
		}
		EOF

		## Default env variables available to all systemd units
		local DEFENV='/tmp/defenv'
		cat > ${DEFENV} <<- EOF
		[Manager]
		DefaultEnvironment=HTTP_PROXY="${http_proxy}"
		DefaultEnvironment=HTTPS_PROXY="${http_proxy}"
		DefaultEnvironment=NO_PROXY="${no_proxy}"
		DefaultEnvironment=http_proxy="${http_proxy}"
		DefaultEnvironment=https_proxy="${http_proxy}"
		DefaultEnvironment=no_proxy="${no_proxy}"
		EOF
		local DEFENV_BASE64=$(cat ${DEFENV} | base64 -w0)
		local DEFENV_JSON="${DEFENV}.json"
		cat > "${DEFENV_JSON}" <<- EOF
		{
		  "append" : false,
		  "mode" : 420,
		  "filesystem" : "root",
		  "path" : "/etc/systemd/system.conf.d/10-default-env.conf",
		  "contents" : {
			"source" : "data:text/plain;charset=utf-8;base64,${DEFENV_BASE64}",
			"verification" : {}
		  },
		  "user" : {
			"name" : "root"
		  },
		  "group": {
			"name": "root"
		  }
		}
		EOF

		local ETCENV='/tmp/etcenv'
		cat > ${ETCENV} <<- EOF
		HTTP_PROXY="${http_proxy}"
		HTTPS_PROXY="${http_proxy}"
		NO_PROXY="${no_proxy}"
		http_proxy="${http_proxy}"
		https_proxy="${http_proxy}"
		no_proxy="${no_proxy}"
		EOF
		local ETCENV_BASE64=$(cat ${ETCENV} | base64 -w0)
		local ETCENV_JSON="${ETCENV}.json"
		cat > "${ETCENV_JSON}" <<- EOF
		{
		  "append" : false,
		  "mode" : 420,
		  "filesystem" : "root",
		  "path" : "/etc/environment",
		  "contents" : {
			"source" : "data:text/plain;charset=utf-8;base64,${ETCENV_BASE64}",
			"verification" : {}
		  },
		  "user" : {
			"name" : "root"
		  },
		  "group": {
			"name": "root"
		  }
		}
		EOF

		## https://github.com/openshift/installer/pull/1832
		local ETCPROFILE='/tmp/profile'
		cat > ${ETCPROFILE} <<- EOF
		export HTTP_PROXY="${http_proxy}"
		export HTTPS_PROXY="${http_proxy}"
		export NO_PROXY="${no_proxy}"
		export http_proxy="${http_proxy}"
		export https_proxy="${http_proxy}"
		export no_proxy="${no_proxy}"
		EOF
		local ETCPROFILE_BASE64=$(cat ${ETCPROFILE} | base64 -w0)
		local ETCPROFILE_JSON="${ETCPROFILE}.json"
		cat > "${ETCPROFILE_JSON}" <<- EOF
		{
		  "append" : false,
		  "mode" : 420,
		  "filesystem" : "root",
		  "path" : "/etc/profile.d/proxy.sh",
		  "contents" : {
			"source" : "data:text/plain;charset=utf-8;base64,${ETCPROFILE_BASE64}",
			"verification" : {}
		  },
		  "user" : {
			"name" : "root"
		  },
		  "group": {
			"name": "root"
		  }
		}
		EOF

		local HNAME='/tmp/hname'
		local HNAME_JSON="${HNAME}.json"
		local HNAME_BASE64=$(echo "${HOSTNAME}.${DOMAIN}" | base64 -w0)
		cat > "${HNAME_JSON}" <<- EOF
		{
		  "append" : false,
		  "filesystem": "root",
		  "path": "/etc/hostname",
		  "contents": {
			"source": "data:text/plain;charset=utf-8;base64,${HNAME_BASE64}",
			"verification": {}
		  },
		  "mode": 420,
		  "user" : {
			"name" : "root"
		  },
		  "group": {
			"name": "root"
		  }
		}
		EOF

		local CHRONY='/tmp/chrony'
		cat > ${CHRONY} <<- EOF
		${NTP_STRING}

		# Record the rate at which the system clock gains/losses time.
		driftfile /var/lib/chrony/drift

		# Allow the system clock to be stepped in the first three updates
		# if its offset is larger than 1 second.
		makestep 1.0 3

		# Enable kernel synchronization of the real-time clock (RTC).
		rtcsync

		# Specify file containing keys for NTP authentication.
		keyfile /etc/chrony.keys

		# Get TAI-UTC offset and leap seconds from the system tz database.
		leapsectz right/UTC

		# Specify directory for log files.
		logdir /var/log/chrony
		EOF
		local CHRONY_BASE64=$(cat ${CHRONY} | base64 -w0)
		local CHRONY_JSON="${CHRONY}.json"
		cat > "${CHRONY_JSON}" <<- EOF
		{
		  "append" : false,
		  "filesystem": "root",
		  "path": "/etc/chrony.conf",
		  "contents": {
			"source": "data:text/plain;charset=utf-8;base64,${CHRONY_BASE64}",
			"verification": {}
		  },
		  "mode": 420,
		  "user" : {
			"name" : "root"
		  },
		  "group": {
			"name": "root"
		  }
		}
		EOF

		JQ_COMMAND_ADDTIONS=''
		#if [ ! -z "${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}" ]; then
		#	JQ_COMMAND_ADDTIONS="${DEFENV_JSON} ${ETCENV_JSON} ${ETCPROFILE_JSON}"
		#fi

		# ${HNAME_JSON} ${CHRONY_JSON} \
		mv ${IGN_FILE_PATH} ${IGN_FILE_PATH}.orig
		/usr/local/bin/jq '.storage.files += [inputs]' \
			${IGN_FILE_PATH}.orig \
			${NIC1_JSON} \
			${JQ_COMMAND_ADDTIONS} > ${IGN_FILE_PATH}

		rm -f ${IGN_FILE_PATH}.orig \
			${NIC1_JSON} ${NIC1} \
			${HNAME_JSON} \
			${DEFENV_JSON} ${DEFENV} \
			${ETCENV_JSON} ${ETCENV} \
			${ETCPROFILE_JSON} ${ETCPROFILE} \
			${CHRONY_JSON} ${CHRONY}

		NM_PATCH='/tmp/nmpatch.json'
		cat > "${NM_PATCH}" <<- EOF
		{
		"systemd": {
		   "units": [
		    {
		     "name": "NetworkManager-wait-online.service",
		     "dropins": [{
		       "name": "timeout.conf",
		       "contents": "[Service]\nExecStart=\nExecStart=/usr/bin/nm-online -s -q --timeout=300"
		     }]
		   }
		  ]
		 }
		}
		EOF

		USER_PATCH='/tmp/userpatch.json'
		cat > "${USER_PATCH}" <<- EOF
		{
		  "passwd": {
		    "users": [
		      {
		        "name": "core",
		        "sshAuthorizedKeys": [
		          "$(cat ${SSHKEY_FILE}.pub)"
		        ]
		      }
		    ]
		  }
		}
		EOF

		if [[ ${HOSTNAME} =~ ^master-[0-9]+$ ]] || [[ ${HOSTNAME} =~ ^worker-[0-9]+$ ]]; then
			echo "  Updating Master and Workers Ignition files with NetworkManager patch"
			mv ${IGN_FILE_PATH} ${IGN_FILE_PATH}.orig
			/usr/local/bin/jq -s '.[0] * .[1]' ${IGN_FILE_PATH}.orig ${NM_PATCH} > ${IGN_FILE_PATH}
			rm -rf ${IGN_FILE_PATH}.orig ${NM_PATCH}
			#echo "  Updating Master and Workers Ignition files with User patch"
			#mv ${IGN_FILE_PATH} ${IGN_FILE_PATH}.orig
			#/usr/local/bin/jq -s '.[0] * .[1]' ${IGN_FILE_PATH}.orig ${USER_PATCH} > ${IGN_FILE_PATH}
			#rm -rf ${IGN_FILE_PATH}.orig ${USER_PATCH}
		fi

		## Update ignition file to add a password
		#mv ${IGN_FILE_PATH} ${IGN_FILE_PATH}.orig
		#/usr/local/bin/jq '(.passwd.users | .[] | select (.name=="core").passwordHash) = "$6$a0dlAGGDEzUJM76x$YcoQyt3qxZV7ySCj2D..qFlLxtO4G9iirkdU5YWnHzmEZ5//neE0wctXq6jramT.4ahRlq2milSeH/XQslMim0"' ${IGN_FILE_PATH}.orig > ${IGN_FILE_PATH}

		## Parse cert
		#/usr/local/bin/jq --raw-output '.storage.files | .[] | select(.path=="/opt/openshift/tls/kube-apiserver-lb-server.key") | .contents.source' ${IGN_FILE_PATH} | cut -f2 -d',' | base64 --decode | openssl x509 -in /dev/stdin -text -noout

		## iPXE Menu
		build_ipxe_menu "${IPXEMENU_DIR}/$MACDASH"

		if [ "${FIRMWARE}" = "bios" ]; then
			IMAGE_TYPE='bios'
		elif [ "${FIRMWARE}" = "efi" ]; then
			IMAGE_TYPE='uefi'
		fi

		## Append OS Specific boot config to iPXE Menu
		## https://github.com/coreos/coreos-installer#test-a-pxe-based-install
		## https://github.com/e-minguez/ocp4-upi-bm-pxeless-staticips/blob/master/docs/9-modify-isos.md
		## https://cloud.redhat.com/openshift/install/metal/user-provisioned
		## https://docs.openshift.com/container-platform/4.1/installing/installing_bare_metal/installing-bare-metal.html#installation-user-infra-machines-pxe_installing-bare-metal
		## https://docs.openshift.com/container-platform/4.1/architecture/architecture-rhcos.html

		#kernel \${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer-kernel ip=dhcp rd.neednet=1 initrd=\${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer-initramfs.img console=tty0 console=ttyS0 coreos.inst=yes coreos.inst.install_dev=sda coreos.inst.image_url=\${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-metal-${IMAGE_TYPE}.raw.gz coreos.inst.ignition_url={PXE_SERVER_ADDRESS}/dist/rhcos/ign/${IGN_FILE_NAME} ip=eno1:dhcp
		echo "  Generate iPXE Menu for ${HOSTNAME}"
		cat >> "${IPXEMENU_DIR}/$MACDASH" <<-HEREEND
		:bootosdeploy
		echo next-server: \${next-server}
		echo hostname: \${hostname}
		echo mac: \${mac:hexhyp}
		set server_root ${PXE_SERVER_ADDRESS}/dist/rhcos/media
		#kernel \${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer-kernel ip=dhcp rd.neednet=1 initrd=\${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer-initramfs.img console=tty0 console=ttyS0 coreos.inst=yes coreos.inst.install_dev=sda coreos.inst.image_url=\${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-metal-${IMAGE_TYPE}.raw.gz coreos.inst.ignition_url=${PXE_SERVER_ADDRESS}/dist/rhcos/ign/${IGN_FILE_NAME}
		kernel \${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer-kernel ip=dhcp rd.neednet=1 initrd=rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer-initramfs.img console=tty0 console=ttyS0 coreos.inst=yes coreos.inst.install_dev=sda coreos.inst.image_url=\${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-metal-${IMAGE_TYPE}.raw.gz coreos.inst.ignition_url=${PXE_SERVER_ADDRESS}/dist/rhcos/ign/${IGN_FILE_NAME}
		initrd \${server_root}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer-initramfs.img
		boot || shell

		HEREEND

		## deploy grub
		## https://docs.oracle.com/cd/E52668_01/E54695/html/ol7-install-pxe-boot-uefi.html
		## http://www.manobit.com/pxe-multi-boot-server-using-grub2-on-mikrotik-routeros-bios-and-efi-support/
		## https://kscherer.github.io/linux/2017/03/20/pxe-install-on-uefi-using-foreman-and-grub2
		## https://github.com/beta-u/perfect-pxe/blob/master/menu-generator/efile/grub4suse.sh
		## https://ressman.org/posts/2018-05-06-pxe-boot-up-boards/
		#echo "  Generate UEFI Grub2 Menu for ${HOSTNAME}"
		#if [ "${FIRMWARE}" = "efi" ]; then
		#	RHCOS_ISO=${ISO_DIR}/rhcos-${RHCOS_VERSION}${RHCOS_SUFFIX}-installer.iso
		#	mkdir -p ${TFTP_ROOT_DIR}/images/rhcos
		#	umount /mnt/iso > /dev/null 2>&1 || true
		#	rm -rf /mnt/iso
		#	mkdir -p /mnt/iso
		#	mount -o loop,ro -t iso9660 ${RHCOS_ISO} /mnt/iso
		#	cp /mnt/iso/images/* ${TFTP_ROOT_DIR}/images/rhcos/
		#	umount /mnt/iso
		#	rm -rf /mnt/iso
		#	mkdir -p ${TFTP_GRUB2_DIR}
		#	#cat > "${TFTP_GRUB2_DIR}/grub.conf" <<-HEREEND
		#	#cat > "${TFTP_GRUB2_DIR}/grub.conf-$MACMENU" <<-HEREEND
		#	cat > "${TFTP_ROOT_DIR}/grub.cfg" <<-HEREEND
		#	set default="1"
		#	function load_video {
		#	  insmod efi_gop
		#	  insmod efi_uga
		#	  insmod video_bochs
		#	  insmod video_cirrus
		#	  insmod all_video
		#	}
		#	load_video
		#	set gfxpayload=keep
		#	insmod gzio
		#	insmod part_gpt
		#	insmod ext2
		#	set timeout=60
		#	menuentry 'Install Red Hat Enterprise Linux CoreOS' --class fedora --class gnu-linux --class gnu --class os {
		#		linux /images/rhcos/vmlinuz nomodeset rd.neednet=1 coreos.inst=yes coreos.inst.install_dev=sda coreos.inst.image_url=${PXE_SERVER_ADDRESS}/dist/rhcos/media/rhcos-${RHCOS_VERSION}-x86_64-metal-${IMAGE_TYPE}.raw.gz coreos.inst.ignition_url=${PXE_SERVER_ADDRESS}/dist/rhcos/ign/${IGN_FILE_NAME}
		#		initrd ${PXE_SERVER_ADDRESS}/dist/rhcos/media/rhcos-${RHCOS_VERSION}-x86_64-installer-initramfs.img
		#	}
		#	HEREEND
		#fi
	done
}

configure_dhcp
#prepare_rhel8
prepare_rhcos ${OCP_CLUSTER_NAME}