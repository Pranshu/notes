# Introduction
If you do not have enough system resource (atleast 16GB Memory, 4CPU) on your laptop/workstation it is possible to host Kubernetes localdev on Linux VM hosted on vSphere. These instructions walk you through of steps required to deploy a fully configured Debian VM to host Kubernetes localdev.
## Deploy localdev VM
1. Download Debian OVA http://www.gsoutils.ford.com/files/openshift/debian_9_40.ova
1. Import this OVA into vCenter to create a VM
1. Configure VM hardware as described below:
    ```
    CPU: 8
    Memory: 32GB
    Disk: 600GB
    ```
    > Make sure enable nested virtualization
1. Start the VM, and navigate to VM console in vCenter and login using following credentials:
    ```
    Username: vagrant
    Password: vagrant
    ```
    > ⚠ NOTE: You should change this default password, at the earliest possible opportunity.
1. Configure VM network stack:
   1. Open the file /etc/network/interfaces
        ```
        # Delete the following line:
        allow-hotplug eth0
        iface eth0 inet dhcp
        pre-up sleep 2
        pre-up sleep

        # Add following line
        auto eth0
        allow-hotplug eth0
        iface eth0 inet static
        address {VM-STATIC-IP}
        netmask {VM-NETWORK-MASK}
        gateway {NETWORK-GATEWAY-IP}
        dns-nameservers {DNS-NAMESERVERS}
        ```
    1. Open the file /etc/hosts, and add this line
        ```
        {VM-STATIC-IP}   {VM-FQDN]
        ```
    1. Open the file /etc/resolv.conf, and add this line
        ```
        nameserver 19.106.96.250
        nameserver 19.106.100.250
        ```
    1. Open the /etc/hosts
        ```
        echo {VM-FQDN} > /etc/hostname
        ```
    > You should replace the place holder values identified by {}, with real values
1. Reboot VM
1. ssh in to VM to ensure that you can access it.
    ```
    ssh vagrant@VM-STATIC-IP
    ```
    When prompted for password use `vagrant`

## Install Kubernetes localdev dependencies
1. To install all dependencies to host Kubernetes localdev on remote linux server, copy and execute [this script](https://github.ford.com/Containers/localdev/blob/master/utils/install-ldev-debian.sh):
    ```
    GITHUB_ACCESS_TOKEN='YOUR-GITHUB-TOKEN'
    curl --header "Authorization: token $GITHUB_ACCESS_TOKEN" \
        --header "Accept: application/vnd.github.v3.raw" \
        --header "User-Agent: curl" \
        --location \
        --output /tmp/install-ldev-debian.sh \
        https://github.ford.com/api/v3/repos/Containers/localdev/contents/utils/install-ldev-debian.sh?ref=master

    chmod +x /tmp/install-ldev-debian.sh && \
        /tmp/install-ldev-debian.sh && \
        rm -rf /tmp/install-ldev-debian.sh
    ```
    > ⚠ NOTE: You should replace the place holder values identified by YOUR-GITHUB-TOKEN, with real values. Yoo can create GitHub Token at [https://github.ford.com/settings/tokens](https://github.ford.com/settings/tokens)

## Clone Kubernetes localdev repository
1. Clone, Configure, and Deploy
    ```
    git clone https://github.ford.com/Containers/localdev

    or

    git clone git@github.ford.com:Containers/localdev.git
    ```
    > Note: The master branch of this repository now tracks RedHat OpenShift, if you would like to deploy CoreOS Tectonic based local development environment then please checkout git branched named '[Tectonic-*](https://github.ford.com/Containers/localdev/branches)'
## Start localdev on the server:
1. Open another ssh session to the server to start localdev
    ```
    cd localdev
    vagrant up
    ```
    > ⚠ NOTE: On windows you should execute these commands in powershell running in administrative context.

## View remote server desktop:
1. On your local workstation Install [VNC viewer](https://www.realvnc.com/en/connect/download/vnc/windows/)
1. To view the remote desktop open vnc viewer and point to:
    ```
    127.0.0.1:5901
    ```
    when prompted for password enter `vagrant`
1. Start SSH tunnel
    ```
    ssh -L 5901:127.0.0.1:5901 -N -f -l vagrant SERVER_IP_ADDRESS
    ```
1. To view the remove desktop open vnc viewer and point to:
    ```
    127.0.0.1:5901
    ```
    when prompted for password enter `vagrant`
