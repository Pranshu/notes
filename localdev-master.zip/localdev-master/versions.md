Following matrix list the versions of OpenShift that are supported

| Version  | OKD | OCP | OVS | Calico | OCS        |
| :------- | :-- | :-- | :-- | :----- | :--------- |
| 3.9.33   | x   | x   | x   | x      |            |
| 3.9.40   | x   | x   | x   | x      |            |
| 3.10.14  |     | x   | x   | x      |            |
| 3.10.34  |     | x   | x   | x      | 3.3.1      |
| 3.10.45  |     | x   | x   | x      | 3.3.1      |
| 3.11.16  |     | x   | x   | x      | 3.3.1      |
| 3.11.43  |     | x   | x   | x      | 3.3.1      |
| 3.11.51  |     | x   | x   | x      | 3.3.1      |

## Base Image
| Reg. Date  | Base Image Version      | Localdev Releases |
| :--------- | :---------------------- | :---------------- |
| Reg. Date  | ford-rhel7-v2018.9.1    | v3.10.45-4        |
| Reg. Date  | ford-rhel7-v2018.10.2   | v3.11.16-3        |
| Reg. Date  | ford-rhel7-v2018.10.25  | v3.11.16-4        |
| Reg. Date  | ford-rhel7-v2018.11.02  | v3.11.16-5        |
| Reg. Date  | ford-rhel7-v2018.11.02  | v3.11.43-1        |
| Reg. Date  | ford-rhel7-v2018.11.02  | v3.11.51-1        |
