#!/bin/bash

# IMPORTANT:
# 1. Download KUBECONFIG for Tectonic from https://tectonic.k8s.ford.com/settings/profile and place in ../artifacts/kube-config-tectonic
# 2. Download kubectl compatible with tectonic https://storage.googleapis.com/kubernetes-release/release/v1.8.7/bin/darwin/amd64/kubectl
# 3. Download oc https://github.com/spuranam/tools/releases/download/3.10.45/oc-3.10.45-macosx.tar.gz
# 4. Download and minio from https://www.minio.io/downloads.html
# 5. export MINIO_ACCESS_KEY='BH9JIEGJWYB47KJY1LYC'
# 6. export MINIO_SECRET_KEY='K+hjVeNPN9TXhjSTYwXUUXIyoOPLtHzbq6Rlzuuo'
# 7. start minio "minio server --address REPLACE-YOUR-HOST-IP:9000 $HOME/Projects/minio_data"
# 8. ./kubemv -n example -s nfs

# ASSUMPTIONS:
# This script assumes that you have following objects defined in OpenShift
# 1. Project a.k.a namespace
#      oc new-project ${NAMESPACE_NAME}
#      oc annotate namespace ${NAMESPACE_NAME} openshift.io/requester=${USER} --overwrite
#      oc annotate namespace ${NAMESPACE_NAME} ford.com/requester=${USER} --overwrite
#      oc annotate namespace ${NAMESPACE_NAME} ford.com/created-on=$(date -u +'%Y-%m-%dT%H:%M:%SZ') --overwrite
#      oc annotate namespace ${NAMESPACE_NAME} ford.com/free-trial=false --overwrite
# 2. All service accounts
#      oc create serviceaccount jenkins -n ${NAMESPACE_NAME}
# 3. nonroot SCC has been assigned to service accounts
#    DOCS: https://docs.okd.io/latest/admin_guide/manage_scc.html
#      oc adm policy add-scc-to-user nonroot -z default -n ${NAMESPACE_NAME}
#      oc adm policy add-scc-to-user nonroot -z jenkins -n ${NAMESPACE_NAME}
#      oc adm policy add-scc-to-user nonroot system:serviceaccount:MY_PROJECT_NAME:MY_SERVICE_ACCOUNT

set -o errexit
set -o nounset
set -o pipefail

SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd -P )
BIN_DIR="$(cd "$(dirname "${SCRIPT_ROOT}/../artifacts/bin/.")" && pwd -P)"
PATH=$PATH:$BIN_DIR

OBJECT_STORAGE_HOST='136.12.60.68'
OBJECT_STORAGE_PORT='9000'
MINIO_ACCESS_KEY='BH9JIEGJWYB47KJY1LYC'
MINIO_SECRET_KEY='K+hjVeNPN9TXhjSTYwXUUXIyoOPLtHzbq6Rlzuuo'

TECTONIC_KUBECONFIG="$(cd "$(dirname "${SCRIPT_ROOT}/../artifacts/.")" && pwd -P)/kube-config-tectonic"
OPENSHIFT_KUBECONFIG="$(cd "$(dirname "${SCRIPT_ROOT}/../artifacts/.")" && pwd -P)/kube-config-openshift"

## global variables
STORAGECLASS_NAME=''
NAMESPACE_NAME=''

TOOLBOX_VOLUME_NAME='vol_to_backup'
TOOLBOX_VOLUME_MOUNT_POINT='/donor_volume'

## Create bin directory
if [ ! -d ${BIN_DIR} ]; then
    mkdir -p ${BIN_DIR}
fi

## MacOS ships BSD getopt, hence we need install them via homebrew
## brew install gnu-getopt openssl
case "$OSTYPE" in
    darwin*)
        export PATH=$(brew --prefix gnu-getopt)/bin:$PATH;
        ;;
    linux*)
        break;
        ;;
    msys*)
        break;
        ;;
    solaris*)
        break;
        ;;
    bsd*)
        break;
        ;;
    *)
        break;
        ;;
esac

function usage() {
cat << HEREDOC

usage: ${0} [hn:s:]

OPTIONS:

-h|--help         This help
-n|--namespace    N namespace to backup and restore
-s|--storageclass N storageclass name

Examples:
    1)  $0 -n example -s nfs
    2)  $0 --namespace example --storageclass nfs

Explantion:
    Example #1, and #2 are equivalent, except #1 uses short-hand flags.

🔥  File bug reports at: https://github.ford.com/Containers/localdev/issues/new

HEREDOC
}

#getopt --test > /dev/null
#if [[ $? -ne 4 ]]; then
#    echo "I’m sorry, `getopt --test` failed in this environment."
#    exit 1
#fi

## NOTE: options may be followed by one colon to indicate they have a required argument
short='hn:s:'
long='help,namespace:,storageclass:'
# Pass arguments only via  -- "$@"  to separate them correctly.
args=$(getopt --name "$(basename $0)" --options "${short}" --longoptions "${long}" -- "$@")
if [[ $? -ne 0 ]]; then
    echo "$0 Error in getopt"
    exit 1
fi

## Note the quotes around $args; to properly handle the quoting
eval set -- "${args}"

while true; do
    case "${1}" in
        -n|--namespace)
            NAMESPACE_NAME="${2}"
            shift 2
            ;;
        -s|--storageclass)
            STORAGECLASS_NAME="${2}"
            shift 2
            ;;
        -h|--help)
            shift
            usage
            exit 0
            ;;
        --)
            shift
            break
            ;;
        *)
            echo "$0: error - unrecognized option $1" >&2
            exit 1
            ;;
    esac
done

if [ -z ${NAMESPACE_NAME} -o -z ${STORAGECLASS_NAME} ]; then
    echo -e "\nERROR: Missing command line options"
    echo -e "\t-n|--namespace"
    echo -e "\t-s|--storageclass"
    usage
    exit 1
fi

## Lets first assume we do not have to traverse Ford HTTP proxies
export ENABLE_PROXY=false
set +e
HTTP_CODE=$( \
    curl \
        --head \
        --insecure \
        --location \
        --silent \
        --show-error \
        --fail \
        --output /dev/null \
        --write-out "%{http_code}" \
        --connect-timeout 10 \
        --proxy http://proxyvipchi.nls.ford.com:83 \
        https://google.com 2> /dev/null
)
if [ "$HTTP_CODE" = "200" ]; then
    export ENABLE_PROXY=true
fi
set -e

if [ "$ENABLE_PROXY" = "true" ]; then
    export http_proxy="http://proxyvipchi.nls.ford.com:83"
    export https_proxy="http://proxyvipchi.nls.ford.com:83"
    export no_proxy="localhost,127.0.0.1,.ford.com,.local"
else
    export http_proxy=""
    export https_proxy=""
    export no_proxy=""
fi

## Download kubectl verrsion compatible with Tectonic
#if [ ! -f ${BIN_DIR}/kubectl ]; then
#curl \
#    --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
#    --retry "${CURL_RETRY:-5}" \
#    --retry-delay "${CURL_RETRY_DELAY:-0}" \
#    --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
#    --insecure \
#    --progress-bar \
#    --location \
#    --output ${BIN_DIR}/kubectl \
#    https://storage.googleapis.com/kubernetes-release/release/v1.8.7/bin/darwin/amd64/kubectl
#chmod +x ${BIN_DIR}/kubectl
#fi

## Install YQ
#if [ ! -f ${BIN_DIR}/yq ]; then
#    curl \
#        --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
#        --retry "${CURL_RETRY:-5}" \
#        --retry-delay "${CURL_RETRY_DELAY:-0}" \
#        --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
#        --insecure \
#        --progress-bar \
#        --location \
#        --fail \
#        --show-error \
#        --output ${BIN_DIR}/yq \
#        https://github.com/mikefarah/yq/releases/download/2.1.1/yq_darwin_amd64
#    chmod +x ${BIN_DIR}/yq
#fi

## Install oc client
#if [ ! -f ${BIN_DIR}/oc ]; then
#    curl \
#        --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
#        --retry "${CURL_RETRY:-5}" \
#        --retry-delay "${CURL_RETRY_DELAY:-0}" \
#        --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
#        --insecure \
#        --progress-bar \
#        --location \
#        --fail \
#        --show-error \
#        --output ${BIN_DIR}/oc.tar.gz \
#        https://github.com/spuranam/tools/releases/download/3.10.45/oc-3.10.45-macosx.tar.gz
#    tar -xvf ${BIN_DIR}/oc.tar.gz -C ${BIN_DIR}
#    chmod +x ${BIN_DIR}/oc
#fi

## Install minio server
#if [ ! -f ${BIN_DIR}/minio ]; then
#    curl \
#        --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
#        --retry "${CURL_RETRY:-5}" \
#        --retry-delay "${CURL_RETRY_DELAY:-0}" \
#        --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
#        --insecure \
#        --progress-bar \
#        --location \
#        --fail \
#        --show-error \
#        --output ${BIN_DIR}/minio \
#        https://dl.minio.io/server/minio/release/darwin-amd64/archive/minio.RELEASE.2018-09-25T21-34-43Z
#    chmod +x ${BIN_DIR}/minio
#fi

echo "Current namespace is ${NAMESPACE_NAME}"
echo "Using the storageClass ${STORAGECLASS_NAME}"

#------------------------------
# BACKUP TECTONIC NAMESPACE
#------------------------------
export KUBECONFIG="${TECTONIC_KUBECONFIG}"
echo "TECTONIC KUBECONFIG=${TECTONIC_KUBECONFIG}"

## Scale down Kubernetes scaleable objects to zero
for dep in $(kubectl -n ${NAMESPACE_NAME} get deployments -o jsonpath='{range .items[*]} {@.metadata.name}{end}'); do
    kubectl -n ${NAMESPACE_NAME} patch deployment ${dep} -p '{"spec":{"replicas":0}}'
    rc=$?
    if [[ $rc != 0 ]]; then
        echo "Failed to patch deployment"
        exit
    fi
    ## Wait for all pods to stop
    until [[ $(kubectl -n ${NAMESPACE_NAME} get pods --no-headers=true 2>/dev/null | wc -l) -eq 0 ]]; do
        echo "Waiting to scale down deployment ${dep}"
        sleep 1
    done
done

## Backup namespace object definitions
i=$((0))
for n in $(kubectl -n ${NAMESPACE_NAME} get -o=custom-columns=NAMESPACE:.metadata.namespace,KIND:.kind,NAME:.metadata.name pvc,configmap,ingress,service,secret,deployment,statefulset,hpa,job,cronjob,role,rolebinding,serviceaccount | grep -v 'secrets/default-token'); do
    if (( $i < 1 )); then
        namespace=$n
        i=$(($i+1))
        if [[ "$namespace" == "PersistentVolume" ]]; then
            kind=$n
            i=$(($i+1))
        fi
    elif (( $i < 2 )); then
        kind=$n
        i=$(($i+1))
    elif (( $i < 3 )); then
        name=$n
        i=$((0))
        if [[ "$namespace" != "NAMESPACE" ]]; then
            mkdir -p ${SCRIPT_ROOT}/$namespace
            yaml=$((kubectl get $kind -o=yaml $name -n $namespace ) 2>/dev/null)
            if [[ $kind != 'Secret' || $yaml != *"type: kubernetes.io/service-account-token"* ]]; then
                echo "Saving ${namespace}/${kind}.${name}.yaml"
                kubectl get $kind -o=yaml --export $name -n $namespace > ${SCRIPT_ROOT}/$namespace/$kind.$name.yaml
            fi
        fi
    fi
done

## Backup persistent volumes
pvc_index=$((0))
filepath="${SCRIPT_ROOT}/${NAMESPACE_NAME}"
for file in $(ls ${filepath}/PersistentVolumeClaim*.yaml); do
    pvc_name=$(yq read ${filepath}/$file 'metadata.name')
    if [ "${pvc_name}" = "" ]; then
        echo "failed get the name of PVC in ${NAMESPACE_NAME} namespace"
        exit 1
    fi

  ## For each PVC inject the toolbox pod
  ## NOTE: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
  TOOLBOX_PVC_NAME=${pvc_name}
  kubectl -n ${NAMESPACE_NAME} create -f - <<EOF
kind: Pod
apiVersion: v1
metadata:
  name: toolbox
  labels:
    app: toolbox
spec:
  containers:
    - name: toolbox
      image: quay.k8s.ford.com/ford-containers/toolbox:1.0.0
      args: ["/bin/bash","-c", "while true; do; sleep 10; done"]
      resources:
        requests:
          memory: "10Mi"
          cpu: "100m"
        limits:
          memory: "100Mi"
          cpu: "250m"
      volumeMounts:
        - name: ${TOOLBOX_VOLUME_NAME}
          mountPath: ${TOOLBOX_VOLUME_MOUNT_POINT}
      imagePullPolicy: IfNotPresent
  volumes:
    - name: ${TOOLBOX_VOLUME_NAME}
      persistentVolumeClaim:
        claimName: ${TOOLBOX_PVC_NAME}
EOF

  ## Wait for the toolbox to start running
  JSONPATH='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'; until kubectl -n ${NAMESPACE_NAME} get pods --selector app=toolbox -o jsonpath="$JSONPATH" 2>&1 | grep -q "Ready=True"; do sleep 1;echo "waiting for pod to be available"; kubectl -n ${NAMESPACE_NAME} get pods; done

  ## Wait for the PVC to get bound
  until kubectl -n ${NAMESPACE_NAME} get pvc -o jsonpath='{range .items[*]}{@.metadata.name}:{@.status.phase}{end}' 2>&1 | grep -q "${pvc}:Bound"; do sleep 1;echo "waiting for PVC ${pvc} to bound"; kubectl -n ${NAMESPACE_NAME} get pvc; done

  ## Generate the backup script on host
  ## NOTE: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
cat << HEREDOC > ${SCRIPT_ROOT}/backup_pvc.sh
#!/bin/bash

export PROJECT_NAME="${NAMESPACE_NAME}"
## https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html#bucketnamingrules
PROJECT_TRUNC=$(${PROJECT_NAME} | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)
PVC_TRUNC=$(${pvc_name} | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)
PROJECT_BUCKET="pvc${pvc_index}--${PROJECT_TRUNC}--${PVC_TRUNC}--pvc${pvc_index}"
export PROJECT_PV_MOUNT=${TOOLBOX_VOLUME_MOUNT_POINT}
export RESTIC_SNAPSHOT="latest"
export RESTIC_PASSWORD="${PROJECT_BUCKET}"
export RESTIC_REPOSITORY="s3:http://${OBJECT_STORAGE_HOST}:${OBJECT_STORAGE_PORT}/${PROJECT_BUCKET}"
export AWS_ACCESS_KEY_ID=${MINIO_ACCESS_KEY}
export AWS_SECRET_ACCESS_KEY=${MINIO_SECRET_KEY}

# Initailize restic repository
restic -r ${RESTIC_REPOSITORY} init >/dev/null 2>&1

# Backup PV
# tar cf - /tmp/backup | gzip | restic -r $r backup --stdin --stdin-filename $i.example.gz
# restic backup /tmp/backup --tag ${PROJECT_NAME} --hostname ${PROJECT_NAME} --one-file-system --no-cache --verbose --verbose
restic -r ${RESTIC_REPOSITORY} backup ${PROJECT_PV_MOUNT} --tag ${PROJECT_NAME} --hostname ${PROJECT_NAME} --one-file-system --cache-dir=/tmp/cache --verbose --verbose
rc=$?
if [[ $rc == 0 ]]; then
 echo "File backup using restic was successfull"
else
  echo "File backup using restic command filed with status ${rc}"
  restic unlock
  exit 1
fi
HEREDOC

  ## Copy backup script to toolbox pod
  kubectl -n ${NAMESPACE_NAME} cp ${SCRIPT_ROOT}/backup_pvc.sh toolbox:/tmp

  ## Execute backup script in the toolbox pod
  kubectl -n ${NAMESPACE_NAME} exec toolbox -- chmod +x /tmp/backup_pvc.sh && /bin/bash /tmp/backup_pvc.sh

  ## Delete toolbox pod
  kubectl -n ${NAMESPACE_NAME} delete pod toolbox --force --grace-period=0

  ## Delete the tmp script on host
  if [ -f ${SCRIPT_ROOT}/backup_pvc.sh ]; then
      rm -rf ${SCRIPT_ROOT}/backup_pvc.sh
  fi

  ## Increment the PVC index
  pvc_index=$(($index+1))

done

#---------------------------------------
# RETORE TECTONIC NAMESAPCE TO OPENSHIFT
#---------------------------------------
export KUBECONFIG="${OPENSHIFT_KUBECONFIG}"

#=======================================
# RESTORE PVCs
#=======================================
pvc_index=$((0))
filepath="${SCRIPT_ROOT}/${NAMESPACE_NAME}"
for file in $(ls ${filepath}/PersistentVolumeClaim*.yaml); do

    pvc_name=$(yq read ${filepath}/$file 'metadata.name')
    if [ "${pvc_name}" = "" ]; then
        echo "failed get the name of PVC in ${NAMESPACE_NAME} namespace"
        exit 1
    fi

    pvc_size=$(yq read ${filepath}/$file 'spec.resources.requests.storage')
    if [ "${pvc_size}" = "" ]; then
        echo "failed get the size of PVC in ${NAMESPACE_NAME} namespace"
        exit 1
    fi

    pvc_accessmodes=$(yq read ${filepath}/$file 'spec.accessModes[0]')
    if [ "${pvc_accessmodes}" = "" ]; then
        echo "failed get the accessModes of PVC in ${NAMESPACE_NAME} namespace"
        exit 1
    fi

   ## Create PVC
   oc -n ${NAMESPACE_NAME} create -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ${pvc_name}
spec:
  accessModes:
  - ${pvc_accessmodes}
  resources:
    requests:
      storage: ${pvc_size}
  storageClassName: ${STORAGECLASS_NAME}
EOF

    ## Wait for new PVC to be bound
    until oc -n ${NAMESPACE_NAME} get pvc -o jsonpath='{range .items[*]}{@.metadata.name}:{@.status.phase}{end}' 2>&1 | grep -q "${pvc_name}:Bound"; do sleep 1;echo "waiting for PVC ${pvc_name} to bound"; oc -n ${NAMESPACE_NAME} get pvc; done

    ## For each PVC inject the toolbox pod
    ## NOTE: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
    TOOLBOX_PVC_NAME=${pvc_name}
    oc -n ${NAMESPACE_NAME} create -f - <<EOF
kind: Pod
apiVersion: v1
metadata:
  name: toolbox
  labels:
    app: toolbox
spec:
  containers:
    - name: toolbox
      image: quay.k8s.ford.com/ford-containers/toolbox:1.0.0
      args: ["/bin/bash","-c", "while true; do; sleep 10; done"]
      resources:
        requests:
          memory: "10Mi"
          cpu: "100m"
        limits:
          memory: "100Mi"
          cpu: "250m"
      volumeMounts:
        - name: ${TOOLBOX_VOLUME_NAME}
          mountPath: ${TOOLBOX_VOLUME_MOUNT_POINT}
      imagePullPolicy: IfNotPresent
  volumes:
    - name: ${TOOLBOX_VOLUME_NAME}
      persistentVolumeClaim:
        claimName: ${TOOLBOX_PVC_NAME}
EOF

    ## Wait for the toolbox to start running
    JSONPATH='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'; until oc -n ${NAMESPACE_NAME} get pods --selector app=toolbox -o jsonpath="$JSONPATH" 2>&1 | grep -q "Ready=True"; do sleep 1;echo "waiting for pod to be available"; oc -n ${NAMESPACE_NAME} get pods; done

    ## Generate the restore script on host
    cat << HEREDOC > ${SCRIPT_ROOT}/restore_pvc.sh
#!/bin/bash
export PROJECT_NAME="${NAMESPACE_NAME}"

## https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html#bucketnamingrules
PROJECT_TRUNC=$(${PROJECT_NAME} | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)
PVC_TRUNC=$(${pvc_name} | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)
PROJECT_BUCKET="pvc${pvc_index}--${PROJECT_TRUNC}--${PVC_TRUNC}--pvc${pvc_index}"
export PROJECT_PV_MOUNT="${TOOLBOX_VOLUME_MOUNT_POINT}"
export RESTIC_SNAPSHOT="latest"
export RESTIC_PASSWORD="${PROJECT_BUCKET}"
export RESTIC_REPOSITORY="s3:http://${OBJECT_STORAGE_HOST}:${OBJECT_STORAGE_PORT}/${PROJECT_BUCKET}"
export AWS_ACCESS_KEY_ID=${MINIO_ACCESS_KEY}
export AWS_SECRET_ACCESS_KEY=${MINIO_SECRET_KEY}

# Initailize restic repository
restic -r ${RESTIC_REPOSITORY} init >/dev/null 2>&1
restic restore ${RESTIC_SNAPSHOT} --target / --include ${PROJECT_PV_MOUNT} --cache-dir=/tmp/cache >/dev/null 2>&1
rc=$?
if [[ $rc == 0 ]]; then
  echo "File restore using restic was successfull"
else
  echo "File restore using restic command filed with status ${rc}"
  restic unlock
fi
HEREDOC

    ## Copy restore script to toolbox pod
    oc -n ${NAMESPACE_TO_BACKUP} cp ${SCRIPT_ROOT}/restore_pvc.sh toolbox:/tmp

    ## Execute restore script in the toolbox pod
    oc -n ${NAMESPACE_TO_BACKUP} exec toolbox -- chmod +x /tmp/restore_pvc.sh && /bin/bash /tmp/restore_pvc.sh

    ## Delete toolbox pod
    oc -n ${NAMESPACE_TO_BACKUP} delete pod toolbox --force --grace-period=0

    ## Delete backup script from host
    if [ -f ${SCRIPT_ROOT}/restore_pvc.sh ]; then
        rm -rf ${SCRIPT_ROOT}/restore_pvc.sh
    fi

    ## Increment the PVC index
    index=$(($index+1))

done

#=======================================
# RESTORE ALL OTHER NAMESPACE OBJECTS
#=======================================
filepath="${SCRIPT_ROOT}/${NAMESPACE_NAME}"
for file in $(ls ${filepath}); do
    #if grep -q -e "PersistentVolumeClaim*.yaml" <<< "$file" ; then
    #   continue
    #fi

    ## Skip PVCs since we already took care of them
    if [[ "$file" =~ '^PersistentVolumeClaim\..*\.yaml$' ]]; then
        continue
    fi

    ## Skip creating ServiceAccount since we already took care of them
    if [[ "$file" =~ '^ServiceAccount\..*\.yaml$' ]]; then
        continue
    fi

    ## TODO: Ingress object must be converted into route object
    if [[ "$file" =~ '^Ingress\..*\.yaml$' ]]; then
        continue
    fi

    echo -e "\t Importing $file"
    oc apply -f ${filepath}/$file -n ${NAMESPACE_NAME}
done

exit 0
