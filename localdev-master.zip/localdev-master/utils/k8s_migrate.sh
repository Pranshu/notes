#!/bin/bash

# Repository Requirements
#
# Download MINIO from https://www.minio.io/downloads.html
#
# export MINIO_ACCESS_KEY='BH9JIEGJWYB47KJY1LYC'
# export MINIO_SECRET_KEY='K+hjVeNPN9TXhjSTYwXUUXIyoOPLtHzbq6Rlzuuo'
#
# Run with minio server --address <your IP>:9000 <your data directory>
#
# On windows you may need to open a firewall hole for incoming traffic on port 9000 any protocol.
#

# ASSUMPTIONS:
# This script assumes that you have following objects defined in OpenShift
# 1. Project a.k.a namespace
#      oc new-project ${NAMESPACE_NAME}
#      oc annotate namespace ${NAMESPACE_NAME} openshift.io/requester=${USER} --overwrite
#      oc annotate namespace ${NAMESPACE_NAME} ford.com/requester=${USER} --overwrite
#      oc annotate namespace ${NAMESPACE_NAME} ford.com/created-on=$(date -u +'%Y-%m-%dT%H:%M:%SZ') --overwrite
#      oc annotate namespace ${NAMESPACE_NAME} ford.com/free-trial=false --overwrite
# 2. All service accounts
#      oc create serviceaccount jenkins -n ${NAMESPACE_NAME}
# 3. nonroot SCC has been assigned to service accounts
#    DOCS: https://docs.okd.io/latest/admin_guide/manage_scc.html
#      oc adm policy add-scc-to-user nonroot -z default -n ${NAMESPACE_NAME}
#      oc adm policy add-scc-to-user nonroot -z jenkins -n ${NAMESPACE_NAME}
#      oc adm policy add-scc-to-user nonroot system:serviceaccount:MY_PROJECT_NAME:MY_SERVICE_ACCOUNT

usage () {
cat << HEREDOC

usage: $(basename $0) command namespace [options]

COMMAND:
   backup - backup namespace yaml and pvc's

   restore - retstore namespace yamls and pvc's

   migrate - perforam a backup and a restore

   helm - Print this usage information

OPTIONS:
   --no-backup-objects - Do not backup source objects (used for debugging)

   --no-backup-pvcs - Do not backup source pvcs (used for debugging)

   --no-scale-replicas - Do not scale back replicas (forces --no-backup-pvcs)

   --restore-replicas - restores replicas after backing up PVC's (useful for getting a snapshot of a namespace and automatically renabling the pods after the cpature)

   --fast-pods - create toolbox pods but run stub scripts instead of restic operations (used for debugging)

   --show-yaml - print generated yaml files to console for debugging

   --no-restore-pvcs - do not restore PVC's (used for debugging)

   --debug - print debugging info

   --dry-run - Do not backup or restore PVC to S3 repo. Perform all other actions. (Used for debugging)

REQUIREMENTS:
   Source and destination config files must be provided in the locations below or the envrionment variables set to their locations.

ENVIRONMENT VARIABLES:
   K8S_MIGRATE_OBJECT_STORAGE_HOST_URL
   K8S_MIGRATE_MINIO_ACCESS_KEY
   K8S_MIGRATE_MINIO_SECRET_KEY

   K8S_MIGRATE_SOURCE_KUBECONFIG        default("${SCRIPT_ROOT}/source_config")
   K8S_MIGRATE_DESTINATION_KUBECONFIG	default("${SCRIPT_ROOT}/destination_config")

   K8S_MIGRATE_YAML_DIR                 default("${SCRIPT_ROOT}/data/yaml")

Examples:
    1)  $(basename $0) backup sde-training
    2)  $(basename $0) restore sde-training
    2)  $(basename $0) migrate sde-training

Debug Examples:
    1)  $(basename $0) backup  sde-training --no-scale-repicas             (only gathers source yaml's and metadata in data/yaml/namespace dir, does not backups pvcs, scale back replicas or make any modifications to source)
    2)  $(basename $0) backup  sde-training --no-backup-objects --fastpods (works off already captured yaml's and metadata, exercises pvc backup code but does not actually talk to restic)
    3)  $(basename $0) restore sde-training --no-restore-pvcs              (restores objects to yaml without creating or restoring pvcs, usefule for testing just yaml creation and conversion)

🔥  File bug reports at: https://github.ford.com/SDE/k8s_utils/issues/new

HEREDOC
}



set -o nounset
set -o pipefail



#############
# CONSTANTS #
#############
TOOLBOX_VOLUME_NAME='vol-to-backup'
TOOLBOX_VOLUME_MOUNT_POINT='/donor_volume'



###############################################
# Set SCRIPT_ROOT and BIN_DIR based on OSTYPE #
###############################################

SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd -P )

case "$OSTYPE" in
   darwin)
      ;;
   linux)
      ;;
   solaris)
      ;;
   bsd)
      ;;
   msys)
      BIN_DIR="${SCRIPT_ROOT}/bin/windows"
      ;;
   'cygwin'|'msys')
      BIN_DIR="${SCRIPT_ROOT}/bin/windows"
      SCRIPT_ROOT=$( cygpath -m "${SCRIPT_ROOT}" )
      ;;
   *)
      ;;
esac

PATH=$BIN_DIR:$PATH



############
# DEFAULTS #
############
DEFAULT_MINIO_OBJECT_STORAGE_HOST_URL='http://19.47.24.84:9000'
DEFAULT_MINIO_ACCESS_KEY='BH9JIEGJWYB47KJY1LYC'
DEFAULT_MINIO_SECRET_KEY='K+hjVeNPN9TXhjSTYwXUUXIyoOPLtHzbq6Rlzuuo'

DEFAULT_SOURCE_KUBECONFIG="${SCRIPT_ROOT}/source_config"
DEFAULT_DESTINATION_KUBECONFIG="${SCRIPT_ROOT}/destination_config"

DEFAULT_YAML_DIR="${SCRIPT_ROOT}/data/yaml"



#################################
# ENV VARS to override defaults #
#################################
OBJECT_STORAGE_HOST_URL=${K8S_MIGRATE_OBJECT_STORAGE_HOST_URL:=$DEFAULT_MINIO_OBJECT_STORAGE_HOST_URL}
MINIO_ACCESS_KEY=${K8S_MIGRATE_MINIO_ACCESS_KEY:=$DEFAULT_MINIO_ACCESS_KEY}
MINIO_SECRET_KEY=${K8S_MIGRATE_MINIO_SECRET_KEY:=$DEFAULT_MINIO_SECRET_KEY}

SOURCE_KUBECONFIG=${K8S_MIGRATE_SOURCE_KUBECONFIG:=$DEFAULT_SOURCE_KUBECONFIG}
DESTINATION_KUBECONFIG=${K8S_MIGRATE_DESTINATION_KUBECONFIG:=$DEFAULT_DESTINATION_KUBECONFIG}

YAML_DIR=${K8S_MIGRATE_YAML_DIR:=$DEFAULT_YAML_DIR}



####################
# GLOBAL VARIABLES #
####################
NAMESPACE_NAME=''

BACKUP_SECONDS=0
RESTORE_SECONDS=0

BACKUP=false
BACKUP_OBJECTS=true
BACKUP_PVCS=true
SCALE_REPLICAS=true
RESTORE_REPLICAS=false

RESTORE=false
RESTORE_PVCS='true'

DRY_RUN=false
SHOW_YAML=false

FAST_PODS=false
DEBUG=false

CLUSTER_NAME=''
DESTINATION_TYPE=''



if [[ $# -lt 2 ]]; then
   usage
   exit 0
fi

case $1 in
   backup)
      BACKUP=true
      ;;

   restore)
      RESTORE=true
      ;;

   migrate)
      BACKUP=true
      RESTORE=true
      ;;
   *)
      usage
      exit 1
      ;;
esac
shift

NAMESPACE_NAME=$1
shift


while (( $# )); do
   case $1 in
      '--no-backup-objects')
         BACKUP_OBJECTS=false
         shift
         ;;
      '--no-backup-pvcs')
         BACKUP_PVCS=false
         shift
         ;;
      '--no-scale-replicas')
         SCALE_REPLICAS=false
         BACKUP_PVCS=false
         shift
         ;;
      '--restore-replicas')
         RESTORE_REPLICAS=true
         shift
         ;;
      '--dry-run')
         DRY_RUN=true
         shift
         ;;
      '--show-yaml')
         SHOW_YAML=true
         shift
         ;;
      '--fast-pods')
         FAST_PODS=true
         shift
         ;;
      '--no-restore-pvcs')
         RESTORE_PVCS='false'
         shift
         ;;
      '--debug')
         DEBUG='true'
         shift
         ;;
      *)
         echo "Unkown option $1"
         usage
         exit 1
         ;;
   esac
done


#############################################
# FUNCTIONS
#############################################
printd () {
   if [[ "true" == "${DEBUG}" ]]; then
      printf "$@"
   fi
}

CheckAndSetProxies () {
   ## Lets first assume we do not have to traverse Ford HTTP proxies
   local ENABLE_PROXY=false

   local HTTP_CODE

   HTTP_CODE=$( \
      curl \
         --head \
         --insecure \
         --location \
         --silent \
         --show-error \
         --fail \
         --output /dev/null \
         --write-out "%{http_code}" \
         --connect-timeout 10 \
         --proxy http://proxyvipchi.nls.ford.com:83 \
         https://google.com 2> /dev/null
   )

   if [ "$HTTP_CODE" != "200" ]; then
      export ENABLE_PROXY=true
   fi

   if [ "$ENABLE_PROXY" == "true" ]; then
      export http_proxy="http://proxyvipchi.nls.ford.com:83"
      export https_proxy="http://proxyvipchi.nls.ford.com:83"
      export no_proxy="localhost,127.0.0.1,.ford.com,.local"
   else
      export http_proxy=""
      export https_proxy=""
      export no_proxy=""
   fi
}

# ARG1 = binary name
CheckBinary () {
   printf "%-20s " "   -$1"
   local DATA; DATA=$( which $1 2>&1 )
   local rc=$?
   if [ $rc -ne 0 ]; then
      echo "Failed"
      echo "Error = ${DATA}"
      exit 1
   else
      echo -e "OK  found @ ${DATA}"
   fi
}

# ARG1 = host  ARG2 = port  ARG3 = access key  ARG4 = secret key
CheckRepo () {

   echo -n "   -Repository access..."
   local MC_CONFIG; MC_CONFIG=$(mc config host add s3 $1 $2 $3 2>&1)
   local rc=$?
   if [ $rc -ne 0 ]; then
      echo "Failed"
      echo "${MC_CONFIG}"
      exit 1
   fi

   local MC_TAG_REPO; MC_TAG_REPO=$()
   local MC_STAT; MC_STAT=$(mc ls s3 2>&1)
   local rc=$?
   if [ $rc -ne 0 ]; then
      echo "Failed"
      echo "${MC_STAT}"
      exit 1
   fi

   echo "OK"
}

# ARG1= name ARG2= config file  ARG3= namespace
CheckCluster () {
   echo -n "   -$1 cluster access..."
   export KUBECONFIG="$2"
   local CLUSTER_INFO; CLUSTER_INFO=$(kubectl cluster-info -n $3 2>&1)
   local rc=$?
   if [ $rc -ne 0 ]; then
      echo "Failed"
      echo "${CLUSTER_INFO}"
      exit 1
   else
      echo "OK"
   fi
}

# ARG1= url
GetClusterType () {
   case $1 in
      'https://tectonic-k8s.k8s.ford.com:443')
         echo -n 'tectonic-prod'
         ;;
      'https://tectonic-k8s.qa.k8s.ford.com:443')
         echo -n 'tectonic-qa'
         ;;
      'https://api.oc.local:8443')
         echo -n 'openshift-localdev'
         ;;
      'osp')
         echo -n 'openshift-prod'
         ;;
      'oss')
         echo -n 'openshift-sandbox'
         ;;
      *)
         echo "ERROR: Unknown cluster $1"
         exit 1
         ;;
   esac
}

# ARG1 = namespace
CheckConfiguration () {
   echo "#####################################################################################################"
   echo "Checking required configuration:"

   echo "   SCRIPT_ROOT=$SCRIPT_ROOT"
   echo "   BIN_DIR=$BIN_DIR"
   echo "   OSTYPE=$OSTYPE"
   echo "   TOOLBOX_VOLUME_NAME=$TOOLBOX_VOLUME_NAME"
   echo "   TOOLBOX_VOLUME_MOUNT_POINT=$TOOLBOX_VOLUME_MOUNT_POINT"
   echo ""
   echo "   http_proxy=$http_proxy"
   echo "   https_proxy=$https_proxy"
   echo "   no_proxy=$no_proxy"
   echo ""
   echo "   OBJECT_STORAGE_HOST_URL=$OBJECT_STORAGE_HOST_URL"
   echo "   MINIO_ACCESS_KEY=$MINIO_ACCESS_KEY"
   echo "   MINIO_SECRET_KEY=$MINIO_SECRET_KEY"
   echo ""
   echo "   SOURCE_KUBECONFIG=$SOURCE_KUBECONFIG"
   echo "   DESTINATION_KUBECONFIG=$DESTINATION_KUBECONFIG"
   echo ""
   echo "   YAML_DIR=$YAML_DIR"
   echo ""
   echo "   NAMESPACE_NAME=$NAMESPACE_NAME"
   echo ""
   echo "   BACKUP=$BACKUP"
   echo "   BACKUP_OBJECTS=$BACKUP_OBJECTS"
   echo "   BACKUP_PVCS=$BACKUP_PVCS"
   echo "   SCALE_REPLICAS=$SCALE_REPLICAS"
   echo "   RESTORE_REPLICAS=$RESTORE_REPLICAS"
   echo ""
   echo "   RESTORE=$RESTORE"
   echo ""
   echo "   DRY_RUN=$DRY_RUN"
   echo "   SHOW_YAML=$SHOW_YAML"
   echo "   FAST_PODS=$FAST_PODS"
   echo "   DEBUG=$DEBUG"
   echo ""
   echo "   PATH=$PATH"
   echo ""

   CheckBinary "kubectl"
   CheckBinary "oc"
   CheckBinary "yq"
   CheckBinary "mc"
   CheckBinary "restic"
   echo ""

   CheckRepo ${OBJECT_STORAGE_HOST_URL} ${MINIO_ACCESS_KEY} ${MINIO_SECRET_KEY}

   CheckCluster "Source" "${SOURCE_KUBECONFIG}" $1

   if [[ "true" == "${RESTORE}" ]]; then
      CheckCluster "Destination" "${DESTINATION_KUBECONFIG}" $1
   fi

   #CheckBinary "foo"

   export KUBECONFIG="${SOURCE_KUBECONFIG}"
   local CLUSTER_URL=$(kubectl cluster-info -n ${NAMESPACE_NAME} 2>&1 | grep "Kubernetes master is running at" | awk '{print $6}')
   CLUSTER_NAME=$(GetClusterType $CLUSTER_URL)
   if [[ -z "$CLUSTER_NAME" ]]; then
      echo "ERROR: Could not determine source cluster name."
      exit 1
   else
      echo -e "\n   Source CLUSTER_NAME=$CLUSTER_NAME\n"
   fi

   echo "Configuration is good!"
   echo "#####################################################################################################"
}

# ARG1 = namespace
StoreClusterInfo () {
   mkdir -p "${YAML_DIR}/$CLUSTER_NAME/$1"
   kubectl cluster-info -n $1 > "${YAML_DIR}/$CLUSTER_NAME/$1/cluster-info" 2>/dev/null
   local rc=$?
   if [ $rc -ne 0 ]; then
      echo "Failed to get cluster info"
      exit 1
   fi
}

# ARG1 = namespace
GetNumberOfRunningPods () {
   kubectl -n "$1" get pods --no-headers 2>/dev/null | wc -l 2>/dev/null
}

#ARG1 = namespace
BackupObjectYamls () {
   echo "#####################################################################################################"
   echo "Backing up object definitions"
   local OBJECTS; OBJECTS=$(kubectl -n $1 get -o=custom-columns=NAMESPACE:.metadata.namespace,KIND:.kind,NAME:.metadata.name pvc,configmap,ingress,service,secret,deployment,statefulset,hpa,job,cronjob,role,rolebinding,serviceaccount --no-headers)
   if [[ -z "${OBJECTS}" ]]; then
      echo "ERROR: No objects found"
      exit 1
   fi
   echo -e "OBJECTS FOUND\n-------------\nNAMESPACE, KIND, NAME\n---------------------\n$OBJECTS"
   while read -r line; do
      local NS=$(echo "${line}" | awk '{print $1}')
      local KIND=$(echo "${line}" | awk '{print $2}')
      local NAME=$(echo "${line}" | awk '{print $3}')
      mkdir -p "${YAML_DIR}/$CLUSTER_NAME/$NS"
      local yaml=$((kubectl get $KIND -o=yaml $NAME -n $NS ) 2>/dev/null)
      if [[ $KIND != 'Secret' || $yaml != *"type: kubernetes.io/service-account-token"* ]]; then
         echo -n "Saving ${NS}/${KIND}.${NAME}.yaml"
         if [[ "Role" == "$KIND" || "RoleBinding" == "$KIND" ]]; then
            echo -en "\t\t\tWARNING:export not supported for kind $KIND... outputing all"
            kubectl get $KIND -o=yaml          $NAME -n $NS > "${YAML_DIR}/$CLUSTER_NAME/$NS/$KIND.$NAME.yaml"
         else
            kubectl get $KIND -o=yaml --export $NAME -n $NS > "${YAML_DIR}/$CLUSTER_NAME/$NS/$KIND.$NAME.yaml"
         fi
      else
         echo -n "NOT Saving ${NS}/${KIND}.${NAME}.yaml"
      fi
      echo ""
   done <<< "$OBJECTS"
}

# ARG1= namespace
BackupPVCIDs () {
   echo "#####################################################################################################"
   echo "Backing up ID's"
   local PODS; PODS=$(kubectl -n $1 get -o=custom-columns=NAME:.metadata.name pod --no-headers)
   echo -e "PODS FOUND\n-------------\n$PODS\n-------------"
   while read -r line; do
      local POD_NAME=$(echo "${line}" | awk '{print $1}')

      #echo POD_NAME=$POD_NAME

      local PVCs=$(kubectl -n $1 get pod $POD_NAME -o jsonpath='{@.spec.volumes[*].persistentVolumeClaim.claimName}')

      #echo PVCs=$PVCs

      if [[ -n "${PVCs}" ]]; then
         local DEPLOYMENT=$(kubectl -n $1 get pod $POD_NAME -o jsonpath='{@.metadata.labels.app}')
         #echo "DEPLOYMENT = $DEPLOYMENT"

         local ID=$(kubectl -n $1 exec $POD_NAME -- id -u)
         #echo ID=$ID

         mkdir -p "${YAML_DIR}/$CLUSTER_NAME/$1"
         echo "Deployment $DEPLOYMENT uses ID $ID"
         echo $ID >"${YAML_DIR}/$CLUSTER_NAME/$1/Deployment.$DEPLOYMENT.id"
      fi
   done <<< "$PODS"
}

# ARG1= namespace
ScaleReplicasToZero () {
   NUM_RUNNING_PODS=$( GetNumberOfRunningPods $1 )

   echo "#####################################################################################################"
   echo "Scaling deployments to zero replicas. Currently there are $NUM_RUNNING_PODS pods running"

   local DEPLOYMENTS=$(kubectl -n $1 get deployments -o jsonpath='{range .items[*]} {@.metadata.name}{end}')
   #echo "### DEPLOYMENTS=$DEPLOYMENTS ###"
   for dep in $DEPLOYMENTS; do
      local REPLICAS=$(kubectl -n $1 get -o jsonpath={@.spec.replicas} deployment $dep)
      if [ $REPLICAS -eq 0 ]; then
         echo "-Deployment $dep already at 0 replicas. Skipping..."
      else
         echo -ne "Patching deployment $dep with $REPLICAS replicas to 0.\t\t"
         kubectl -n $1 patch deployment ${dep} -p '{"spec":{"replicas":0}}'
         local rc=$?
         if [[ $rc != 0 ]]; then
            echo "ERROR: Failed to patch deployment $dep"
            exit 1
         fi
      fi
   done
}

# ARG1= number of replicas
GenerateReplicaPatchYaml () {
   local YAML=$(cat <<EOF
spec:
  replicas: $1
EOF
)
   cat <<< "$YAML"
}

# ARG1= namespace
RestoreReplicas () {
   NUM_RUNNING_PODS=$( GetNumberOfRunningPods $1 )

   echo "#####################################################################################################"
   echo "Restoring deployments to original number of replicas. Currently there are $NUM_RUNNING_PODS pods running"

   local DEPLOYMENTS=$(kubectl -n $1 get deployments -o jsonpath='{range .items[*]} {@.metadata.name}{end}')
   #echo "### DEPLOYMENTS=$DEPLOYMENTS ###"
   for dep in $DEPLOYMENTS; do
      local REPLICAS=$(kubectl -n $1 get -o jsonpath={@.spec.replicas} deployment $dep)
      if [ $REPLICAS -eq 0 ]; then
         local DESIRED_REPLICAS=$(yq read ${YAML_DIR}/$CLUSTER_NAME/$1/Deployment.$dep.yaml 'spec.replicas')
         echo -ne "Patching deployment $dep with $REPLICAS replicas to $DESIRED_REPLICAS replicas\t\t"
         cat <<< "$(GenerateReplicaPatchYaml $DESIRED_REPLICAS )" > ${SCRIPT_ROOT}/patch.yaml

         if [[ "true" == "${SHOW_YAML}" ]]; then
	    echo ""
            while IFS= read -r line; do
               echo -e "   $line"
            done <<< "$(cat ${SCRIPT_ROOT}/patch.yaml)"
	    echo -n "   "
         fi

         #kubectl -n $1 apply -f ${YAML_DIR}/$CLUSTER_NAME/$1/Deployment.$dep.yaml
         kubectl -n $1 patch deployment ${dep} -p "$(cat ${SCRIPT_ROOT}/patch.yaml)"
         local rc=$?
         if [[ $rc != 0 ]]; then
            echo "ERROR: Failed to patch deployment $dep"
            exit 1
         fi

         if [ -f ${SCRIPT_ROOT}/patch.yaml ]; then
            rm ${SCRIPT_ROOT}/patch.yaml
         fi
      fi
   done
}

#ARG1= namespace
WaitForZeroRunningPods () {
   echo -n "Waiting for $NUM_RUNNING_PODS pods to stop. "
   local NUM_RUNNING_PODS=$( GetNumberOfRunningPods $1 )
   until [[ $NUM_RUNNING_PODS -eq 0 ]]; do
      echo -n "$NUM_RUNNING_PODS "
      sleep 1
      NUM_RUNNING_PODS=$( GetNumberOfRunningPods $1 )
   done
   echo ""
   echo "All pods in namespace $1 stopped successfully."
}

# ARG1= namespace ARG2= pvc_name ARG3= pvc_index
GenerateBackupScript () {
   local SCRIPT=$(cat <<EOF
#!/bin/bash

echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"
echo "BACKING UP PVC $2"
echo ""

export PROJECT_NAME="$1"
# https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html#bucketnamingrules
export PROJECT_TRUNC="$(echo "$1" | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)"
export PVC_TRUNC="$(echo "$2" | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)"
export PROJECT_BUCKET="$CLUSTER_NAME/$1/pvc$3--\${PROJECT_TRUNC}--\${PVC_TRUNC}--pvc$3"
export RESTIC_SNAPSHOT="latest"
export RESTIC_PASSWORD="\${PROJECT_BUCKET}"
export RESTIC_REPOSITORY="s3:${OBJECT_STORAGE_HOST_URL}/\${PROJECT_BUCKET}"
export AWS_ACCESS_KEY_ID="${MINIO_ACCESS_KEY}"
export AWS_SECRET_ACCESS_KEY="${MINIO_SECRET_KEY}"

#echo PROJECT_NAME="\${PROJECT_NAME}"
#echo PROJECT_TRUNC="\$PROJECT_TRUNC"
#echo PVC_TRUNC="\$PVC_TRUNC"
#echo PROJECT_BUCKET="\$PROJECT_BUCKET"
#echo RESTIC_SNAPSHOT="\$RESTIC_SNAPSHOT"
#echo RESTIC_PASSWORD="\$RESTIC_PASSWORD"
echo RESTIC_REPOSITORY="\$RESTIC_REPOSITORY"
#echo AWS_ACCESS_KEY_ID="\$AWS_ACCESS_KEY_ID"
#echo AWS_SECRET_ACCESS_KEY="\$AWS_SECRET_ACCESS_KEY"

echo "Initializing repository \${RESTIC_REPOSITORY}"
echo "%%%%%%%%%%%%%%%%%%%%%%%"
restic -r \${RESTIC_REPOSITORY} init
rc=\$?
if [ \$rc -ne 0 ]; then
   echo "restic init failed with status \${rc}"
   exit 1
fi
echo "%%%%%%%%%%%%%%%%%%%%%%%"
echo "Initializing complete"

echo ""
echo "Starting backup"
echo "%%%%%%%%%%%%%%%"
# Backup PV
#restic -r \${RESTIC_REPOSITORY} backup "${TOOLBOX_VOLUME_MOUNT_POINT}" --tag \${PROJECT_NAME} --hostname \${PROJECT_NAME} --one-file-system --cache-dir=/tmp/cache --verbose --verbose
restic -r \${RESTIC_REPOSITORY} backup "${TOOLBOX_VOLUME_MOUNT_POINT}" --tag \${PROJECT_NAME} --hostname \${PROJECT_NAME} --one-file-system --cache-dir=/tmp/cache --verbose
rc=\$?
if [ \$rc -ne 0 ]; then
  echo "File backup using restic command failed with status \${rc}"
  restic unlock
  exit 1
fi
echo "%%%%%%%%%%%%%%%"
echo "Backup complete"

echo ""
echo "Checking backup"
echo "%%%%%%%%%%%%%%%"
restic -r \${RESTIC_REPOSITORY} check
rc=\$?
if [ \$rc -ne 0 ]; then
   echo "restic check failed with status \${rc}"
   exit 1
fi
echo "%%%%%%%%%%%%%%%"
echo "Check Complete"
echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"

exit 0


EOF
)
   cat <<< "$SCRIPT"
}

# ARG1= namepsace
GetPersistentVolumeClaims () {
   local filepath="${YAML_DIR}/$CLUSTER_NAME/$1"
   ls ${filepath}/PersistentVolumeClaim*.yaml
}

# ARG1= namespace ARG2= pvc_name
CreateToolBoxPod () {

   YAML=$(cat <<EOF
kind: Pod
apiVersion: v1
metadata:
  name: toolbox
  labels:
    app: toolbox
spec:
  securityContext:
    runAsUser: 0
  containers:
    - name: toolbox
      image: quay.k8s.ford.com/ford-containers/toolbox:1.0.0
      args: ["/bin/bash","-c", "sleep 60000"]
      resources:
        requests:
          memory: "1Gi"
          cpu: "1"
        limits:
          memory: "10Gi"
          cpu: "3"
      volumeMounts:
        - name: ${TOOLBOX_VOLUME_NAME}
          mountPath: ${TOOLBOX_VOLUME_MOUNT_POINT}
      imagePullPolicy: Always
      securityContext:
        privileged: true
  volumes:
    - name: ${TOOLBOX_VOLUME_NAME}
      persistentVolumeClaim:
        claimName: $2
EOF
)
   if [[ "true" == "${SHOW_YAML}" ]]; then
      printf "YAML=\n%s\n\n" "${YAML}"
   fi

   echo -n "Creating toolbox pod..."
   kubectl -n $1 create -f - <<< "$YAML" >/dev/null 2>&1
   local rc=$?
   if [ $rc -ne 0 ]; then
      echo "create failed with return code $rc"
      exit $rc
   fi
   echo "done"
}

# ARG1= namepsace
WaitForToolBoxPod () {
   local STATUS="FALSE"

   echo -n "Waiting for toolbox pod to be available..."
   until [ "True" == $STATUS ]; do
      sleep 1
      #kubectl -n $1 get pods
      STATUS=$(kubectl -n $1 get pods toolbox -o jsonpath='{@.status.conditions[?(@.type=="Ready")].status}' 2>/dev/null)
      #echo "Toolbox pod STATUS=$STATUS"
   done
   echo "toolbox pod is available"
}

# ARG1= namespace ARG2= pvc_name
WaitForPVCBound () {
   local STATUS="Not Bound"

   echo -n "Waiting for pvc $2 in namespace $1 to be bound..."
   until [ "Bound" == "${STATUS}" ]; do
      sleep 1
      #echo "waiting for PVC $2 to be bound"
      #kubectl -n $1 get pvc
      STATUS=$(kubectl -n $1 get pvc $2 -o jsonpath='{@.status.phase}' 2>/dev/null)
   done
   echo "pvc is bound"
}

# ARG1= namespace ARG2= script
CopyScriptToToolBoxPod () {
   echo -n "Copying backup script $2 to toolbox pod..."
   kubectl -n $1 cp $2 toolbox:/tmp/toolbox_script.sh >/dev/null 2>&1
   echo "done"
}

# ARG1= namespace
RunToolBoxScriptOnPod () {
   echo "Running backup script on toolbox pod"
   kubectl -n $1 exec toolbox -- chmod +x //tmp/toolbox_script.sh
   kubectl -n $1 exec toolbox -- //bin/bash //tmp/toolbox_script.sh
}

# ARG1= namespace
DeleteToolBoxPod () {
   echo -n "Deleting toolbox pod..."
   kubectl -n $1 delete pod toolbox --force --grace-period=0 >/dev/null 2>&1
   echo "done"
}

# ARG1= namespace
BackupPVCs () {
   local CLAIM_LIST=$( GetPersistentVolumeClaims "$1")
   #echo CLAIM_LIST=$CLAIM_LIST

   local pvc_index=$((0))
   for file in $CLAIM_LIST; do
      #echo file=$file
      local pvc_name=$(yq read $file 'metadata.name')
      #echo pvc_name=$pvc_name
      if [ "${pvc_name}" = "" ]; then
         echo "failed get the name of PVC in $1 namespace"
         exit 1
      fi

      CreateToolBoxPod $1 ${pvc_name}

      WaitForToolBoxPod $1

      WaitForPVCBound $1 ${pvc_name}

      ## Generate the backup script on host

      if [[ "true" == $FAST_PODS ]]; then
         echo -e "#!/bin/bash\necho hello\nsleep 1\n" > ${SCRIPT_ROOT}/backup_pvc.sh
      else
         cat <<< "$( GenerateBackupScript $1 ${pvc_name} ${pvc_index} )" > ${SCRIPT_ROOT}/backup_pvc.sh
      fi

      if [[ "true" == "${SHOW_YAML}" ]]; then
         cat ${SCRIPT_ROOT}/backup_pvc.sh
      fi

      CopyScriptToToolBoxPod $1 backup_pvc.sh 		# must use relative path for cygwin. kubectl does not accept unix or windows style paths :(

      RunToolBoxScriptOnPod $1

      DeleteToolBoxPod $1

      ## Delete the tmp script on host
      if [ -f ${SCRIPT_ROOT}/backup_pvc.sh ]; then
         rm ${SCRIPT_ROOT}/backup_pvc.sh
      fi

      pvc_index=$(($pvc_index+1))
      echo "#####################################################################################################"
   done
}

displaytime () {
  local T=$1
  local D=$((T/60/60/24))
  local H=$((T/60/60%24))
  local M=$((T/60%60))
  local S=$((T%60))
  (( $D > 0 )) && printf '%d days ' $D
  (( $H > 0 )) && printf '%d hours ' $H
  (( $M > 0 )) && printf '%d minutes ' $M
  (( $D > 0 || $H > 0 || $M > 0 )) && printf 'and '
  printf '%d seconds\n' $S
}

# ARG1= namespace
BackupNamespace () {
   SECONDS=0

   echo "#####################################################################################################"
   echo "Backing up namespace $1"

   export KUBECONFIG="${SOURCE_KUBECONFIG}"

   echo "#####################################################################################################"
   echo "# Backing up namespace objects and metadata"
   echo "#####################################################################################################"

   if [[ "true" == $BACKUP_OBJECTS ]]; then
      StoreClusterInfo $1
      BackupObjectYamls $1
      BackupPVCIDs $1
   fi

   echo "#####################################################################################################"
   echo "# Shutting down namespace pods"
   echo "#####################################################################################################"
   if [[ "true" == $SCALE_REPLICAS ]]; then
      ScaleReplicasToZero $1
      WaitForZeroRunningPods $1
   fi

   echo "#####################################################################################################"
   echo "# Backing up PVC's"
   echo "#####################################################################################################"

   if [[ "true" == $BACKUP_PVCS ]]; then
      BackupPVCs $1
   fi

   if [[ "true" == $RESTORE_REPLICAS ]]; then
      RestoreReplicas $1
   fi

   BACKUP_SECONDS=$SECONDS
}


# ARG1= namespace ARG2= pvc_name ARG3= pvc_index
GenerateRestoreScript () {
   local SCRIPT=$(cat <<EOF
#!/bin/bash

echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"
echo "RESTORING PVC ${pvc_name}"
echo ""



export PROJECT_NAME="$1"
# https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html#bucketnamingrules
export PROJECT_TRUNC="$(echo "$1" | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)"
export PVC_TRUNC="$(echo "$2" | awk '{print tolower($0)}' | sed 's/[_]//g' | cut -c -20)"
export PROJECT_BUCKET="$CLUSTER_NAME/$1/pvc$3--\${PROJECT_TRUNC}--\${PVC_TRUNC}--pvc$3"
export RESTIC_SNAPSHOT="latest"
export RESTIC_PASSWORD="\${PROJECT_BUCKET}"
export RESTIC_REPOSITORY="s3:${OBJECT_STORAGE_HOST_URL}/\${PROJECT_BUCKET}"
export AWS_ACCESS_KEY_ID="${MINIO_ACCESS_KEY}"
export AWS_SECRET_ACCESS_KEY="${MINIO_SECRET_KEY}"

#echo PROJECT_NAME="\${PROJECT_NAME}"
#echo PROJECT_TRUNC="\$PROJECT_TRUNC"
#echo PVC_TRUNC="\$PVC_TRUNC"
#echo PROJECT_BUCKET="\$PROJECT_BUCKET"
#echo RESTIC_SNAPSHOT="\$RESTIC_SNAPSHOT"
#echo RESTIC_PASSWORD="\$RESTIC_PASSWORD"
echo RESTIC_REPOSITORY="\$RESTIC_REPOSITORY"
#echo AWS_ACCESS_KEY_ID="\$AWS_ACCESS_KEY_ID"
#echo AWS_SECRET_ACCESS_KEY="\$AWS_SECRET_ACCESS_KEY"



echo ""
echo "Starting restore"
echo "%%%%%%%%%%%%%%%"
restic -r \${RESTIC_REPOSITORY} restore latest --target / --path "${TOOLBOX_VOLUME_MOUNT_POINT}" --cache-dir=/tmp/cache --verbose --verbose
rc=\$?
if [ \$rc -ne 0 ]; then
  echo "File restore using restic command failed with status \${rc}"
  restic unlock
  exit 1
fi
echo "%%%%%%%%%%%%%%%"
echo "Restore complete"

ls -la "${TOOLBOX_VOLUME_MOUNT_POINT}"
echo "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"

EOF
)
   cat <<< "$SCRIPT"
}

# ARG1= namespace  ARG2= pvc_name  ARG3= pvc_accessmode  ARG4= pvc_size ARG5= pvc_storageClassName
CreatePVC () {
   YAML=$(cat <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: $2
spec:
  accessModes:
  - $3
  resources:
    requests:
      storage: $4
  storageClassName: $5
EOF
)
   if [[ "true" == "${SHOW_YAML}" ]]; then
      echo YAML="${YAML}"
   fi
   if [[ "false" == $DRY_RUN ]]; then
      kubectl -n $1 create -f - <<< "$YAML" >/dev/null 2>&1
      rc=$?
      if [ $rc -ne 0 ]; then
         echo "create failed with return code $rc"
         exit $rc
      fi
   fi
}

# ARG1= namespace  ARG2= pvc_storageClassName
ConvertStorageClassName () {
   local AVAILABLE=$(kubectl -n $1 get storageclass -o jsonpath='{@.items[*].metadata.name}')

   local DEFAULT=$(echo "${AVAILABLE}" | awk '{print $1}')

   local SC
   for SC in ${AVAILABLE} ; do
      if [[ "$2" == "${SC}" ]]; then
         echo "${SC}"
         return
      fi
   done

   echo "${DEFAULT}"
}

# ARG1= namespace  ARG2= pvc file  ARG3 = pvc_index
RestorePVC () {
   local pvc_name=$(yq read $2 'metadata.name')
   if [ "${pvc_name}" = "" ]; then
       echo "failed get the name of PVC in $1 namespace"
       exit 1
   fi
   #echo -n "pvc_name=$pvc_name "

   local pvc_size=$(yq read $2 'spec.resources.requests.storage')
   if [ "${pvc_size}" = "" ]; then
       echo "failed get the size of PVC in $1 namespace"
       exit 1
   fi
   #echo -n "pvc_size=$pvc_size "

   local pvc_accessmodes=$(yq read $2 'spec.accessModes[0]')
   if [ "${pvc_accessmodes}" = "" ]; then
       echo "failed get the accessModes of PVC in $1 namespace"
       exit 1
   fi
   #echo  "pvc_accessmodes=$pvc_accessmodes "

   local pvc_storageClassName=$(yq read $2 'spec.storageClassName')
   if [ "${pvc_storageClassName}" = "" ]; then
       echo "failed get the storageClassName of PVC in $1 namespace"
       exit 1
   fi
   #echo  "pvc_storageClassName=$pvc_storageClassName "

   #ConvertStorageClassName $1 $pvc_storageClassName
   pvc_storageClassName=$(ConvertStorageClassName $1 $pvc_storageClassName)

   CreatePVC $1 ${pvc_name} ${pvc_accessmodes} ${pvc_size} ${pvc_storageClassName}

   if [[ "false" == $DRY_RUN ]]; then
      WaitForPVCBound $1 ${pvc_name}
   fi

   CreateToolBoxPod $1 ${pvc_name}

   WaitForToolBoxPod $1

   if [[ "true" == $FAST_PODS ]]; then
      echo -e "#!/bin/bash\necho hello\nsleep 1\n" > ${SCRIPT_ROOT}/restore_pvc.sh
   else
      cat <<< "$( GenerateRestoreScript $1 ${pvc_name} $3 )" > ${SCRIPT_ROOT}/restore_pvc.sh
   fi

   if [[ "true" == "${SHOW_YAML}" ]]; then
      cat ${SCRIPT_ROOT}/restore_pvc.sh
   fi

   CopyScriptToToolBoxPod $1 restore_pvc.sh

   RunToolBoxScriptOnPod $1

   DeleteToolBoxPod $1

   ## Delete restore script from host
   if [ -f ${SCRIPT_ROOT}/restore_pvc.sh ]; then
      rm -rf ${SCRIPT_ROOT}/restore_pvc.sh
   fi
}

# ARG1= namespace
RestorePVCs () {
   pvc_index=$((0))
   local filepath="${YAML_DIR}/$CLUSTER_NAME/$1"
   for file in $(ls ${filepath}/PersistentVolumeClaim*.yaml); do
      echo "#####################################################################################################"
      echo "Restoring from $file"

      RestorePVC $1 "$file" $pvc_index

      ## Increment the PVC index
      pvc_index=$(($pvc_index+1))

      echo "#####################################################################################################"

   done
}

# ARG1= namespace
SetDestinationClusterType () {
   local URL=$(kubectl cluster-info -n $1 2>&1 | grep "Kubernetes master is running at" | awk '{print $6}')

   DESTINATION_TYPE=$(GetClusterType $URL)
}

# ARG1= ID
GenerateIDPatchYaml () {
   local YAML=$(cat <<EOF
spec:
  template:
    spec:
      securityContext:
        runAsUser: $1
EOF
)
   cat <<< "$YAML"
}

# ARG1= namespace  ARG2= file
PatchDeployment () {
   local KIND=$(basename $2 | cut -d '.' -f 1)

   printd "   %s\n" "deploy patch"
   case $DESTINATION_TYPE in
      'openshift-localdev'|'openshift-prod'|'openshift-sandbox')
            #target is openshift so patch if ID file rpesent
            local NAME=$(basename $2 | cut -d '.' -f 2)
            local ID_FILE="${YAML_DIR}/$CLUSTER_NAME/$1/$KIND.$NAME.id"
            printd "%s\n" "   NAME=$NAME ID_FILE=$ID_FILE"
            if [[ -f $ID_FILE ]]; then
               local ID=$(cat $ID_FILE)
               printd "%s\n" "   ID=$ID"
               local dep=$(yq read $2 'metadata.name')
               echo "   patching deployment $dep with runAsUser $ID"
               cat <<< "$(GenerateIDPatchYaml $ID )" > ${SCRIPT_ROOT}/patch.yaml

               if [[ "true" == "${SHOW_YAML}" ]]; then
                  while IFS= read -r line; do
                     echo -e "   $line"
                  done <<< "$(cat ${SCRIPT_ROOT}/patch.yaml)"
               fi

               if [[ "true" != "${DRY_RUN}" ]]; then
                  echo -n "   "
                  kubectl -n $1 patch deployment ${dep} -p "$(cat ${SCRIPT_ROOT}/patch.yaml)"
               fi

               if [ -f ${SCRIPT_ROOT}/patch.yaml ]; then
                  rm ${SCRIPT_ROOT}/patch.yaml
               fi
            fi
         ;;
   esac
}

# ARG1= name  ARG2= host  ARG3= target port (hhtp https) ARG4= service
GenerateRouteYaml () {
   local YAML=$(cat <<EOF
apiVersion: route.openshift.io/v1
kind: Route
metadata:
  name: $1
spec:
  host: $2
  port:
    targetPort: $3
  tls:
    insecureEdgeTerminationPolicy: Redirect
    termination: edge
  to:
    kind: Service
    name: $4
    weight: 100
  wildcardPolicy: None
status:
  ingress: null
EOF
)
   cat <<< "$YAML"
}

# ARG1= namespace ARG2= file
ConvertRoute () {
   #echo "   Converting Ingress $1"

   local ROUTE_NAME=$(basename $file | cut -d '.' -f 2)
   #echo "   ROUTE_NAME=$ROUTE_NAME"

   #local HOST=$(yq read ${file} 'spec.rules.[0].host' | cut -d '.' -f 1)
   local HOST=$(yq read ${file} 'spec.rules.[0].host')
   #echo "   HOST=$HOST"

   local SERVICE_NAME_HTTP=$(yq read ${file} 'spec.rules.[0].http.paths.[0].backend.serviceName')
   #echo "   SERVICE_NAME_HTTP=$SERVICE_NAME_HTTP"

   #local SERVICE_PORT_HTTP=$(yq read ${file} 'spec.rules.[0].http.paths.[0].backend.servicePort')
   #echo "   SERVICE_PORT_HTTP=$SERVICE_PORT_HTTP"

   local SERVICE_NAME_HTTPS=$(yq read ${file} 'spec.rules.[0].https.paths.[0].backend.serviceName')
   #echo "   SERVICE_NAME_HTTPS=$SERVICE_NAME_HTTPS"

   #local SERVICE_PORT_HTTPS=$(yq read ${file} 'spec.rules.[0].https.paths.[0].backend.servicePort')
   #echo "   SERVICE_PORT_HTTPS=$SERVICE_PORT_HTTPS"

   if [[ "null" != "$SERVICE_NAME_HTTPS" ]]; then
      local SERVICE_NAME=$SERVICE_NAME_HTTPS
      #local SERVICE_PORT=$SERVICE_PORT_HTTPS
   else
      local SERVICE_NAME=$SERVICE_NAME_HTTP
      #local SERVICE_PORT=$SERVICE_PORT_HTTP
   fi


   case $CLUSTER_NAME in
      'tectonic-prod')
         HOST=$(echo "$HOST" | sed 's/.apps.k8s.ford.com//')
         ;;
      'tectonic-qa')
         HOST=$(echo "$HOST" | sed 's/.apps.qa.k8s.ford.com//')
         ;;
      'openshift-localdev')
         ;;
      'openshift-prod')
         ;;
      'openshift-sandbox')
         ;;
   esac

   case $DESTINATION_TYPE in
      'tectonic-prod'|'tectonic-qa')
         YAML="$(cat $file)"
         #echo "   patch hostname"
         ;;
      'openshift-localdev')
         HOST="$HOST.app.oc.local"
         YAML="$( GenerateRouteYaml $ROUTE_NAME $HOST http $SERVICE_NAME )"
         ;;
      'openshift-prod')
         ;;
      'openshift-sandbox')
         ;;
   esac

   if [[ "true" == "${SHOW_YAML}" ]]; then
      echo ""
      while IFS= read -r line; do
         echo -e "   $line"
      done <<< "$YAML"
      echo -n "   "
   fi

   if [[ -n "$YAML" ]]; then
      kubectl delete -n $1                  -f - <<< "$YAML" >/dev/null 2>&1
      kubectl create -n $1 --validate=false -f - <<< "$YAML"
   fi

#      'https://tectonic-k8s.k8s.ford.com:443')
#      'https://tectonic-k8s.qa.k8s.ford.com:443')
#      'https://api.oc.local:8443')
}

# ARG1= namespace
RestoreObjects () {

   for file in $(ls ${YAML_DIR}/$CLUSTER_NAME/$1/*.yaml); do

      local KIND=$(basename $file | cut -d '.' -f 1)
      local NAME=$(basename $file | cut -d '.' -f 2)

      printd "%s\n" "file=$file KIND=$KIND NAME=$NAME"

      local OWNER=$(yq read ${file} 'metadata.labels.OWNER')
      #echo OWNER=$OWNER
      #if [ "TILLER" == "${OWNER}" ]; then
      #   echo "Skipping TILLER OWNED $(basename $file)"
      #   continue
      #fi

      case $KIND in
         'PersistentVolumeClaim'|'ServiceAccount')
            echo "Skipping $KIND $(basename $file)"
            ;;
         'Ingress')
            echo -n "creating $(basename $file)..."
            ConvertRoute $1 $file
            ;;
         'Deployment')
            kubectl delete -n $1 -f $file >/dev/null 2>&1  # Delete if already exists
            echo -n "creating $(basename $file)..."
            local YAML="$(cat $file)"
            kubectl create -n $1 -f - <<< "$YAML"
            PatchDeployment $1 $file
            ;;
         *)
            kubectl delete -n $1 -f $file >/dev/null 2>&1  # Delete if already exists
            echo -n "creating $(basename $file)..."
            local YAML="$(cat $file)"
            kubectl create -n $1 -f - <<< "$YAML"
            ;;
      esac

   done
}

# ARG1= namespace
RestoreNamespace () {
   SECONDS=0

   echo "#####################################################################################################"
   echo "Restoring namespace $1"

   export KUBECONFIG="${DESTINATION_KUBECONFIG}"

   echo ""
   SetDestinationClusterType $1
   echo - "SOURCE_TYPE      = $CLUSTER_NAME"
   echo - "DESTINATION_TYPE = $DESTINATION_TYPE"

   echo "#####################################################################################################"
   echo "# Restoring PVC's"
   echo "#####################################################################################################"

   if [[ "true" == "${RESTORE_PVCS}" ]]; then
      RestorePVCs $1
   fi

   echo "#####################################################################################################"
   echo "# Restoring Objects"
   echo "#####################################################################################################"
   RestoreObjects $1

   RESTORE_SECONDS=$SECONDS
}
#############################################
# END OF FUNCTIONS
#############################################

###############################################################################################################
###                                          MAIN                                                           ###
###############################################################################################################

CheckAndSetProxies

CheckConfiguration ${NAMESPACE_NAME}

if [[ "true" == "${BACKUP}" ]]; then
   BackupNamespace ${NAMESPACE_NAME}
fi

if [[ "true" == "${RESTORE}" ]]; then
   RestoreNamespace ${NAMESPACE_NAME}
fi

echo "-----------------------------------------------------------------------------------------------------------------"
echo "Backup of namespace ${NAMESPACE_NAME} completed in $( displaytime $BACKUP_SECONDS)"
echo "Restoration of namespace ${NAMESPACE_NAME} completed in $( displaytime $RESTORE_SECONDS)"
echo "Migration of namespace ${NAMESPACE_NAME} completed in $( displaytime $(($BACKUP_SECONDS + $RESTORE_SECONDS)) )"
