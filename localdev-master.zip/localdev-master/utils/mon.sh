    export HOST_SHARE_PATH='/home/vagrant/share'
    export CAASINFRA_PULL_USER='caas-infra+image_puller'
    export CAASINFRA_PULL_TOKEN='P03D7NPEF545U7O4O16OVSGVQULEL4J2XJHFYU2KXZ8R9ZCH1TEUFM81V8AP50JY'
    export GF_NAMESPACE='cluster-ops-grafana'
    export GF_PULL_SECRET='gafana-pull-secret'
    export GF_SERVICE_ACCOUNT='grafana'
    export GF_CONTAINER_IMAGE='files.caas.ford.com/caas-infra/grafana:6.3.3'
    export GF_OAUTH_PROXY_IMAGE='registry.redhat.io/openshift3/oauth-proxy:v3.11.135'
    export GF_ROUTE_HOST='monitoring.app.caas.ford.com'
    export GF_REPLICA_COUNT=2

    # Create namespace
    if ! oc get project | grep -q ${GF_NAMESPACE}; then
        oc new-project ${GF_NAMESPACE}
    fi

    oc annotate namespace cluster-ops-grafana openshift.io/node-selector="node-role.kubernetes.io/infra=true" --overwrite

    # Create service account
    if ! oc get serviceaccounts -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${GF_NAMESPACE} | grep -qE "^${GF_SERVICE_ACCOUNT}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/sa-grafana.yaml | oc apply -f -
    fi

    # Create image pull secret
    if ! oc get secrets -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${GF_NAMESPACE} | grep -qE "^${GF_PULL_SECRET}$"; then
        ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
        oc create secret docker-registry ${GF_PULL_SECRET} \
        --docker-username="${CAASINFRA_PULL_USER}" \
        --docker-password="${CAASINFRA_PULL_TOKEN}" \
        --docker-email=mysecret@ford.com \
        --docker-server ${CAASINFRA_IMAGE_REPOSITORY} \
        --namespace=${GF_NAMESPACE}

        ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
        ## https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/
        oc secrets link ${GF_SERVICE_ACCOUNT} ${GF_PULL_SECRET} --for=pull --namespace=${GF_NAMESPACE} || true
    fi

    # Create grafana.ini secert
    if ! oc -n ${GF_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-config$"; then
        oc create secret generic grafana-config \
            --from-file=grafana.ini=${HOST_SHARE_PATH}/templates/monitoring/manifests/grafana.ini \
            --namespace ${GF_NAMESPACE}
    fi

    # Create Oauth proxy session secret
    if ! oc -n ${GF_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-proxy$"; then
        oc -n ${GF_NAMESPACE} create secret generic grafana-proxy --from-literal=session_secret=$(openssl rand -base64 32)
    fi

    # grant role to enable openshift authentication
    oc adm policy add-cluster-role-to-user system:auth-delegator -z ${GF_SERVICE_ACCOUNT} -n ${GF_NAMESPACE}

    # Default prometheus endpoint
    export OCP_PROMETHEUS_URL="https://prometheus-k8s.openshift-monitoring.svc:9091"
    # Default prometheus user and credentails, see https://access.redhat.com/solutions/{4153221,4234811} for details
    export OCP_PROM_USER=$(oc -n openshift-monitoring get secret grafana-datasources -o json | jq -r '.data["prometheus.yaml"]' | base64 -d | jq -r '.datasources[] |.basicAuthUser')
    export OCP_PROM_PASSWD=$(oc -n openshift-monitoring get secret grafana-datasources -o json | jq -r '.data["prometheus.yaml"]' | base64 -d | jq -r '.datasources[] |.basicAuthPassword')

    # Configure default grafana datasource
    if ! oc -n ${GF_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-datasources$"; then
        #envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/sec-grafana-datasources-v1.yaml | oc apply -f -
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/sec-grafana-datasources.yaml | oc apply -f -
    fi

    # Create grafana service object, note the annotation to generate self-signed cert
    if ! oc -n ${GF_NAMESPACE} get service -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/svc-grafana.yaml | oc apply -f -
    fi

    # Create grafana route object
    if ! oc -n ${GF_NAMESPACE} get route -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/ing-grafana.yaml | oc apply -f -
    fi

    # Configure default localtion to save dashboards
    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboards$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/cm-grafana-dashboards.yaml | oc create -f -
    fi

    # Load default grafana dashboards
    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-cluster-rsrc-use$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-cluster-rsrc-use \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-cluster-rsrc-use.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-node-rsrc-use$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-node-rsrc-use \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-node-rsrc-use.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-resources-cluster$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-resources-cluster \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-resources-cluster.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-resources-namespace$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-resources-namespace \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-resources-namespace.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-resources-pod$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-resources-pod \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-resources-pod.json
    fi

    # Deploy grafana deployment
    if ! oc get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${GF_NAMESPACE} | grep -qE "^grafana$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/deployment.yaml | oc apply -f -
        until [ $(oc -n ${GF_NAMESPACE} get deployment grafana -ojsonpath="{.status.conditions[?(@.type=='Available')].status}") == "True" ] > /dev/null 2>&1; do sleep 10; oc -n ${GF_NAMESPACE} get deployment grafana; done
    fi