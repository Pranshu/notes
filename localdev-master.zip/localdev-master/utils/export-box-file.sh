#!/bThin/bash

# set -xeuo pipefail

set -o errexit
set -o nounset
set -o pipefail

## OpenShift Origin
#ssh -o LogLevel=FATAL \
#    -o Compression=yes \
#    -o DSAAuthentication=yes \
#    -o IdentitiesOnly=yes \
#    -o StrictHostKeyChecking=no \
#    -o UserKnownHostsFile=/dev/null \
#    -o IdentityFile="~/.vagrant.d/insecure_private_key" \
#    vagrant@m1.oc.local \
#    -t "sudo systemctl stop origin-master-api && \
#        sudo systemctl stop origin-master-controllers && \
#        sudo systemctl stop origin-node && \
#        sudo systemctl stop docker && \
#        sudo shutdown -h -t 30"

## OpenShift Enterprise
#ssh -o LogLevel=FATAL \
#    -o Compression=yes \
#    -o DSAAuthentication=yes \
#    -o IdentitiesOnly=yes \
#    -o StrictHostKeyChecking=no \
#    -o UserKnownHostsFile=/dev/null \
#    -o IdentityFile="~/.vagrant.d/insecure_private_key" \
#    vagrant@m1.oc.local \
#    -t "sudo systemctl stop atomic-openshift-master-api && \
#        sudo systemctl stop atomic-openshift-master-controllers && \
#        sudo systemctl stop atomic-openshift-node && \
#        sudo systemctl stop docker && \
#        sudo shutdown -h -t 30"

#scp -o LogLevel=FATAL \
#    -o Compression=yes \
#    -o DSAAuthentication=yes \
#    -o IdentitiesOnly=yes \
#    -o StrictHostKeyChecking=no \
#    -o UserKnownHostsFile=/dev/null \
#    -o IdentityFile="~/.vagrant.d/insecure_private_key" \
#    vagrant@m1.oc.local:/tmp/test.yaml .

ssh -o LogLevel=FATAL \
    -o Compression=yes \
    -o DSAAuthentication=yes \
    -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="${HOME}/.vagrant.d/insecure_private_key" \
    vagrant@127.0.0.1 -p 2222

# Export prepared vagrant box
# https://www.howtoforge.com/extract-values-from-top-and-plot-them
VERSION_MAJOR='3.11'
VERSION_MINOR='104'
VERSION_RELEASE='1'
LOCAL_DEV_PROFILE='basic-cnx'
BOX_NAME="openshift-enterprise-${VERSION_MAJOR}.${VERSION_MINOR}-master"
#BOX_NAME="CaaS-localdev"
BOX_FILE="openshift-enterprise-${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.${VERSION_MINOR}-${VERSION_RELEASE}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant/boxes/${BOX_FILE}"
ssh -o LogLevel=FATAL \
    -o Compression=yes \
    -o DSAAuthentication=yes \
    -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="${HOME}/.vagrant.d/insecure_private_key" \
    vagrant@m1.oc.local \
    -t "mv /home/vagrant/share/templates/openshift/master-config.yaml /home/vagrant/share/templates/openshift/master-config.yaml.old || true && \
        sudo cp /etc/origin/master/master-config.yaml /home/vagrant/share/templates/openshift/master-config.yaml && \
        sudo oc get pods --show-labels -o wide --all-namespaces > /home/vagrant/share/pods/${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.${VERSION_MINOR}-${VERSION_RELEASE}.pods && \
        sudo docker images > /home/vagrant/share/pods/${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.${VERSION_MINOR}-${VERSION_RELEASE}.images && \
        sudo top -n 1 -b > /home/vagrant/share/pods/${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.${VERSION_MINOR}-${VERSION_RELEASE}.top && \
        sudo systemctl stop atomic-openshift-node && \
        sudo systemctl disable atomic-openshift-node && \
        sudo docker stop \$(docker ps -aq) && \
        sudo docker rm \$(docker ps -aq) && \
        sudo systemctl stop docker && \
        sudo systemctl disable docker && \
        sudo rm -rf /tmp/* && \
        sudo yum clean all && \
        sudo rm -rf /var/cache/yum && \
        sudo rm -rf /var/tmp/yum-* && \
        echo "" | sudo tee /var/log/audit/audit.log && \
        echo "" | sudo tee /var/log/wtmp && \
        echo "" | sudo tee /var/log/lastlog && \
        echo "" | sudo tee /var/log/grubby && \
        echo "" | sudo tee /var/lib/origin/audit/audit.log > /dev/null && \
        echo "" | sudo tee ~/.bash_history && history -c && \
        sudo journalctl --vacuum-time=10s"
VBoxManage controlvm "${BOX_NAME}" poweroff soft
mkdir -p "$(pwd)/vagrant/boxes"
rm -rf ${BOX_FILE}
VAGRANT_VAGRANTFILE=Vagrantfile
vagrant package --output "${BOX_FILE_PATH}" --base ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"

NEW_BOX_NAME="openshift-enterprise-${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.129-${VERSION_RELEASE}.virtualbox.box"
NEW_BOX_PATH="$(pwd)/vagrant/boxes/${NEW_BOX_NAME}"
NEW_BOX_JNAME="openshift-enterprise-${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.json"
NEW_BOX_JPATH="$(pwd)/vagrant/${NEW_BOX_JNAME}"

mv ${BOX_FILE_PATH} ${NEW_BOX_PATH}
scp ${NEW_BOX_JPATH} root@files.caas.ford.com:/tmp/${NEW_BOX_JNAME}
scp ${NEW_BOX_PATH} root@files.caas.ford.com:/tmp/${NEW_BOX_NAME}

vagrant box add ${BOX_NAME} "${BOX_FILE_PATH}"

VBoxManage startvm "${BOX_NAME}"  --type headless

# Export build-host
VERSION_MAJOR='3.11'
VERSION_MINOR='141'
VERSION_RELEASE='1'
LOCAL_DEV_PROFILE='build-host'
BOX_NAME="openshift-enterprise-${VERSION_MAJOR}.${VERSION_MINOR}-master"
BOX_FILE="openshift-enterprise-${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.${VERSION_MINOR}-${VERSION_RELEASE}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant/boxes/${BOX_FILE}"
ssh -o LogLevel=FATAL \
    -o Compression=yes \
    -o DSAAuthentication=yes \
    -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="${HOME}/.vagrant.d/insecure_private_key" \
    vagrant@m1.oc.local \
    -t "sudo docker stop \$(docker ps -aq) && \
        sudo docker rm \$(docker ps -aq) && \
        sudo systemctl stop docker && \
        sudo systemctl disable docker && \
        sudo rm -rf /tmp/* && \
        sudo yum clean all && \
        sudo rm -rf /var/cache/yum && \
        sudo rm -rf /var/tmp/yum-* && \
        echo "" | sudo tee /var/log/audit/audit.log && \
        echo "" | sudo tee /var/log/wtmp && \
        echo "" | sudo tee /var/log/lastlog && \
        echo "" | sudo tee /var/log/grubby && \
        echo "" | sudo tee /var/lib/origin/audit/audit.log > /dev/null && \
        echo "" | sudo tee ~/.bash_history && history -c && \
        sudo journalctl --vacuum-time=10s"
VBoxManage controlvm "${BOX_NAME}" poweroff soft
mkdir -p "$(pwd)/vagrant/boxes"
rm -rf ${BOX_FILE}
VAGRANT_VAGRANTFILE=Vagrantfile
vagrant package --output "${BOX_FILE_PATH}" --base ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"

NEW_BOX_JNAME="openshift-enterprise-${LOCAL_DEV_PROFILE}-${VERSION_MAJOR}.json"
scp ${NEW_BOX_JPATH} root@files.caas.ford.com:/tmp/${NEW_BOX_JNAME}
scp ${BOX_FILE_PATH} root@files.caas.ford.com:/tmp/${BOX_FILE}

#############

# Check version of VirtualBox Guest Additions
lsmod | grep -io vboxguest | xargs modinfo | grep -iw version
lsmod | grep -i vbox
sudo /usr/sbin/modinfo vboxguest

export http_proxy="http://internet.ford.com:83"
export https_proxy="http://internet.ford.com:83"
export no_proxy="localhost,127.0.0.1,.ford.com"
export OPENSHIFT_VERSION='3.11'

yum -y install yum-plugin-remove-with-leaves

# https://access.redhat.com/sites/default/files/attachments/rh_yum_cheatsheet_1214_jcs_print-1.pdf
yum -y install yum-langpacks
yum --setopt=tsflags=nodocs --setopt=override_install_langs=en_US.utf8 update -y
yum update -y
yum update -y kernel*
yum install -y epel-release
yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm

# sudo yum --disablerepo="*" --enablerepo="epel" list available
yum update -y
yum install -y wget curl gcc kernel-devel kernel-headers dkms make bzip2 perl
yum remove -y gcc kernel-devel kernel-headers dkms make


VBOX_GUESTADDTIONS_URL=https://files.caas.ford.com:9443/virtualbox/latest/VBoxGuestAdditions_6.0.12.iso
#VBOX_GUESTADDTIONS_URL=http://download.virtualbox.org/virtualbox/6.0.12/VBoxGuestAdditions_6.0.12.iso
#export VBOX_GUESTADDTIONS_URL=http://www.gsoutils.ford.com/files/openshift/VBoxGuestAdditions_5.2.20.iso
export ISO_FILE='/tmp/vboxguestadditions.iso'
KERN_DIR=/usr/src/kernels/$(uname -r);
export KERN_DIR;
curl \
    --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
    --retry "${CURL_RETRY:-5}" \
    --retry-delay "${CURL_RETRY_DELAY:-0}" \
    --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
    --insecure \
    --progress-bar \
    --location \
    --output $ISO_FILE \
    $VBOX_GUESTADDTIONS_URL
# install virtualbox guest additions
mkdir -p /tmp/vbox
mount -o loop,ro /tmp/vboxguestadditions.iso /tmp/vbox
sh /tmp/vbox/VBoxLinuxAdditions.run --nox11
#echo y|sh /tmp/vbox/VBoxLinuxAdditions.run --nox11 \
#    || echo "VBoxLinuxAdditions.run exited $? and is suppressed." \
#        "For more read https://www.virtualbox.org/ticket/12479";
umount /tmp/vbox;
rm -rf /tmp/vbox;
rm -f $ISO_FILE;

yum -y remove gcc kernel-devel kernel-headers
yum autoremove

yum -y --enablerepo='*' clean all
# Remove documentation
rm -rf /usr/share/doc/*;

# Remove unused locales
rm -rf /usr/lib/locale/*;
rm -rf /usr/share/locale/*;
localedef -c -i en_US -f UTF-8 en_US.UTF-8;

# Delete logs
find /var/log/ -name *.log -exec rm -f {} \;

# Remove old kernels
package-cleanup --oldkernels --count=1 -y;

# Zero free space to aid VM compression
dd if=/dev/zero of=/EMPTY bs=1M
rm -f /EMPTY

# Whiteout root
count=$(df --sync -kP / | tail -n1  | awk -F ' ' '{print $4}');
let count--
dd if=/dev/zero of=/tmp/whitespace bs=1024 count=$count;
rm -rf /tmp/whitespace;

# Whiteout /boot
count=$(df --sync -kP /boot | tail -n1 | awk -F ' ' '{print $4}');
let count--
dd if=/dev/zero of=/boot/whitespace bs=1024 count=$count;
rm -rf /boot/whitespace;

# Whiteout /var/lib/origin
count=$(df --sync -kP /var/lib/origin | tail -n1 | awk -F ' ' '{print $4}');
let count--
dd if=/dev/zero of=/var/lib/origin/whitespace bs=1024 count=$count;
rm -rf /var/lib/origin/whitespace;

# https://access.redhat.com/solutions/1239683
# sudo dd if=/dev/zero of=/zerofile oflag=direct

# Whiteout /var/log
count=$(df --sync -kP /var/log | tail -n1 | awk -F ' ' '{print $4}');
let count--
dd if=/dev/zero of=/var/log/whitespace bs=1024 count=$count;
rm -rf /var/log/whitespace;

# Whiteout /var/lib/etcd
count=$(df --sync -kP /var/lib/etcd | tail -n1 | awk -F ' ' '{print $4}');
let count--
dd if=/dev/zero of=/var/lib/etcd/whitespace bs=1024 count=$count;
rm -rf /var/lib/etcd/whitespace;

# Whiteout /var/etcd
count=$(df --sync -kP /var/etcd | tail -n1 | awk -F ' ' '{print $4}');
let count--
dd if=/dev/zero of=/var/etcd/whitespace bs=1024 count=$count;
rm -rf /var/etcd/whitespace;

# Whiteout /var/lib/docker
count=$(df --sync -kP /var/lib/docker | tail -n1 | awk -F ' ' '{print $4}');
let count--
dd if=/dev/zero of=/var/lib/docker/whitespace bs=1024 count=$count;
rm -rf /var/lib/docker/whitespace;

cat /dev/null > ~/.bash_history && history -c

echo "Vacuuming journalctl logs"
journalctl --vacuum-time=10s >/dev/null 2>&1


# CentOS
VBoxManage controlvm "tdev_default_1552745869727_53343" poweroff soft
VERSION='1902.01'
mkdir -p "$(pwd)/vagrant/boxes"
BOX_NAME="ford-centos"
BOX_FILE="ford-centos-${VERSION}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant/boxes/${BOX_FILE}"
vagrant package --output "${BOX_FILE_PATH}" --base "tdev_default_1552745869727_53343" ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"

# RHEL base
VBoxManage controlvm "openshift-enterprise-3.11.135-master" poweroff soft
VERSION_MAJOR='3.11'
VERSION_MINOR=''
VERSION='2019.09.08'
mkdir -p "$(pwd)/vagrant/boxes"
BOX_NAME="openshift-enterprise-${VERSION_MAJOR}"
BOX_NAME="ford-rhel7"
BOX_NAME="openshift-enterprise-3.11.135-master"
BOX_FILE="ford-rhel7-${VERSION}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant/boxes/${BOX_FILE}"
vagrant package --output "${BOX_FILE_PATH}" --base ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"


#############


docker load --input hotfix_ose-control-plane.tar
docker images brew-pulp-docker01.web.prod.ext.phx2.redhat.com:8888/openshift3/ose-control-plane

### Get the image ID for this image for the next command.

# docker tag  6b05ffa2c56f registry.redhat.io/openshift3/ose-control-plane: v3.11.16
# docker tag  1f23828b535b registry.redhat.io/openshift3/ose-control-plane:old

# mv /etc/origin/node/pods/apiserver.yaml /etc/origin/node/apiserver.yaml
# mv /etc/origin/node/apiserver.yaml /etc/origin/node/pods/apiserver.yaml      ### This will re-deploy the pod (with the new image).


source $(pwd)/RHSM.env && time VAGRANT_VAGRANTFILE=Vagrantfile.basebox vagrant up --provision
TODAY=$(date +"%Y%m%d%H%M%S")
VERSION='3.9.33'
mkdir -p "$(pwd)/vagrant-boxes/boxes"



https://kerneltalks.com/howto/how-to-enable-repository-using-subscription-manager-in-rhel/
https://access.redhat.com/solutions/1522143
https://github.com/candlepin/packer

subscription-manager repos \
    --enable="rhel-7-server-rpms" \
    --enable="rhel-7-server-extras-rpms" \
    --enable="rhel-7-server-ose-3.11-rpms" \
    --enable="rhel-7-server-ansible-2.6-rpms" \
    --enable="rhel-7-fast-datapath-rpms" \
    --enable="rh-gluster-3-client-for-rhel-7-server-rpms" \
    --enable="rhel-7-server-optional-rpms"
    subscription-manager repos \
    --disable="rhel-7-server-cnv-1.3-tech-preview-rpms"





# Origin
VERSION_MAJOR='3.9'
VERSION_MINOR='0'
mkdir -p "$(pwd)/vagrant-boxes/boxes"
TODAY=$(date +"%Y%m%d%H%M%S")
BOX_NAME="openshift-origin-${VERSION_MAJOR}"
BOX_FILE="${BOX_NAME}-r${VERSION_MINOR}-${TODAY}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant-boxes/boxes/${BOX_FILE}"
VAGRANT_VAGRANTFILE=Vagrantfile.build
OPENSHIFT_RELEASE_MAJOR_VERSION=${VERSION_MAJOR}
OPENSHIFT_RELEASE_MINOR_VERSION=${VERSION_MINOR}
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise'
OC_VERSION="${VERSION_MAJOR}.${VERSION_MINOR}"
vagrant package --output "${BOX_FILE_PATH}" --base ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"
vagrant box add ${BOX_NAME} "${BOX_FILE_PATH}"

# Enterprise slim (no CNX)
VERSION_MAJOR='3.11'
VERSION_MINOR='16-3'
mkdir -p "$(pwd)/vagrant-boxes/boxes"
TODAY=$(date +"%Y%m%d%H%M%S")
BOX_NAME="openshift-enterprise-${VERSION_MAJOR}"
#BOX_FILE="${BOX_NAME}.${VERSION_MINOR}-${TODAY}.virtualbox.box"
BOX_FILE="openshift-enterprise-nocnx-${VERSION_MAJOR}.${VERSION_MINOR}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant-boxes/boxes/${BOX_FILE}"
#VAGRANT_VAGRANTFILE=Vagrantfile.build
VAGRANT_VAGRANTFILE=Vagrantfile
OPENSHIFT_RELEASE_MAJOR_VERSION=${VERSION_MAJOR}
OPENSHIFT_RELEASE_MINOR_VERSION=${VERSION_MINOR}
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise'
OC_VERSION="${VERSION_MAJOR}.${VERSION_MINOR}"
vagrant package --output "${BOX_FILE_PATH}" --base ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"
vagrant box add ${BOX_NAME} "${BOX_FILE_PATH}"



# Enterprise slim (gfs)
VERSION_MAJOR='3.11'
VERSION_MINOR='16-3'
mkdir -p "$(pwd)/vagrant-boxes/boxes"
TODAY=$(date +"%Y%m%d%H%M%S")
BOX_NAME="openshift-enterprise-${VERSION_MAJOR}"
#BOX_FILE="${BOX_NAME}.${VERSION_MINOR}-${TODAY}.virtualbox.box"
BOX_FILE="openshift-enterprise-gfs-${VERSION_MAJOR}.${VERSION_MINOR}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant-boxes/boxes/${BOX_FILE}"
#VAGRANT_VAGRANTFILE=Vagrantfile.build
VAGRANT_VAGRANTFILE=Vagrantfile
OPENSHIFT_RELEASE_MAJOR_VERSION=${VERSION_MAJOR}
OPENSHIFT_RELEASE_MINOR_VERSION=${VERSION_MINOR}
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise'
OC_VERSION="${VERSION_MAJOR}.${VERSION_MINOR}"
vagrant package --output "${BOX_FILE_PATH}" --base ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"
vagrant box add ${BOX_NAME} "${BOX_FILE_PATH}"

systemctl stop atomic-openshift-node
systemctl disable atomic-openshift-node
docker stop $(docker ps -aq)
systemctl stop docker
systemctl disable docker
cat /dev/null > ~/.bash_history && history -c && exit
journalctl --vacuum-time=10s
VBoxManage controlvm "openshift-enterprise-3.11" poweroff soft

VERSION_MAJOR='3.11'
VERSION_MINOR='16-3'
mkdir -p "$(pwd)/vagrant-boxes/boxes"
TODAY=$(date +"%Y%m%d%H%M%S")
BOX_NAME="openshift-enterprise-${VERSION_MAJOR}"
#BOX_FILE="${BOX_NAME}.${VERSION_MINOR}-${TODAY}.virtualbox.box"
BOX_FILE="${BOX_NAME}.${VERSION_MINOR}.virtualbox.box"
BOX_FILE_PATH="$(pwd)/vagrant-boxes/boxes/${BOX_FILE}"
#VAGRANT_VAGRANTFILE=Vagrantfile.build
VAGRANT_VAGRANTFILE=Vagrantfile
OPENSHIFT_RELEASE_MAJOR_VERSION=${VERSION_MAJOR}
OPENSHIFT_RELEASE_MINOR_VERSION=${VERSION_MINOR}
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise'
OC_VERSION="${VERSION_MAJOR}.${VERSION_MINOR}"
vagrant package --output "${BOX_FILE_PATH}" --base ${BOX_NAME}
shasum -a 256 "${BOX_FILE_PATH}"
vagrant box add ${BOX_NAME} "${BOX_FILE_PATH}"

# Build basebox
source $(pwd)/RHSM.env && time VAGRANT_VAGRANTFILE=Vagrantfile.basebox vagrant up --provision
source $(pwd)/RHSM.env && time VAGRANT_VAGRANTFILE=Vagrantfile.basebox vagrant destroy -f
source $(pwd)/RHSM.env && time VAGRANT_VAGRANTFILE=Vagrantfile.basebox vagrant ssh -c 'sudo subscription-manager unregister'

time OPENSHIFT_DEPLOYMENT_TYPE='origin' vagrant up --provision
time OPENSHIFT_DEPLOYMENT_TYPE='origin' vagrant destroy -f
time OPENSHIFT_DEPLOYMENT_TYPE='origin' vagrant ssh -c "watch --color -n 1 docker images"
time OPENSHIFT_DEPLOYMENT_TYPE='origin' vagrant ssh -c "sudo su - -c 'oc get pods --all-namespaces'"
time OPENSHIFT_DEPLOYMENT_TYPE='origin' vagrant ssh -- -t "sudo su - -c 'watch --color -d -n 1 oc get pods --all-namespaces'"

# Enterprise v3.10.14
time \
VAGRANT_VAGRANTFILE=Vagrantfile.build \
OPENSHIFT_RELEASE_MAJOR_VERSION='3.10' \
OPENSHIFT_RELEASE_MINOR_VERSION='14' \
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise' \
OC_VERSION='3.10.14' \
KUBECTL_VERSION='1.10.6' \
vagrant up --provision

# Enterprise v3.9.40
time \
VAGRANT_VAGRANTFILE=Vagrantfile.build \
OPENSHIFT_RELEASE_MAJOR_VERSION='3.9' \
OPENSHIFT_RELEASE_MINOR_VERSION='40' \
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise' \
OC_VERSION='3.9.40' \
KUBECTL_VERSION='1.9.9' \
vagrant up --provision

# Origin
time \
VAGRANT_VAGRANTFILE=Vagrantfile.build \
OPENSHIFT_RELEASE_MAJOR_VERSION='3.10' \
OPENSHIFT_RELEASE_MINOR_VERSION='0' \
OPENSHIFT_DEPLOYMENT_TYPE='origin' \
OC_VERSION='3.10.14' \
KUBECTL_VERSION='1.10.6' \
vagrant up --provision

# Run
time \
OPENSHIFT_RELEASE_MAJOR_VERSION='3.10' \
OPENSHIFT_RELEASE_MINOR_VERSION='14' \
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise' \
OC_VERSION='3.10.14' \
KUBECTL_VERSION='1.10.6' \
vagrant up --provision

time \
OPENSHIFT_RELEASE_MAJOR_VERSION='3.9' \
OPENSHIFT_RELEASE_MINOR_VERSION='40' \
OPENSHIFT_DEPLOYMENT_TYPE='openshift-enterprise' \
OC_VERSION='3.9.40' \
KUBECTL_VERSION='1.9.9' \
vagrant up --provision



VBoxManage controlvm "openshift-enterprise-3.11" poweroff soft
VBoxManage startvm "openshift-enterprise-3.11"  --type headless

export http_proxy="http://internet.ford.com:83"
export https_proxy="http://internet.ford.com:83"
export no_proxy="localhost,127.0.0.1,.ford.com"
export OPENSHIFT_VERSION='3.11'

#
yum update -y
yum update -y kernel*
yum install -y epel-release
yum install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
# sudo yum --disablerepo="*" --enablerepo="epel" list available
yum update -y
yum install -y wget curl gcc kernel-devel kernel-headers dkms make bzip2 perl

yum --enablerepo=rhel-7-server-rpms clean metadata

VBOX_GUESTADDTIONS_URL=https://files.caas.ford.com:9443/virtualbox/latest/VBoxGuestAdditions_6.0.2.iso
#VBOX_GUESTADDTIONS_URL=http://download.virtualbox.org/virtualbox/5.2.22/VBoxGuestAdditions_5.2.22.iso
#export VBOX_GUESTADDTIONS_URL=http://www.gsoutils.ford.com/files/openshift/VBoxGuestAdditions_5.2.18.iso
export ISO_FILE=/tmp/vboxguestadditions.iso
KERN_DIR=/usr/src/kernels/$(uname -r);
export KERN_DIR;
curl \
    --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
    --retry "${CURL_RETRY:-5}" \
    --retry-delay "${CURL_RETRY_DELAY:-0}" \
    --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
    --insecure \
    --progress-bar \
    --location \
    --output $ISO_FILE \
    $VBOX_GUESTADDTIONS_URL

# Uninstall virtualbox guest additions
mkdir -p /tmp/vbox
mkdir -p /tmp/vbox
mount -o loop,ro "$ISO_FILE" /tmp/vbox
sh /tmp/vbox/VBoxLinuxAdditions.run uninstall
#echo y|sh /tmp/vbox/VBoxLinuxAdditions.run uninstall \
#    || echo "VBoxLinuxAdditions.run exited $? and is suppressed." \
#        "For more read https://www.virtualbox.org/ticket/12479";
umount /tmp/vbox;
rm -rf /tmp/vbox;
rm -f $ISO_FILE;
VBoxManage controlvm "openshift-enterprise-${OPENSHIFT_VERSION}" poweroff soft

VBoxManage startvm "openshift-enterprise-${OPENSHIFT_VERSION}"  --type headless


kernel-headers-3.10.0-957.el7.x86_64
kernel-devel-3.10.0-957.el7.x86_64
kernel-tools-libs-3.10.0-957.el7.x86_64
kernel-tools-3.10.0-957.el7.x86_64
kernel-3.10.0-957.el7.x86_64

export http_proxy="http://internet.ford.com:83"
export https_proxy="http://internet.ford.com:83"
export no_proxy="localhost,127.0.0.1,.ford.com"
export OPENSHIFT_VERSION='3.11'



##########



#modprobe vboxdrv
#dkms

VBoxManage controlvm "openshift-enterprise-${OPENSHIFT_VERSION}" poweroff soft

VBoxManage startvm "openshift-enterprise-${OPENSHIFT_VERSION}"  --type headless
curl \
    --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
    --retry "${CURL_RETRY:-5}" \
    --retry-delay "${CURL_RETRY_DELAY:-0}" \
    --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
    --insecure \
    --progress-bar \
    --location \
    --output /usr/local/bin/jq \
    https://github.com/stedolan/jq/releases/download/jq-1.5/jq-linux64
chmod +x /usr/local/bin/jq
VBoxManage controlvm "openshift-enterprise-${OPENSHIFT_VERSION}" poweroff soft
