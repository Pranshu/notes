# ETCD
- [How do I restore from an etcd backup in OpenShift](https://access.redhat.com/solutions/4013381)
- [Extend ETCD Database Quota](https://access.redhat.com/solutions/4176411)
- [How do I remove and add back an existing etcd member for the OpenShift cluster?](https://access.redhat.com/solutions/4029781)
- [OpenShift 3.11 Replacing a failed etcd member showed request cluster ID mismatch error](https://access.redhat.com/solutions/4307491)


# Monitoring
- [How to edit the Prometheus Alertmanager configuration](https://access.redhat.com/solutions/3804781)
- [How long can data keep for Alertmanager ?](https://access.redhat.com/solutions/4289251)


# Logging
- [Elasticsearch logs intermittently drop out in Kibana - connection is successful](https://access.redhat.com/solutions/4225951)
- [Openshift Logging stack is flooded with operations messages](https://access.redhat.com/solutions/4345851)
- [OpenShift 3.10/3.11 Logging Inventory Variables to Use In Place of openshift_logging_image_prefix](https://access.redhat.com/solutions/4102981)
- [Troubleshooting OpenShift Container Platform 3.x: Aggregating Container Logging](https://access.redhat.com/articles/3136551)
- [OpenShift Authentication Logs](https://access.redhat.com/solutions/2174381)
- [How do I reset a user's kibana indexes?](https://access.redhat.com/solutions/4306351)


# Builds
- [How to use container images across different projects](https://access.redhat.com/solutions/4254211)
- [How to use proxies when using Build Configurations in OpenShift?](https://access.redhat.com/solutions/1575513)
- [Unable to assign system:deployer role to a service account](https://access.redhat.com/solutions/3827841)
- [How to use credentials in User scope stored on Jenkins of OpenShift?](https://access.redhat.com/solutions/4319951)


# Certificates
- [How to add custom certificates for OpenShift Web Console running in a Pod on OpenShift 3.9+](https://access.redhat.com/solutions/4188671)
- [Can the same certificate be used for OpenShift services router, docker-registry and registry-console?](https://access.redhat.com/solutions/4267102)
- [How can I manually replace 3.10 or 3.11 node certificates](https://access.redhat.com/solutions/3821042)
- [How to renew and redeploy internal logging certificates in OpenShift](https://access.redhat.com/solutions/4233251)


# Router
- [Redeploy the application HAProxy routers in OpenShift](https://access.redhat.com/solutions/4251781)
- [OpenShift Web Console doesn't logout while using OpenID or Single Sign-On (SSO)](https://access.redhat.com/solutions/4349271)
- [Performance Scaling HAProxy with OpenShift](https://access.redhat.com/articles/3428361)


# Registry
- [How to use a hostPath volume as persistent storage in OpenShift container image registry](https://access.redhat.com/solutions/4216161)
- [How to change the registry-console route hostname on OCP3](https://access.redhat.com/solutions/4358991)
- [Registry unable to access S3 bucket in OpenShift 3.9](https://access.redhat.com/solutions/4356111)
- [How point to the new registry.redhat.io registry](https://access.redhat.com/solutions/3990441)
- [Cannot Assign Static IP Address to Nodes](https://access.redhat.com/solutions/4175151)


# OCP4
- [Master KCS Article OpenShift Container Platform 4.x](https://access.redhat.com/articles/4217411)
- [How do I see what is happening with my UPI install](https://access.redhat.com/solutions/4139361)
- [Troubleshooting OpenShift Container Platform 4.x: UPI Installation](https://access.redhat.com/articles/4292081)
- [How to shutdown all OpenShift hosts safely in OpenShift 4.1?](https://access.redhat.com/solutions/4218311)
- [Openshift 4 unable to update infra nodes](https://access.redhat.com/solutions/4342791)
- [Example Ignition Configs](https://coreos.com/ignition/docs/latest/examples.html#set-the-hostname)
- [How to configure the Image Registry to use user-created PVC in OpenShift 4.x?](https://access.redhat.com/solutions/4348211)
- [Node is Ignited but Does not Join Cluster](https://access.redhat.com/solutions/4335971)
- [Accessing the RHCOS Console](https://access.redhat.com/solutions/4307591)
- [OpenShift 4 Bare Metal control plane setup fails due to x509: certificate signed by unkonwn authority](https://access.redhat.com/solutions/4271572)


# DNS
- [Slow DNS resolution or queries for OpenShift 3.X services](https://access.redhat.com/solutions/3827421)
- [Why do pods/containers started by OpenShift have the option ndots=5 in their /etc/resolv.conf?](https://access.redhat.com/solutions/2518321)
- [How to add or modify custom DNS servers on OpenShift](https://access.redhat.com/solutions/4035111)


# General
- [Pods are stuck in "ContainerCreating" status when an OpenShift node's /var/log partition is full](https://access.redhat.com/solutions/4358291)
- [What is the correct syntax for OpenShift inventory file variables openshift_release, openshift_pkg_version, and openshift_image_tag?](https://access.redhat.com/solutions/3662771)
- [OpenShift Installation Fails with "One or more required container images are not available: registry.redhat.io/openshift3/ose-$<component>:$<version>"](https://access.redhat.com/solutions/4357461)
- [Is it possible to only use the internal master URL for OAuth in OpenShift's monitoring component?](https://access.redhat.com/solutions/4358271)
- [Red Hat Container Registry Authentication](https://access.redhat.com/RegistryAuthentication)
- [ClusterRole to manage template in Openshift](https://access.redhat.com/solutions/4058721)
- [Troubleshooting OpenShift Container Platform 3.x: Basics](https://access.redhat.com/solutions/1542293)
- [Configure log levels for OpenShift Container Platform](https://access.redhat.com/solutions/2216951#builder)
- [Which files belongs to OpenShift in cluster nodes?](https://access.redhat.com/solutions/4349291)
- [Can we use Operator Lifecycle Management behind private registry](https://access.redhat.com/solutions/4349011)
- [Token Activity Timeout for OpenShift 3.x](https://access.redhat.com/solutions/4318551)
- [What ports need to be open for a standard Prometheus installation on top of OpenShift?](https://access.redhat.com/solutions/3626161)
- [Pod ignores drain node command and still on the running state](https://access.redhat.com/solutions/4289361)


# Audit
- [Configure Advanced Audit to send the audit logs to external logging aggregator](https://access.redhat.com/solutions/4345181)
