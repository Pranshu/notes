#!/bin/bash

while true; do
    if /opt/var/ping/tcping 19.2.39.193 50000 | grep 'failed:'; then
        echo "$(date -u +'%Y-%m-%d %H:%M:%S') ========== " >> /opt/var/nginx/www/debug/log.txt
        /opt/var/ping/tcping 19.2.39.193 50000 -c 1 >> /opt/var/nginx/www/debug/log.txt
        echo ""
        mtr -rwb 19.2.39.193 >> /opt/var/nginx/www/debug/log.txt
        mtr --report --tcp --port 50000 19.2.39.193 >> /opt/var/nginx/www/debug/log.txt
        #traceroute 19.2.39.193 >> /opt/var/nginx/www/debug/log.txt
        echo "" >> /opt/var/nginx/www/debug/log.txt
    fi

    if /opt/var/ping/tcping 19.2.47.137 8080 | grep 'failed:'; then
        echo "$(date -u +'%Y-%m-%d %H:%M:%S') ========== " >> /opt/var/nginx/www/debug/log.txt
        /opt/var/ping/tcping 19.2.47.137 8080 -c 1 >> /opt/var/nginx/www/debug/log.txt
        echo ""
        mtr --report --tcp --port 8080 19.2.47.137 >> /opt/var/nginx/www/debug/log.txt
        mtr -rwb 19.2.47.137 >> /opt/var/nginx/www/debug/log.txt
        #traceroute 19.2.47.137  >> /opt/var/nginx/www/debug/log.txt
        echo "" >> /opt/var/nginx/www/debug/log.txt
    fi

    sleep 1;
done

#!/bin/bash

# 19.2.39.193:50000 Jenkins slave agent (TCP)
# 19.2.46.131:8080 Jenkins master (HTTP)
# 19.2.47.137:8080 HTTP Echo (HTTP)
# 19.2.41.115:9200 ElasticSearch (TCP)
# 19.2.35.104:8443 Ceph dashboard (HTTP)
# 19.2.39.13:9091 Prometheus (TCP)

declare -A ENDPOINT=( [19.2.39.193]=50000 \
                        [19.2.46.131]=8080 \
                        [19.2.47.137]=8080 \
                        [19.2.35.104]=8443 \
                        [19.2.41.115]=9200 \
                        [19.2.39.13]=9091 )
while true; do
    for K in "${!ENDPOINT[@]}"; do
        #echo $K --- ${ENDPOINT[$K]};
        if ! nc -vz -w 1 ${K} ${ENDPOINT[$K]} > /dev/null 2>&1; then
            #echo "Hello $K --- ${ENDPOINT[$K]}";
            echo "IP:${K} PORT:${ENDPOINT[$K]} $(date -u +'%Y-%m-%d %H:%M:%S') ========== " >> /opt/var/nginx/www/debug/log.txt
            mtr -rwb ${K} >> /opt/var/nginx/www/debug/log.txt
            echo ""
            mtr --report --tcp --port ${ENDPOINT[$K]} ${K} >> /opt/var/nginx/www/debug/log.txt
            echo ""
            echo ""
        fi
    done
    sleep 1
done

oc -n osba-demo policy add-role-to-user ns-admin pmereddy

export https_proxy=http://proxyvipfmcc.nb.ford.com:83
date; wget https://services.gradle.org/distributions/gradle-5.0-all.zip; date”
date; unzip ./gradle-5.0-all.zip -d ./gradle; date”

https://access.redhat.com/errata/RHBA-2019:0636
https://access.redhat.com/errata/RHBA-2019:0637