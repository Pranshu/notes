set -o errexit
set -o nounset
set -o pipefail

SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd -P )

i=$((0))
OLDIFS=$IFS
IFS=$'\n'
for n in $(kubectl get -o=custom-columns=KIND:.kind,NAME:.metadata.name --no-headers clusterrole,clusterrolebinding,crd); do
    kind=$(echo "$n" | tr -s ' ' | cut -d' ' -f 1)
    name=$(echo "$n" | tr -s ' ' | cut -d' ' -f 2)
    mkdir -p ${SCRIPT_ROOT}/$kind
    if [ "${kind}" != "clusterroles" ]; then
        kubectl get $kind -o=yaml $name > ${SCRIPT_ROOT}/$kind/$kind.$name.yaml
    else
        kubectl get $kind -o=yaml --export $name > ${SCRIPT_ROOT}/$kind/$kind.$name.yaml
    fi
done
IFS=$OLDIFS

i=$((0))
OLDIFS=$IFS
IFS=$'\n'
#secret
for n in $(kubectl -n kubeflow get -o=custom-columns=NAMESPACE:.metadata.namespace,KIND:.kind,NAME:.metadata.name --no-headers pvc,configmap,ingress,service,deployment,statefulset,hpa,job,cronjob,role,rolebinding,serviceaccount); do
    namespace=$(echo "$n" | tr -s ' ' | cut -d' ' -f 1)
    kind=$(echo "$n" | tr -s ' ' | cut -d' ' -f 2)
    name=$(echo "$n" | tr -s ' ' | cut -d' ' -f 3)
    #echo "${namespace}, ${kind}, ${name}"
    mkdir -p ${SCRIPT_ROOT}/$namespace
    if [ "${kind}" != "roles" ]; then
        kubectl get $kind -o=yaml $name -n $namespace > ${SCRIPT_ROOT}/$namespace/$kind.$name.yaml
    else
        kubectl get $kind -o=yaml --export $name -n $namespace > ${SCRIPT_ROOT}/$namespace/$kind.$name.yaml
    fi
done
IFS=$OLDIFS

