oc new-project was-engineering
oc apply -f systemtest.yaml

horizontalpodautoscaler.autoscaling/systemtest-autoscaler created
configmap/systemtest created
persistentvolumeclaim/persistence created
persistentvolumeclaim/dumps created
route.route.openshift.io/systemtest-tls-edge created
secret/smikishk-ptmp-image-pull-pull-secret created
secret/tls-passthrough created
secret/sts-secrets created
service/systemtest created
statefulset.apps/systemtest-efk created