- https://docs.openshift.com/container-platform/3.11/install_config/registry/index.html
- https://docs.openshift.com/container-platform/3.11/install_config/registry/securing_and_exposing_registry.html
- https://docs.openshift.com/container-platform/3.11/admin_guide/image_policy.html
- https://docs.openshift.com/container-platform/3.11/install_config/registry/accessing_registry.html#access-user-prerequisites

oc adm registry --config=/etc/origin/master/admin.kubeconfig \
  --service-account=registry \
  --images='registry.redhat.io/openshift3/ose-${component}:${version}' \
  --dry-run=true \
  --output=yaml > o.yaml

oc adm registry --config=/etc/origin/master/admin.kubeconfig \
  --service-account=registry \
  --images='registry.redhat.io/openshift3/ose-${component}:${version}' \
  --dry-run=true \
  --output=yaml > o.yaml
  --tls-certificate=/path/to/pem-encode.cert \
  --tls-key=/path/to/pem-encode.key \

oc create -f /home/vagrant/share/templates/registry/manifests/registry.yaml

oc adm ca create-server-cert \
    --signer-cert=/etc/origin/master/ca.crt \
    --signer-key=/etc/origin/master/ca.key \
    --signer-serial=/etc/origin/master/ca.serial.txt \
    --hostnames='docker-registry.default.svc.cluster.local,docker-registry.default.svc,172.30.124.220' \
    --cert=/etc/secrets/registry.crt \
    --key=/etc/secrets/registry.key

oc create secret generic registry-certificates \
    --from-file=/etc/secrets/registry.crt \
    --from-file=/etc/secrets/registry.key

oc secrets link registry registry-certificates
oc secrets link default  registry-certificates

oc rollout pause dc/docker-registry

oc set volume dc/docker-registry --add --type=secret \
    --secret-name=registry-certificates -m /etc/secrets

oc set env dc/docker-registry \
    REGISTRY_HTTP_TLS_CERTIFICATE=/etc/secrets/registry.crt \
    REGISTRY_HTTP_TLS_KEY=/etc/secrets/registry.key

oc patch dc/docker-registry -p '{"spec": {"template": {"spec": {"containers":[{
    "name":"registry",
    "livenessProbe":  {"httpGet": {"scheme":"HTTPS"}}
  }]}}}}'

oc patch dc/docker-registry -p '{"spec": {"template": {"spec": {"containers":[{
    "name":"registry",
    "readinessProbe":  {"httpGet": {"scheme":"HTTPS"}}
  }]}}}}'

oc rollout resume dc/docker-registry

oc logs dc/docker-registry | grep tls

dcertsdir=/etc/docker/certs.d
destdir_addr=$dcertsdir/$(oc -n default get svc docker-registry -o json | jq -r '.spec.clusterIP'):5000
destdir_name=$dcertsdir/docker-registry.default.svc.cluster.local:5000
sudo mkdir -p $destdir_addr $destdir_name
sudo cp  /etc/origin/master/ca.crt $destdir_addr
sudo cp  /etc/origin/master/ca.crt $destdir_name

\cp /etc/origin/master/ca.crt /etc/pki/ca-trust/source/anchors/registry.oc.local.crt
update-ca-trust enable

sudo systemctl daemon-reload
sudo systemctl restart docker

sed -i "/- docker-registry.default.svc:5000/i \          - $(oc -n default get svc docker-registry -o json | jq -r '.spec.clusterIP'):5000" /etc/origin/master/master-config.yaml
sed -i "/- domainName: docker-registry.default.svc:5000/i \  - domainName: $(oc -n default get svc docker-registry -o json | jq -r '.spec.clusterIP'):5000" /etc/origin/master/master-config.yaml
/usr/local/bin/master-restart api
/usr/local/bin/master-restart controllers

docker pull busybox
docker tag docker.io/busybox:latest docker-registry.default.svc:5000/openshift/busybox

docker login -u openshift -p $(oc whoami -t) docker-registry.default.svc:5000
docker push docker-registry.default.svc:5000/openshift/busybox


oc new-app -n default --template=registry-console \
    -p OPENSHIFT_OAUTH_PROVIDER_URL="https://api.oc.local:8443" \
    -p REGISTRY_HOST=$(oc get route docker-registry -n default --template='{{ .spec.host }}') \
    -p COCKPIT_KUBE_URL=$(oc get route registry-console -n default --template='https://{{ .spec.host }}')
