## Minimum Requirements
- Working [OpenShift localdev](https://github.ford.com/Containers/localdev) if you do not have one please install.
- Copy the file `<localdev-dir>/envs/quay.env.template` to `<localdev-dir>/envs/quay.env` update all fields

> ⚠ __NOTE__: You must replace the string `<localdev-dir>` above with absolute path to where you have cloned the localdev repository on your system.

## Quay installation and upgrade procedure
1. Start localdev instance
1. `vagrant ssh` into the localdev vm

## Login to target cluster
> 💡This is step is __not__ required when installing Quay localdev
```bash
sudo su -

## Production Cluster
oc login https://api.caas.ford.com

## NGLAB Cluster
oc login https://api.caas.nglab.ford.com
```

## Signed certificates
> 💡This is step is __not__ required when installing Quay localdev

You must manually place pem encode root ca certificates in
- `<localdev-dir>/envs/certs/ca/ca.key`

You must manually place pem encode dex certificates in
  - `<localdev-dir>/envs/certs/dex.caas.ford.com/dex.caas.ford.com.pem`
  - `<localdev-dir>/envs/certs/dex.caas.ford.com/dex.caas.ford.com.key`

You must manually place pem encode quay certificates in
  - `<localdev-dir>/envs/certs/registry.ford.com/registry.ford.com.pem`
  - `<localdev-dir>/envs/certs/registry.ford.com/registry.ford.com.key`

You must manually place pem encode clair certificates in
  - `<localdev-dir>/envs/certs/clair.caas.ford.com/clair.caas.ford.com.pem`
  - `<localdev-dir>/envs/certs/clair.caas.ford.com/clair.caas.ford.com.key`

## Backup existing quay database
> 💡This is step is __not__ required when installing Quay localdev
```bash
HOST_SHARE_PATH='/home/vagrant/share'
namespace='quay-enterprise'
db_to_backup='quaydb'
db_cluster_name='quay-db'
db_backup_dir=${HOST_SHARE_PATH}/envs/quay_db_backups
set -a; source ${HOST_SHARE_PATH}/envs/quay.env; set +a;
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
backup_quay_database 'quay-enterprise' ${db_to_backup} ${db_cluster_name} ${db_backup_dir}

```

## Export existing objects in quay-enterprise namespace
> 💡This is step is __not__ required when installing Quay localdev
```bash
HOST_SHARE_PATH='/home/vagrant/share'
namespace='quay-enterprise'
nsexports_dir=${HOST_SHARE_PATH}/envs/nsexports
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
export_namespace ${namespace} ${nsexports_dir}

oc -n quay-enterprise get pvc -o yaml --export > ${nsexports_dir}/current-pvc.yml
```

## Purge existing objects in quay-enterprise namespace
> 💡This is step is __not__ required when installing Quay localdev
```bash
HOST_SHARE_PATH='/home/vagrant/share'
namespace='quay-enterprise'
nsexports_dir=${HOST_SHARE_PATH}/envs/nsexports
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
purge_namespace ${namespace} ${nsexports_dir}
```

## Install Quay
```bash
HOST_SHARE_PATH='/home/vagrant/share'
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
install_quay ${HOST_SHARE_PATH}/envs/quay.env
```

### Install Clair
After Quay is setup navigate to `https://<QUAY-URL>/superuser/?tab=servicekeys` setup Clair jwt token, use following:
```bash
Key Name: clair-scanner
Service Name: clair_scanner
Expires: current date + 1 day
Approval Notes: This is jwt token for clair security scanner
```
Download the file `clair-scanner.pem` and copy the key-id from the Quay interface and update the `${HOST_SHARE_PATH}/envs/quay.env`. Now we are ready to install and configure quay using the following steps

```bash
HOST_SHARE_PATH='/home/vagrant/share'
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
install_clair ${HOST_SHARE_PATH}/envs/quay.env
```
### Scale Quay DB instance
Scale up Quay's Crunchy PostgreSQL instance
```bash
HOST_SHARE_PATH='/home/vagrant/share'
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
set -a; source ${HOST_SHARE_PATH}/envs/quay.env; set +a;
source ${GOPATH}/pgopenv
pgo scale ${QUAY_PGCLUSTER_NAME} --resources-config=${DEFAULT_POD_CLASS} --replica-count=1
```

### Clean up old PVC
```bash
oc -n quay-enterprise get pvc -o yaml --export > ${HOST_SHARE_PATH}/envs/nsexports/current-pvc.yml
```


## Test

## API Test

## Push Image
```
export http_proxy="http://internet.ford.com:83"
export https_proxy="http://internet.ford.com:83"
export no_proxy="localhost,127.0.0.1,.ford.com,.local.svc,.app.oc.local"
skopeo copy \
    --dest-tls-verify=false \
    --dest-creds baseos+token:ZLQAPB6HA8LL08OU07K65ZQP1PEQZTHBIHFV612C3655WL051HG8YHBUB9ZKDLHU \
    docker://quay.io/coreos/dex:v2.0.0 docker://registry.app.oc.local/baseos/dex:v2.0.0
```
## Pull Image

## Refs
- [Red Hat Quay on OpenShift configuration files](https://access.redhat.com/documentation/en-us/red_hat_quay/3/html-single/deploy_red_hat_quay_on_openshift/index#appendix_a_red_hat_quay_on_openshift_configuration_files)


<!--
export QUAY_NAMESPACE='quay-enterprise'
kubectl proxy &>/dev/null &
PROXY_PID=$!
kubectl get namespace "$QUAY_NAMESPACE" -o json | jq 'del(.spec.finalizers[] | select("kubernetes"))' | curl -s -k -H "Content-Type: application/json" -X PUT -o /dev/null --data-binary @- http://localhost:8001/api/v1/namespaces/$QUAY_NAMESPACE/finalize && echo "Killed namespace: $QUAY_NAMESPACE"
kill $PROXY_PID
oc delete namespace $QUAY_NAMESPACE
oc -n quay-enterprise get pods -o=custom-columns=NAME:.metadata.name --no-headers | xargs -I {} oc -n quay-enterprise delete pod --force --grace-period=0 {}
-->