#!/bin/bash

set -o errexit
set -o nounset
set -o pipefail

export UPGRADE_OPENSHIFT_TO='3.11.141'

export INVENTORY_FILE='/home/vagrant/inventory.ini'
export HOST_SHARE_PATH='/home/vagrant/share'
export ANSIBLE_ROOT='/usr/share/ansible/'
export ANSIBLE_CONFIG=${HOST_SHARE_PATH}/templates/ansible.cfg

export http_proxy="http://internet.ford.com:83"
export https_proxy="http://internet.ford.com:83"
export no_proxy="127.0.0.1,localhost,.local,.svc,.ford.com,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16"

export REG_AUTH_USER=$(cat /root/.docker/config.json | jq -r '.auths."registry.redhat.io".auth' | base64 --decode | cut -d ':' -f1)
export REG_AUTH_PASSWORD=$(cat /root/.docker/config.json | jq -r '.auths."registry.redhat.io".auth' | base64 --decode | cut -d ':' -f2)

##rpm -qa --queryformat '%{name}|%{version}|%{release}|%{arch}.rpm\n' | grep atomic-openshift-node
#CURRENT_OPENSHIFT_VERSION=$(rpm -qi atomic-openshift-node | grep 'Version' | awk '{print $3}')
#CURRENT_REL_VERSION=$(echo ${CURRENT_OPENSHIFT_VERSION} | awk -F '.' '{print $3}')
#CURRENT_REL_VERSION='104'
#UPGRADE_REL_VERSION=$(echo ${UPGRADE_OPENSHIFT_TO} | awk -F '.' '{print $3}')

# Pre-pull 3.11.129 images
docker images --format "{{.Repository}}:{{.Tag}}" | \
    grep -i 104 | sed "s|104|141|g" | xargs -L1 docker pull

# Update openshift ansible
yum install -y openshift-ansible-3.11.141

# Remove upstream calico playbook
rm -rf ${ANSIBLE_ROOT}/openshift-ansible/roles/calico
rm -rf ${ANSIBLE_ROOT}/openshift-ansible/roles/calico-node
rm -rf ${ANSIBLE_ROOT}/openshift-ansible/roles/calico_master

# Copy vendored calico playbook
rsync -rIq ${HOST_SHARE_PATH}/ansible/roles-3.11/ ${ANSIBLE_ROOT}/openshift-ansible/roles/
rsync -Iq ${HOST_SHARE_PATH}/ansible/playbooks-3.11/upgrade-calico.yaml ${ANSIBLE_ROOT}/openshift-ansible/playbooks/upgrade-calico.yaml

# Update openshift to v3.11.141
ansible-playbook -i ${INVENTORY_FILE} \
    -e "openshift_release='3.11'" \
    -e "openshift_image_tag=v3.11.141" \
    -e "openshift_pkg_version=-3.11.141" \
    -e "oreg_auth_user='${REG_AUTH_USER}'" \
    -e "oreg_auth_password='${REG_AUTH_PASSWORD}'" \
    -e 'openshift_rolling_restart_mode=services' \
    -e "openshift_enable_service_catalog=false" \
    -e "template_service_broker_install=false" \
    -e "ansible_service_broker_install=false" \
    ${ANSIBLE_ROOT}/openshift-ansible/playbooks/byo/openshift-cluster/upgrades/v3_11/upgrade.yml

# Update kube-proxy
#oc get is node -n kube-proxy-and-dns -o yaml --export | sed 's|v3.11.104|v3.11.141|' | oc apply -f -
oc delete ClusterRoleBinding proxy-cluster-reader
oc delete ClusterRoleBinding proxy-reader
oc delete -n kube-proxy-and-dns istag node:v3.10 --ignore-not-found
oc delete serviceaccount proxy -n kube-proxy-and-dns
oc delete namespace kube-proxy-and-dns --wait=false
${HOST_SHARE_PATH}/utils/kill-kube-ns kube-proxy-and-dns
until oc get namespace kube-proxy-and-dns; do echo "Waiting "; sleep 5; done
oc create namespace kube-proxy-and-dns
oc adm policy add-scc-to-user privileged system:serviceaccount:kube-proxy-and-dns:proxy -n kube-proxy-and-dns
cat ${HOST_SHARE_PATH}/templates/kube-proxy-and-dns/is.yaml | sed 's|v3.11.104|v3.11.141|' | oc create -f -
oc create -f ${HOST_SHARE_PATH}/templates/kube-proxy-and-dns/sa_rbac.yaml
oc create -f ${HOST_SHARE_PATH}/templates/kube-proxy-and-dns/ds.yaml

# Uninstall metrics
ansible-playbook -i ${INVENTORY_FILE} \
    -e "oreg_auth_user='${REG_AUTH_USER}'" \
    -e "oreg_auth_password='${REG_AUTH_PASSWORD}'" \
    -e 'openshift_rolling_restart_mode=services' \
    -e "openshift_metrics_install_metrics=false" \
    -e "openshift_metrics_heapster_standalone=false" \
    -e "openshift_metrics_server_install=false" \
    ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-metrics/config.yml

# Install metrics
ansible-playbook -i ${INVENTORY_FILE} \
    -e "openshift_release='3.11'" \
    -e "openshift_image_tag=v3.11.141" \
    -e "openshift_pkg_version=-3.11.141" \
    -e "oreg_auth_user='${REG_AUTH_USER}'" \
    -e "oreg_auth_password='${REG_AUTH_PASSWORD}'" \
    -e 'openshift_rolling_restart_mode=services' \
    -e "openshift_metrics_install_metrics=true" \
    -e "openshift_metrics_heapster_standalone=true" \
    -e "openshift_metrics_server_install=true" \
    ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-metrics/config.yml

# https://access.redhat.com/support/cases/#/case/02288631?commentId=a0a2K00000OsM8YQAV
# Remove the metricsPublicURL from webConsole
oc get cm webconsole-config -n openshift-web-console -o yaml | sed -e "s|metricsPublicURL|#metricsPublicURL|g" | oc -n openshift-web-console apply -f -


# Check if any old images are still running
oc get pods -o jsonpath \
--template='{range .items[*]}{.spec.nodeName}{","}{.metadata.namespace}{","}{.metadata.name}{","}{.spec.containers[0].image}{"\n"}{end}' \
--all-namespaces | grep 104

# Clean old docker images
docker images --format "{{.Repository}}:{{.Tag}}:{{.ID}}" | \
    grep -i 104 | awk -F ':' '{print $3}' | \
    xargs -L1 docker rmi

# Save all docker images
mkdir -p /home/vagrant/image-cache
pushd /home/vagrant/image-cache
docker images -a --filter='dangling=false' \
  --format '{{.Repository}}:{{.Tag}} {{.Repository}}:{{.Tag}}' | \
    xargs -n2 $1 -t sh -c 'test -e $1.tar.gz || \
    docker save $0 | gzip -2 > $(echo $1 | tr '_' '__' | tr ':' '_' | tr '/' '___').tar.gz'
popd

# Purge docker cache
systemctl stop atomic-openshift-node
docker stop $(docker ps -aq)
docker rm $(docker ps -aq)
docker system prune -a -f

# Load all docker images
for image in /home/vagrant/image-cache/*.tar.gz; do
    if [ -f "${image}" ]; then
        /usr/bin/docker load --input "${image}"
    fi
done
systemctl stop docker

# Clean up
rm -rf /root/{anaconda-ks.cfg,ansible,.ansible,.ansible_async,ks-post.log,openshift_bootstrap,original-ks.cfg,.pki,.rnd,.tcshrc}
rm -rf /tmp/*
rm -rf /home/vagrant/{image-cache,nfs-deployment.yaml}
yum -y install yum-utils
package-cleanup --quiet --leaves --exclude-bin | xargs yum remove -y
yum clean all
rm -rf /var/cache/yum
rm -rf /var/tmp/yum-*
cat /dev/null > /var/log/audit/audit.log
cat /dev/null > /var/log/wtmp
cat /dev/null > /var/log/lastlog
cat /dev/null > /var/log/grubby

# Startup
systemctl start docker
systemctl start atomic-openshift-node

# Install Rook
export HOST_SHARE_PATH='/home/vagrant/share'
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
install_rook

# Install logging
## https://docs.openshift.com/container-platform/3.11/install_config/aggregate_logging.html
ansible-playbook -i ${INVENTORY_FILE} \
    -e "openshift_release='3.11'" \
    -e "openshift_image_tag=v3.11.141" \
    -e "openshift_pkg_version=-3.11.141" \
    -e "oreg_auth_user='${REG_AUTH_USER}'" \
    -e "oreg_auth_password='${REG_AUTH_PASSWORD}'" \
    -e 'openshift_rolling_restart_mode=services' \
    -e "openshift_logging_install_logging=true" \
    -e  "openshift_logging_kibana_cpu_limit=250m" \
    -e  "openshift_logging_kibana_memory_limit=512M" \
    -e  "openshift_logging_kibana_proxy_cpu_limit=250m" \
    -e  "openshift_logging_kibana_proxy_memory_limit=512M" \
    -e  "openshift_logging_fluentd_cpu_limit=250m" \
    -e  "openshift_logging_fluentd_memory_limit=512M" \
    -e  "openshift_logging_es_cpu_limit=1" \
    -e  "openshift_logging_es_memory_limit=1024M" \
    -e  "openshift_logging_elasticsearch_kibana_index_mode=shared_ops" \
    -e  "openshift_logging_es_pvc_storage_class_name='rook-ceph-block-replicated'" \
    ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-logging/config.yml

oc delete pvc -n openshift-logging logging-es-0
cat <<EOF | oc create -f -
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: logging-es-0
  namespace: openshift-logging
  finalizers:
    - kubernetes.io/pvc-protection
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 20Gi
  storageClassName: rook-ceph-block-replicated
EOF

# Uninstall logging
ansible-playbook -i ${INVENTORY_FILE} \
    -e "openshift_release='3.11'" \
    -e "openshift_image_tag=v3.11.141" \
    -e "openshift_pkg_version=-3.11.141" \
    -e "oreg_auth_user='${REG_AUTH_USER}'" \
    -e "oreg_auth_password='${REG_AUTH_PASSWORD}'" \
    -e 'openshift_rolling_restart_mode=services' \
    -e "openshift_logging_install_logging=false" \
    -e  "openshift_logging_es_pvc_storage_class_name='rook-ceph-block-replicated'" \
    ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-logging/config.yml

# Install Quay
export HOST_SHARE_PATH='/home/vagrant/share'
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
install_quay

# Install Registry
export HOST_SHARE_PATH='/home/vagrant/share'
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
install_registry

# Install Garfana
export HOST_SHARE_PATH='/home/vagrant/share'
source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
install_grafana

podman save -o grafana_6.3.3.tar files.caas.ford.com/caas-infra/grafana:6.3.3
docker load -i grafana_6.3.3.tar

docker run --rm -it --name grafana -p 30001:3001 files.caas.ford.com/caas-infra/grafana:6.3.3 bash
docker run -d --name grafana -p 30001:3001 files.caas.ford.com/caas-infra/grafana:6.3.3
docker exec -it grafana bash

oc -n openshift-monitoring scale statefulset/prometheus-k8s --replicas=1
