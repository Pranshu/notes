#!/bin/bash

# IMPORTANT: THIS SCRIPT MUST BE IDEMPOTENT I.E. NO MATTER HOW MANY
# TIMES YOU RUN THIS SCRIPT YOU ALWAYS END UP WITH THE SAME RESULT.

set -o errexit
set -o nounset
set -o pipefail

export SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd )
export DATA_ROOT=/home/vagrant

source $SCRIPT_ROOT/lib-common.sh
source $SCRIPT_ROOT/lib-openshift.sh

add_ford_banner

echo "Installing packages"
## https://access.redhat.com/articles/1320623
#rm -fr /var/cache/yum/*
#yum clean all

## Update system to latest packages and install dependencies
##yum repolist
#yum makecache
yum -y update

## Install the following base packages
yum install -y \
    wget curl git net-tools bind-utils \
    yum-utils rsync docker podman \
    buildah skopeo mtr bash-completion

if [ "${VAGRANT_BASEBOX_CONTEXT}" = "true" ]; then
    ## No further action is required for docker host
    exit 0
fi

## Install the following base packages
yum install -y \
    iptables-services bridge-utils kexec-tools \
    sos psacct libcap-ng-utils

#yum install -y epel-release
### Disable the EPEL repository globally so that is not accidentally used during later steps of the installation
#sed -i -e "s/^enabled=1/enabled=0/" /etc/yum.repos.d/epel.repo
### Disable EPEL to prevent unexpected packages from being pulled in during installation.
#yum-config-manager epel --disable
set +e
if [ "${OPENSHIFT_DEPLOYMENT_TYPE}" = "openshift-enterprise" ] && [ "${LOCAL_DEV_PROFILE}" != "build-host" ]; then
    ## Install the packages for Ansible
    if [ "$(hostname)" = "${MASTER_FQDN}" ]; then
        yum install -y openshift-ansible-${OPENSHIFT_ANSIBLE_VERSION}
    fi
fi
set -e

# Rook filesystem
# https://github.com/rook/rook/issues/2047
# https://github.com/rook/rook/issues/717
#
# https://linoxide.com/file-system/create-mount-extend-xfs-filesystem/
# https://github.com/mapreducelab/kubernetes-ansible/blob/master/roles/rook/tasks/main.yml
# https://github.com/Robi-WanKenobi/helm-charts-tfg/blob/master/storage/README.md
# https://github.com/LvJianting/linux-handbook/blob/master/foundation/LVM.md
# https://community.checkpoint.com/thread/10253-how-to-add-a-new-disk-and-expand-the-log-file-system
#
# https://github.com/ijzerbroot/k8s-docker/blob/master/setup-with-kubeadm.txt
# https://www.linuxnov.com/create-lvm-partition-with-xfs-ext4-file-systems-on-rhel-and-debian/
# https://www.ibm.com/support/knowledgecenter/en/SSBS6K_3.1.1/manage_cluster/install_rook.html
#if [ "${LOCAL_DEV_PROFILE}" != "build-host" ]; then
#    sudo parted -s /dev/sdc mklabel msdos
#    sudo parted -s /dev/sdc mkpart primary 1 100%
#    sudo parted -s /dev/sdc set 1 lvm on
#    sudo pvcreate /dev/sdc1 || exit 1
#    sudo vgcreate vg_ceph /dev/sdc1 || exit 1
#    sudo lvcreate -L 5G -n lv_cephmeta vg_ceph || exit 1
#    sudo lvcreate -l 100%FREE -n lv_ceph vg_ceph || exit 1
#    sudo mkfs.xfs /dev/vg_ceph/lv_cephmeta || exit 1
#    sudo mkfs.xfs /dev/vg_ceph/lv_ceph || exit 1
#    sudo bash -c "echo '/dev/vg_ceph/lv_cephmeta  /cephdata/rook/rookmetadata   xfs  defaults  1 2' >> /etc/fstab"
#    sudo bash -c "echo '/dev/vg_ceph/lv_ceph  /cephdata/rook/storage  xfs   defaults   1 2' >> /etc/fstab"
#    sudo mkdir -p /cephdata/rook/rookmetadata && sudo mkdir -p /cephdata/rook/storage && sudo mount /cephdata/rook/rookmetadata && sudo mount /cephdata/rook/storage
#fi

#if grep -q '^EnvironmentFile=/etc/environment' /usr/lib/systemd/system/docker.service; then
#    sed -i '/\[Service\]/a EnvironmentFile=/etc/environment' /usr/lib/systemd/system/docker.service
#fi

for f in /etc/sysconfig/docker /etc/sysconfig/docker-storage /etc/sysconfig/docker-network; do
    if [[ ! -f ${f} ]]; then
        touch $f
    fi
done

if systemctl is-active docker.service >/dev/null; then
    systemctl stop docker.service || true
    systemctl stop docker-storage-setup || true
fi

# DOCS:
#   https://docs.openshift.com/container-platform/3.11/scaling_performance/optimizing_storage.html#choosing-a-graph-driver
#   https://docs.openshift.com/container-platform/3.11/install/host_preparation.html#configuring-docker-thin-pool
#   https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux_atomic_host/7/html/managing_containers/managing_storage_with_docker_formatted_containers#using_the_overlay_graph_driver
if ! grep -q "^CONTAINER_ROOT_LV_NAME=dockerlv$" /etc/sysconfig/docker-storage-setup; then
cat <<EOF > /etc/sysconfig/docker-storage-setup
STORAGE_DRIVER=overlay2
DEVS=/dev/sdb
VG=dockervg
CONTAINER_ROOT_LV_NAME=dockerlv
CONTAINER_ROOT_LV_SIZE=95%FREE
CONTAINER_ROOT_LV_MOUNT_PATH=/var/lib/docker
#ROOT_SIZE=500G
#DATA_SIZE=400G
#DATA_SIZE=95%FREE
EOF
fi

if [ -f /var/lib/docker ]; then
    rm -rf /var/lib/docker/*
    container-storage-setup --reset
fi

#systemctl restart docker-storage-setup || true

if ! systemctl is-active docker.service >/dev/null; then
    systemctl enable docker.service
    systemctl start docker.service
fi

## Run docker as unprivileged user
if ! getent group dockerroot | grep &>/dev/null "\bvagrant\b"; then
    usermod -aG dockerroot vagrant
    echo "{\"live-restore\": true,\"group\": \"dockerroot\"}" > /etc/docker/daemon.json
    #echo "{\"live-restore\": true,\"group\": \"dockerroot\", \"dns\": [\"192.168.1.25\"]}" > /etc/docker/daemon.json
    systemctl restart docker
    ls -ltr /var/run/docker.sock
fi

# DOCS: https://access.redhat.com/RegistryAuthentication
# DOCS: https://docs.openshift.com/container-platform/3.11/day_two_guide/docker_tasks.html
# DOCS: https://docs.openshift.com/container-platform/3.11/admin_guide/image_policy.html#admin-guide-image-policy
if ! grep -q "^registries = \['registry.redhat.io'\]$" /etc/containers/registries.conf; then
	echo "Updating /etc/containers/registries.conf file"
	# Note: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
	cat <<- EOD > /etc/containers/registries.conf
	[registries.search]
	registries = ['registry.redhat.io']
	EOD
fi

if [ "${LOCAL_DEV_PROFILE}" = "build-host" ] && [ -f ${HOST_SHARE_PATH}/tokens/rh-localdev-registry-token-auth.json ]; then
    if [ ! -f /root/.docker/config.json ] || [ ! grep -q "registry.redhat.io" /root/.docker/config.json ]; then
        mkdir -p /root/.docker
        rsync -Iq ${HOST_SHARE_PATH}/tokens/rh-localdev-registry-token-auth.json /root/.docker/config.json
    fi
fi

# Install nextgen container tools buildah, podman
install_build_tools

if [ "${LOCAL_DEV_PROFILE}" = "build-host" ]; then
    ## No further action is required for docker host
    exit 0
fi

## Generate ssh key pairs
add_vagrant_ssh_key

## other steps are required only on master node
if [ "$(hostname)" = "${INFRA_FQDN}" ]; then
    ## Persist init script
    cp /tmp/vagrant-shell ${DATA_ROOT}/init.sh
    chown vagrant:vagrant ${DATA_ROOT}/init.sh
    chmod 755 ${DATA_ROOT}/init.sh
    sed -i "s|^export RHSM_ORG=.*$|export RHSM_ORG=''|g" ${DATA_ROOT}/init.sh
    sed -i "s|^export RHSM_ACTIVATION_KEY=.*$|export RHSM_ACTIVATION_KEY=''|g" ${DATA_ROOT}/init.sh

    ## No further action is required on infra nodes
    exit 0
fi

if [ -f ${HOST_SHARE_PATH}/tokens/ford-dev-license.yaml ]; then
    mkdir -p /root/ldev-secrets
    cp ${HOST_SHARE_PATH}/tokens/ford-dev-license.yaml /root/ldev-secrets/ford-dev-license.yaml
fi

if [ -f ${HOST_SHARE_PATH}/tokens/cnx-pull-secret.json ]; then
    mkdir -p /root/ldev-secrets
    cp ${HOST_SHARE_PATH}/tokens/cnx-pull-secret.json /root/ldev-secrets/cnx-pull-secret.json
    cp ${HOST_SHARE_PATH}/tokens/tigera-pull-secret.json /root/ldev-secrets/tigera-pull-secret.json
fi

if [ -f ${HOST_SHARE_PATH}/tokens/tigera-pull-secret.json ]; then
    mkdir -p /root/ldev-secrets
    cp ${HOST_SHARE_PATH}/tokens/cnx-pull-secret.json /root/ldev-secrets/cnx-pull-secret.json
    cp ${HOST_SHARE_PATH}/tokens/tigera-pull-secret.json /root/ldev-secrets/tigera-pull-secret.json
fi

## Copy login template
if [[ -f /etc/origin/master/login.html ]]; then
    mkdir -p /etc/origin/master
    \cp --force ${HOST_SHARE_PATH}/templates/login.html /etc/origin/master/login.html
fi

if [ "${OPENSHIFT_USE_CALICO_SDN}" = "true" ]; then
    export OS_SDN_NETWORK_PLUGIN_NAME='cni'
    export OPENSHIFT_USE_OPENSHIFT_SDN='false'
else
    export OPENSHIFT_USE_OPENSHIFT_SDN='true'
fi

## GlusterFS feature toggle
if [ "${OPENSHIFT_GLUSTERFS}" = "true" ]; then
    export GLUSTERFS_FEATURE_TOGGLE=''
else
    export GLUSTERFS_FEATURE_TOGGLE='#'
fi

# Registry auth credentials
export REG_AUTH_USER=$(cat ${HOST_SHARE_PATH}/tokens/rh-localdev-registry-token-auth.json | jq -r '.auths."registry.redhat.io".auth' | base64 --decode | cut -d ':' -f1) || true
export REG_AUTH_PASSWORD=$(cat ${HOST_SHARE_PATH}/tokens/rh-localdev-registry-token-auth.json | jq -r '.auths."registry.redhat.io".auth' | base64 --decode | cut -d ':' -f2) || true

echo "Generate ansible inventory file"
envsubst < ${ANSIBLE_INVENTORY_FILE} > ${DATA_ROOT}/inventory.ini

if [ "${OPENSHIFT_DEPLOYMENT_TYPE}" = "origin" ]; then
    ## CentOS 7 - RPM install
    # https://buildlogs.centos.org/centos/7/paas/x86_64/openshift-origin39/
    # https://wiki.centos.org/SpecialInterestGroup/PaaS/OpenShift-Quickstart
    # yum install -y centos-release-openshift-origin39
    # yum install -y openshift-ansible

    [ ! -d $DATA_ROOT/openshift-ansible ] && git clone https://github.com/openshift/openshift-ansible.git
    if [ "${OPENSHIFT_USE_GIT_RELEASE}" = "true" ]; then
        cd $DATA_ROOT/openshift-ansible && git fetch && git checkout ${OPENSHIFT_ANSIBLE_GIT_REL} && cd ..
    else
        cd $DATA_ROOT/openshift-ansible && git fetch && git checkout tags/${OPENSHIFT_ANSIBLE_GIT_TAG} && cd ..
    fi
fi

# TODO: https://github.com/openshift/openshift-ansible/pull/10833
# TODO: https://github.com/openshift/openshift-ansible/pull/10832
# https://github.com/openshift/openshift-ansible/pull/9435
# https://github.com/openshift/openshift-ansible/commit/4d233dd09db38093b59a708d75f8255c350d6100
# https://github.com/openshift/openshift-ansible/commit/d2bee7f9475abd850cb8954aefd34adaa34e062b
if [ "${OPENSHIFT_USE_CALICO_SDN}" = "true" ]; then
    echo "Copying Calico ansible playbooks"
    if [ -d $ANSIBLE_ROOT/openshift-ansible/roles/calico ]; then
        rm -rf $ANSIBLE_ROOT/openshift-ansible/roles/calico
    fi
    if [ -d $ANSIBLE_ROOT/openshift-ansible/roles/calico-node ]; then
        rm -rf $ANSIBLE_ROOT/openshift-ansible/roles/calico-node
    fi
    if [ -d $ANSIBLE_ROOT/openshift-ansible/roles/calico_master ]; then
        rm -rf $ANSIBLE_ROOT/openshift-ansible/roles/calico_master
    fi

    ## vendor custom calico & kube_proxy playbooks
    rsync -rIq ${HOST_SHARE_PATH}/ansible/roles-${OPENSHIFT_RELEASE_MAJOR_VERSION}/ $ANSIBLE_ROOT/openshift-ansible/roles/
    rsync -Iq ${HOST_SHARE_PATH}/ansible/playbooks-${OPENSHIFT_RELEASE_MAJOR_VERSION}/upgrade-calico.yaml $ANSIBLE_ROOT/openshift-ansible/playbooks/upgrade-calico.yaml
fi

## Deploy OpenShift
echo "Purge ansible cache"
rm -rf /etc/ansible/ansible.cfg

## Copy openshift audit policy
## NOTE: Path should be in one of the mounted dirs in:
##  https://github.com/openshift/openshift-ansible/blob/release-3.11/roles/openshift_control_plane/files/apiserver.yaml#L54
##  https://github.com/openshift/openshift-ansible/blob/release-3.11/roles/openshift_control_plane/files/controller.yaml#L48
if [ -f ${HOST_SHARE_PATH}/templates/openshift/openshift-audit-policy.yaml ] && [ ! -f /etc/origin/master/audit-policy/openshift-audit-policy.yaml ]; then
    mkdir -p /etc/origin/master/audit-policy
    \cp -f ${HOST_SHARE_PATH}/templates/openshift/openshift-audit-policy.yaml /etc/origin/master/audit-policy/openshift-audit-policy.yaml
    chmod 644 /etc/origin/master/audit-policy/openshift-audit-policy.yaml
fi

#vi /usr/share/ansible/openshift-ansible/roles/openshift_control_plane/templates/master.yaml.v1.j2
##sed -i "s|^  masterIP: .*|  masterIP: ${MASTER_IP}|" $ANSIBLE_ROOT/openshift-ansible/roles/openshift_control_plane/templates/master.yaml.v1.j2

echo "Invoking openShift-ansible playbooks"
ansible-playbook -vvv -i $DATA_ROOT/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/prerequisites.yml 2>&1
ansible-playbook -vvv -i $DATA_ROOT/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/deploy_cluster.yml 2>&1
if [ $? -ne 0 ]; then
    echo "Ansible run failed"
    exit 0
fi

## Copy docker auth for vagrant user
mkdir -p ${DATA_ROOT}/.docker
if [ ! -f /root/.docker/config.json ]; then
    cp -f /root/.docker/config.json ${DATA_ROOT}/.docker/config.json
    chown "vagrant":"vagrant" ${DATA_ROOT}/.docker -R
    chmod g+rwx "${DATA_ROOT}/.docker" -R
fi

## Patch ImageStreams
patch_imagestreams

## Create OpenShift admin user
create_admin_account

## Configure IPFailover for TCP/UDP services
setup_ipfailover

install_nfs_provisioner

# NOTE:
# Not installed by default since it bloats the vagrant box file 10GB
# This can be installed afterwards, see the update-openshift.sh for details
#install_rook

## Create a sample namespace and grant access to OLM
provision_namespace ${OPENSHIFT_EXAMPLE_NAMESPACE} nsadmin nsdeveloper nsobserver
if [ "${OPENSHIFT_DEPLOY_OLM}" = "true" ]; then
    grant_view_to_olm nsadmin
fi

## Install Tigera networking suite
#configure_cnx
#configure_cnx_analytics

## TODO: deploy CNX default policies
#configure_cnx_policy

rm -rf /root/ldev-secrets

## Configure /etc/motd file in the guest VM
customize_banner

## TECH-DEBT:
if [ ! -f /etc/origin/master/master-config.yaml.original ]; then
    \cp --force /etc/origin/master/master-config.yaml /etc/origin/master/master-config.yaml.original
fi

## Configure default Jenkins template
## NOTE: leading '\' after /i is requried to escape the spaces to preserve YAML indentation
sed -i "/kind: MasterConfig/i \jenkinsPipelineConfig:\n  autoProvisionEnabled: true\n  parameters: null\n  serviceName: jenkins\n  templateName: jenkins-persistent\n  templateNamespace: openshift" /etc/origin/master/master-config.yaml

## Copy login template
if [ ! -f /etc/origin/master/login.html ]; then
    \cp --force ${HOST_SHARE_PATH}/templates/login.html /etc/origin/master/login.html
fi
if ! grep --quiet -e 'login: /etc/origin/master/login.html' /etc/origin/master/master-config.yaml; then
    ## NOTE: leading '\' after /i is requried to escape the spaces to preserve YAML indentation
    sed -i "/pauseControllers: false/i \  templates:\n    login: /etc/origin/master/login.html" /etc/origin/master/master-config.yaml
fi

## Deploy status server
if [[ $(oc -n cluster-ops get deployments -o=custom-columns=NAME:.metadata.name --no-headers | grep -cE 'status') -ne 1 ]]; then
    oc new-project cluster-ops || true
    oc -n cluster-ops create -f ${HOST_SHARE_PATH}/templates/status/configmap.yaml || true
    oc -n cluster-ops create -f ${HOST_SHARE_PATH}/templates/status/deployment.yaml || true
    wait_for_pod cluster-ops status-*
fi

## Web Console configs
oc get cm webconsole-config -n openshift-web-console -o yaml | sed -e "s#scriptURLs\: .*#scriptURLs\:\n        - https://status.app.oc.local/openshift-extension.js#" | oc -n openshift-web-console apply -f -

# https://access.redhat.com/support/cases/#/case/02288631?commentId=a0a2K00000OsM8YQAV
# Remove the metricsPublicURL from webConsole
oc get cm webconsole-config -n openshift-web-console -o yaml | sed -e "s|metricsPublicURL|#metricsPublicURL|g" | oc -n openshift-web-console apply -f -

# Patch Jenkins templates
oc -n openshift apply -f ${HOST_SHARE_PATH}/templates/openshift/templates/jenkins-persistent.yaml || true
oc -n openshift apply -f ${HOST_SHARE_PATH}/templates/openshift/templates/jenkins-ephemeral.yaml || true

# Update the images
# DOCS: https://blog.openshift.com/automatically-update-red-hat-container-images-on-openshift-3-11/

## Restart OpenShift control plane
restart_control_plane

## Wait for OpenShift API server
wait_for_k8s_apiserver https://api.oc.local:8443

## Copy KUBECONFIG file to host
postinstall_cleanup

## Display welcome message to user
print_welcome_message

exit 0
