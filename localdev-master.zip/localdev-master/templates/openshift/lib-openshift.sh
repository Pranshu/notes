if [ "${VAGRANT_BUILD_CONTEXT}" = "true" ] || [ ! -f /root/.docker/pull-secrets.env ]; then
    mkdir -p /root/.docker
    \cp -f ${HOST_SHARE_PATH}/tokens/pull-secrets.env /root/.docker/pull-secrets.env
fi

source /root/.docker/pull-secrets.env

function customize_banner() {
    MOTD_FILE=/etc/motd
    BANNER_WIDTH=64

    # OS INFO
    PLATFORM_RELEASE=$(sed 's/^.\+ release \([.0-9]\+\).*/\1/' /etc/redhat-release)
    PLATFORM_MSG=$(printf 'RHEL Server release %s (Maipo)' "$PLATFORM_RELEASE")
    BUILT_MSG=$(printf 'built %s' $(date +%Y-%m-%d))
    printf '%0.1s' "-"{1..64} > ${MOTD_FILE}
    printf '\n' >> ${MOTD_FILE}
    # printf '%2s%-30s%30s\n' " " "${PLATFORM_MSG}" "${BUILT_MSG}" >> ${MOTD_FILE}
    printf '%2s%-30s%17s\n' " " "${PLATFORM_MSG}" "${BUILT_MSG}" >> ${MOTD_FILE}
    printf '%0.1s' "-"{1..64} >> ${MOTD_FILE}
    printf '\n' >> ${MOTD_FILE}
    # OPENSHIFT INFO
    printf '%2s%-30s%17s\n' " " "RHEL OpenShift release" "${OPENSHIFT_RELEASE_MAJOR_VERSION}.${OPENSHIFT_RELEASE_MINOR_VERSION}" >> ${MOTD_FILE}
    printf '%2s%-30s%18s\n' " " "RHEL OpenShift localdev release" "${LOCAL_DEV_VERSION}" >> ${MOTD_FILE}
    printf '%2s%-30s%18s\n' " " "RHEL OpenShift localdev profile" "${LOCAL_DEV_PROFILE}" >> ${MOTD_FILE}
    # printf '%2s%-30s%30s\n' " " "RHEL OpenShift localdev build" "$(date -u +'%Y-%m-%dT%H:%M:%SZ')" >> ${MOTD_FILE}
    printf '%0.1s' "-"{1..64} >> ${MOTD_FILE}
    printf '\n' >> ${MOTD_FILE}
}

function setup_rhsm_subscription(){
    local SUBSTATUS=$(subscription-manager status | grep "^Overall" | awk '{print $NF}') || true
    if [ "${SUBSTATUS}" == 'Unknown' ] && [ "${RHSM_ORG}" != "" ] && [ "${RHSM_ACTIVATION_KEY}" != "" ]; then
        echo "Enrolling VM with Red Hat Subscription-Manager"
        subscription-manager register --org="${RHSM_ORG}" --activationkey="${RHSM_ACTIVATION_KEY}" || true
    fi

    # subscription-manager repos --list-enabled | grep "Repo ID" | awk '{ print $3 }'
    # sub_status=$(subscription-manager status | grep "Overall Status" | awk '{ print $3 }')
    if [ "${OPENSHIFT_DEPLOYMENT_TYPE}" = "openshift-enterprise" ]; then
        echo "Enable RHEL repositories"
        yum makecache fast
        ##subscription-manager release --set='7.5'
        #subscription-manager repos --disable="*"
        subscription-manager repos \
            --enable="rhel-7-server-rpms" \
            --enable="rhel-7-server-extras-rpms" \
            --enable="rhel-7-server-ose-${OPENSHIFT_RELEASE_MAJOR_VERSION}-rpms" \
            --enable="rhel-7-server-ansible-2.6-rpms" \
            --enable="rhel-7-fast-datapath-rpms" \
            --enable="rh-gluster-3-client-for-rhel-7-server-rpms" \
            --enable="rhel-7-server-optional-rpms"
    fi
}

function wait_for_pod() {
    local namespace=$1
    local pod=$2
    set +e
    index=$((0))
    sleeptime=3
    until oc -n ${namespace} get pods | grep ${pod} | grep Running ; do
        if [[ ${index} -gt 0 ]]; then
            echo "Waiting for ${pod} pod to start $((${index} * ${sleeptime})) seconds ...";
        else
            echo "Waiting for ${pod} pod to start ...";
        fi
        index=$(($index+1))
        sleep ${sleeptime};
    done
    set -e
}

function wait_for_service() {
    local service=$1
    if ! systemctl is-active ${service} >/dev/null; then
        echo -n "${service} is starting up. Please wait."
        until systemctl is-active ${service} >/dev/null; do
            sleep 1
            echo -n "."
        done
    fi
}

function wait_for_objects() {
    local namespace=$1
    local deployment_name=$2
    local kind=${3:-deployment}

    #until [ "$(oc get pods $(oc -n kube-system get pods -l "k8s-app=calicoctl" -o=custom-columns=NAME:.metadata.name --no-headers=true) -o 'jsonpath={.status.conditions[?(@.type=="Ready")].status}')" == 'True' ] > /dev/null 2>&1; do sleep 10; oc -n kube-system get pods; done

    #until [ $(oc -n ${namespace} get deployment ${deployment_name} -ojsonpath="{.status.conditions[?(@.type=='Available')].status}") == "True" ] > /dev/null 2>&1; do sleep 10; oc -n ${namespace} get deployment ${deployment_name}; done

    until [[ $(oc -n ${namespace} get ${kind} ${deployment_name} -ojsonpath="{.status.unavailableReplicas}") =~ 0|^$ ]] > /dev/null 2>&1; do sleep 5; oc -n ${namespace} get ${kind} ${deployment_name}; done
}

function wait_for_k8s_apiserver() {
    local API_SERVER_ADDRESS=$1
    index=$((0))
    sleeptime=3
    while [[ "$(curl --cacert /etc/origin/master/ca.crt -s -o /dev/null -w ''%{http_code}'' ${API_SERVER_ADDRESS})" != "200" ]]; do
        if [[ ${index} -gt 0 ]]; then
            echo "Waiting for Kubernetes api server ...";
        else
            echo "Waiting for Kubernetes api server $((${index} *  ${sleeptime})) seconds ...";
        fi
        index=$(($index+1));
        sleep ${sleeptime};
    done
}

function configure_openshift_master() {
    if [ -z "${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}" ]; then
        \cp -f ${HOST_SHARE_PATH}/templates/openshift/master-config-noproxy.yaml /etc/origin/master/master-config.yaml
    else
        \cp --force ${HOST_SHARE_PATH}/templates/openshift/master-config-proxy.yaml /etc/origin/master/master-config.yaml
        #cp "/etc/origin/master/master-config.yaml" "/etc/origin/master/master-config.orig.yaml"
        #oc ex config patch /etc/origin/master/master-config.orig.yaml --patch "$(cat ${HOST_SHARE_PATH}/templates/openshift/patch/master-config.yaml)" > /etc/origin/master/master-config.yaml
        #rm -rf /etc/origin/master/master-config.orig.yaml
    fi
}

function restart_control_plane() {
    # DOCS: https://docs.openshift.com/container-platform/3.11/architecture/infrastructure_components/kubernetes_infrastructure.html
    # ansible masters -m shell -a "/usr/local/bin/master-restart api"

    status=$(/usr/local/bin/master-restart api)
    #if [ $status -ne 2 ]; then
    #    echo "Failed to restart master api server"
    #    exit 1
    #fi

    status=$(/usr/local/bin/master-restart controllers)
    #if [ $status -ne 2 ]; then
    #    echo "Failed to restart master api server"
    #    exit 1
    #fi

    ## /usr/local/bin/master-logs controllers controllers
    ## /usr/local/bin/master-logs api api
    ## /usr/local/bin/master-logs etcd etcd

    ## Stop node service
    #systemctl stop atomic-openshift-node

    ## Kill static pod
    #for pod in $(docker ps --format '{{.ID}}:{{.Names}}' | grep -E 'k8s_(api|controllers)_master-(api|controllers)-m1.oc.local_kube-system_*' | cut -d ':' -f1); do
    #    docker stop ${pod}
    #done

    ## Start node service
    #systemctl start atomic-openshift-node
    #wait_for_service atomic-openshift-node

    ## Wait for api server static pod to start
    #until docker ps --format '{{.ID}}:{{.Names}}:{{.Status}}' | grep -E 'k8s_api_master-api-m1.oc.local_kube-system_*'; do
    #    echo "Waiting api server static pod";
    #    sleep 3;
    #done

    ## Wait for controllers static pod to start
    #until docker ps --format '{{.ID}}:{{.Names}}:{{.Status}}' | grep -E 'k8s_controllers_master-controllers-m1.oc.local_kube-system_*'; do
    #    echo "Waiting controllers static pod";
    #    sleep 3;
    #done

}

function configure_jenkins_pipeline() {
    # DOCS: https://docs.openshift.com/container-platform/3.11/install_config/configuring_pipeline_execution.html
    \cp -f /etc/origin/master/master-config.yaml /etc/origin/master/master-config.orig.yaml
    oc ex config patch /etc/origin/master/master-config.orig.yaml --patch="{\"jenkinsPipelineConfig\":{\"templateName\":\"jenkins-persistent\"}}" > /etc/origin/master/master-config.yaml
    rm -rf  /etc/origin/master/master-config.orig.yaml
}

function configure_docker_registry() {
    # Limits the docker registries that normal users may import images from. Set this list to the registries that you trust to contain valid Docker images and that you want applications to be able to import from. Users with permission to create Images or ImageStreamMappings via the API are not affected by this policy - typically only administrators or system integrations will have those permissions.
    # DOCS: https://docs.openshift.com/container-platform/3.11/admin_guide/image_policy.html
    allowed_registries=(quay.io registry.access.redhat.com registry.redhat.io registry.ford.com quay.k8s.ford.com *.oc.local docker-registry.default.svc:5000 hpcdocker1.hpc.ford.com:5000)
    \cp -f /etc/origin/master/master-config.yaml /etc/origin/master/master-config.orig.yaml
    oc ex config patch /etc/origin/master/master-config.orig.yaml --patch="{\"imagePolicyConfig\":{\"allowedRegistriesForImport\":[$(echo "${allowed_registries[@]}" | xargs printf '{"domainName":"%s"},' | sed 's/,$//')]}}" > /etc/origin/master/master-config.yaml
    rm -rf  /etc/origin/master/master-config.orig.yaml
}

function openshift_tune_performance() {
    # DOCS: https://docs.openshift.com/container-platform/3.11/scaling_performance/host_practices.html#scaling-performance-capacity-host-practices-master
    # REFS: https://github.com/ganhuang/tech-blogs/blob/master/install_origin_all_in_one_master.md
    \cp -f /etc/origin/master/master-config.yaml /etc/origin/master/master-config.orig.yaml
    oc ex config patch/etc/origin/master/master-config.orig.yaml --patch='{\"masterClients\":{\"externalKubernetesClientConnectionOverrides\":{\"acceptContentTypes\":"application/vnd.kubernetes.protobuf,application/json\",\"burst\":1600,\"contentType\":\"application/vnd.kubernetes.protobuf\",\"qps\":800},\"openshiftLoopbackClientConnectionOverrides\":{\"acceptContentTypes\":\"application/vnd.kubernetes.protobuf,application/json\",\"burst\":2400,\"contentType\":\"application/vnd.kubernetes.protobuf\",\"qps\":1200}}}' > /etc/origin/master/master-config.yaml
    rm -rf  /etc/origin/master/master-config.orig.yaml
}

function configure_emptydir_quota() {
    # DOCS: https://docs.openshift.com/container-platform/3.11/admin_guide/manage_nodes.html#modifying-nodes
    # DOCS: https://access.redhat.com/solutions/3110681
    # DOCS: https://github.com/openshift/openshift-ansible-contrib/tree/master/roles/openshift-emptydir-quota
    # DOCS: https://github.com/snazirOptum/testOSEELK/blob/master/test/fluentd-forward.sh
    #oc -n openshift-node get cm node-config-allinone -o yaml --export > ${DATA_ROOT}/node-config-allinone.yaml
    #sed -i 's/        perFSGroup: null/        perFSGroup: "512Mi"/' ${DATA_ROOT}/node-config-allinone.yaml
    oc -n openshift-node get configmap/node-config-allinone -o yaml | sed 's/perFSGroup: null/perFSGroup: "512Mi"/' | oc replace -f -
}

function add_ford_banner() {
	# NOTE: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
	# NOTE: single quotes will prevent variable interpolation
	cat <<- 'FORD_BANNER' > /etc/issue
	******************************************************************************
	*       WARNING!  THIS IS A FORD MOTOR COMPANY PRIVATE COMPUTER SYSTEM.      *
	*                           USAGE MAY BE MONITORED.                          *
	*                                                                            *
	*  UNAUTHORIZED ACCESS OR USE MAY RESULT IN CRIMINAL OR CIVIL PROSECUTION,   *
	*  DISCIPLINE UP TO AND INCLUDING TERMINATION OF EMPLOYMENT, TERMINATION OF  *
	*  ASSIGNMENT, OR LOSS OF ACCESS.                                            *
	*                                                                            *
	*  By signing on to the system I agree that, where consistent with           *
	*  applicable law:                                                           *
	*  1) I understand and will comply with the provisions of Ford Directive     *
	*     B-109, and the other confidentiality policies listed below,            *
	*  2) I do not have any expectation of privacy in my use of the system, and  *
	*  3) Ford actively monitors its information, systems, and data to identify  *
	*     and respond to security threats and losses, and  any information or    *
	*     data identified through this monitoring may be shared among Ford and   *
	*     Ford's global affiliates and service providers, through approved       *
	*     processes or where legally required, and provided to government        *
	*     authorities (including law enforcement).                               *
	*                                                                            *
	*  Ford recognizes that in certain jurisdictions there are specific laws,    *
	*  regulations, and labor agreements that may apply, and Ford will comply    *
	*  with such requirements.                                                   *
	*                                                                            *
	*  By accessing this system, I acknowledge that it contains information      *
	*  that is Confidential and Proprietary to Ford, its affiliates, dealers,    *
	*  and suppliers, and that I am responsible for maintaining the security     *
	*  and confidentiality of the information and shall use it only for          *
	*  purposes authorized by Ford.  Such information shall not be disclosed     *
	*  or caused to be disclosed without proper authorization from Ford.         *
	*                                                                            *
	*  Ford owns all rights to unpublished work created by or developed for      *
	*  Ford and reserves the right to protect these works as unpublished         *
	*  copyrighted works in the event of an inadvertent or deliberate            *
	*  unauthorized publication.  Ford also reserves its rights under the        *
	*  copyright laws to protect these works as published works.                 *
	*                                                                            *
	*  I agree to read and follow Ford Policy Letter No. 22, Directives B-109    *
	*  and C-110, and Global Information Standard 2 (GIS2) before accessing      *
	*  information on the web.  Go to the Ford Legal Access site to read these   *
	*  confidentiality policies PL 22, B-109, C-110, GIS2.                       *
	******************************************************************************
	FORD_BANNER
    chmod 644 /etc/issue
    sed -i "s~^#Banner.*~Banner /etc/issue~g" /etc/ssh/sshd_config
    systemctl restart sshd
}

function add_vagrant_ssh_key() {
    if [ ! -f /root/.ssh/id_rsa ]; then
        echo "Copying ssh keys"
		# NOTE: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
		# NOTE: single quotes will prevent variable interpolation
		cat <<- 'VAGRANT_ID_RSA' > ${HOST_SHARE_PATH}/../.ssh/id_rsa
		-----BEGIN RSA PRIVATE KEY-----
		MIIEogIBAAKCAQEA6NF8iallvQVp22WDkTkyrtvp9eWW6A8YVr+kz4TjGYe7gHzI
		w+niNltGEFHzD8+v1I2YJ6oXevct1YeS0o9HZyN1Q9qgCgzUFtdOKLv6IedplqoP
		kcmF0aYet2PkEDo3MlTBckFXPITAMzF8dJSIFo9D8HfdOV0IAdx4O7PtixWKn5y2
		hMNG0zQPyUecp4pzC6kivAIhyfHilFR61RGL+GPXQ2MWZWFYbAGjyiYJnAmCP3NO
		Td0jMZEnDkbUvxhMmBYSdETk1rRgm+R4LOzFUGaHqHDLKLX+FIPKcF96hrucXzcW
		yLbIbEgE98OHlnVYCzRdK8jlqm8tehUc9c9WhQIBIwKCAQEA4iqWPJXtzZA68mKd
		ELs4jJsdyky+ewdZeNds5tjcnHU5zUYE25K+ffJED9qUWICcLZDc81TGWjHyAqD1
		Bw7XpgUwFgeUJwUlzQurAv+/ySnxiwuaGJfhFM1CaQHzfXphgVml+fZUvnJUTvzf
		TK2Lg6EdbUE9TarUlBf/xPfuEhMSlIE5keb/Zz3/LUlRg8yDqz5w+QWVJ4utnKnK
		iqwZN0mwpwU7YSyJhlT4YV1F3n4YjLswM5wJs2oqm0jssQu/BT0tyEXNDYBLEF4A
		sClaWuSJ2kjq7KhrrYXzagqhnSei9ODYFShJu8UWVec3Ihb5ZXlzO6vdNQ1J9Xsf
		4m+2ywKBgQD6qFxx/Rv9CNN96l/4rb14HKirC2o/orApiHmHDsURs5rUKDx0f9iP
		cXN7S1uePXuJRK/5hsubaOCx3Owd2u9gD6Oq0CsMkE4CUSiJcYrMANtx54cGH7Rk
		EjFZxK8xAv1ldELEyxrFqkbE4BKd8QOt414qjvTGyAK+OLD3M2QdCQKBgQDtx8pN
		CAxR7yhHbIWT1AH66+XWN8bXq7l3RO/ukeaci98JfkbkxURZhtxV/HHuvUhnPLdX
		3TwygPBYZFNo4pzVEhzWoTtnEtrFueKxyc3+LjZpuo+mBlQ6ORtfgkr9gBVphXZG
		YEzkCD3lVdl8L4cw9BVpKrJCs1c5taGjDgdInQKBgHm/fVvv96bJxc9x1tffXAcj
		3OVdUN0UgXNCSaf/3A/phbeBQe9xS+3mpc4r6qvx+iy69mNBeNZ0xOitIjpjBo2+
		dBEjSBwLk5q5tJqHmy/jKMJL4n9ROlx93XS+njxgibTvU6Fp9w+NOFD/HvxB3Tcz
		6+jJF85D5BNAG3DBMKBjAoGBAOAxZvgsKN+JuENXsST7F89Tck2iTcQIT8g5rwWC
		P9Vt74yboe2kDT531w8+egz7nAmRBKNM751U/95P9t88EDacDI/Z2OwnuFQHCPDF
		llYOUI+SpLJ6/vURRbHSnnn8a/XG+nzedGH5JGqEJNQsz+xT2axM0/W/CRknmGaJ
		kda/AoGANWrLCz708y7VYgAtW2Uf1DPOIYMdvo6fxIB5i9ZfISgcJ/bbCUkFrhoH
		+vq/5CIWxCPp0f85R4qxxQ5ihxJ0YDQT9Jpx4TMss4PSavPaBH3RXow5Ohe+bYoQ
		NE5OgEXk2wVfZczCZpigBKbKZHNYcelXtTt/nP3rsCuGcM4h53s=
		-----END RSA PRIVATE KEY-----
		VAGRANT_ID_RSA
        chmod 600 ${HOST_SHARE_PATH}/../.ssh/id_rsa

        mkdir -p /root/.ssh
        rsync -rIq ${HOST_SHARE_PATH}/../.ssh/ /root/.ssh/
        chmod -R 600 /root/.ssh

        ssh -i ${HOST_SHARE_PATH}/../.ssh/id_rsa -o StrictHostKeyChecking=no root@$(hostname -i) "pwd" < /dev/null
        ssh -i ${HOST_SHARE_PATH}/../.ssh/id_rsa -o StrictHostKeyChecking=no root@$(hostname -f) "pwd" < /dev/null
    fi
}

function install_glusterfs() {
    ansible-playbook -vvv -i ${DATA_ROOT}/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-glusterfs/config.yml 2>&1
    if [ $? -ne 0 ]; then
        echo "Ansible run failed"
        exit 1
    fi
}

function install_monitoring() {
    ansible-playbook -vvv -i ${DATA_ROOT}/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-prometheus/config.yml 2>&1
    if [ $? -ne 0 ]; then
        echo "Ansible run failed"
        exit 1
    fi
}

function install_logging() {
    if ! oc -n openshift-logging get deploymentconfig -o jsonpath='{range .items[*]} {@.metadata.name}{end}' | grep -qE 'logging-es-data-master-*|logging-kibana'; then
        ansible-playbook -vvv -i ${DATA_ROOT}/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-logging/config.yml 2>&1
        if [ $? -ne 0 ]; then
            echo "Ansible run failed"
            exit 1
        fi
    fi
}

function install_service_catalog() {
    ansible-playbook -vvv -i ${DATA_ROOT}/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-service-catalog/config.yml 2>&1
    if [ $? -ne 0 ]; then
        echo "Ansible run failed"
        exit 1
    fi
}

function install_console() {
    if [[ $(oc -n openshift-console get deployments -o=custom-columns=NAME:.metadata.name --no-headers | grep -cE 'console') -ne 1 ]]; then
        ansible-playbook -vvv -i ${DATA_ROOT}/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-console/config.yml 2>&1
        if [ $? -ne 0 ]; then
            echo "Ansible run failed"
            exit 1
        fi
    fi
}

function install_metering() {
    ansible-playbook -vvv -i ${DATA_ROOT}/inventory.ini ${ANSIBLE_ROOT}/openshift-ansible/playbooks/openshift-metering/config.yml 2>&1
    if [ $? -ne 0 ]; then
        echo "Ansible run failed"
        exit 1
    fi
}

function install_olm() {
    # OLM: https://docs.openshift.com/container-platform/3.11/install_config/installing-operator-framework.html#installing-operator-framework
    ##ansible-playbook -vvv -i $DATA_ROOT/inventory.ini $ANSIBLE_ROOT/openshift-ansible/playbooks/updates/registry_auth.yml 2>&1
    #https://github.com/dailyops/cops/blob/master/k8s.rc#L202
    if [[ $(oc -n operator-lifecycle-manager get deployments -o=custom-columns=NAME:.metadata.name --no-headers | grep -cE 'catalog-operator|olm-operator') -ne 2 ]]; then
        ansible-playbook -vvv -i $DATA_ROOT/inventory.ini $ANSIBLE_ROOT/openshift-ansible/playbooks/olm/config.yml 2>&1
        if [ $? -ne 0 ]; then
            echo "Ansible run failed"
            exit 0
        fi
    fi
}

function deploy_crunchydata_templates() {
    set +e
    echo " "
    echo "Deploying CrunchyData templates"
    oc create -n openshift -f ${HOST_SHARE_PATH}/catalog/crunchy-postgres.json || true
    oc create -n openshift -f ${HOST_SHARE_PATH}/catalog/crunchy-postgres-ha.json || true
    set -e
}

function create_admin_account() {
    set +e
    echo " "
    echo "Creating default user '${OPENSHIFT_USER_NAME}'"
    oc adm policy add-cluster-role-to-user cluster-admin ${OPENSHIFT_USER_NAME} || true
    echo " "
    set -e
}

function setup_ipfailover() {
    set +e
    echo " "
    echo "Setting up IPFAILOVER"
    oc adm policy add-scc-to-user privileged system:serviceaccount:default:ipfailover || true
    oc adm ipfailover --watch-port=80 --interface=eth1 --selector="region=primary" --virtual-ips="172.17.4.65-126" --replicas=1 --create || true
    echo " "
    set -e
}

function provision_namespace() {
    local NAMESPACE=$1
    local ADMIN=$2
    local DEVELOPER=$3
    local OBSERVER=$4

    ## Create GPU SCC
    if [[ $(oc get SecurityContextConstraints -o=custom-columns=NAME:.metadata.name --no-headers | grep -c 'nvidia-deviceplugin') -eq 0 ]]; then
        oc create -f ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/nvidia-deviceplugin-scc.yml
    fi

    # Create restricted-anyuid SCC
    if [[ $(oc get SecurityContextConstraints -o=custom-columns=NAME:.metadata.name --no-headers | grep -c 'restricted-anyuid') -eq 0 ]]; then
        oc create -f ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/restricted-anyuid-scc.yaml
    fi

    # Create Ford custom rbac ClusterRoles
    if [[ $(oc get ClusterRole -o=custom-columns=NAME:.metadata.name --no-headers | grep -c 'ns-admin') -eq 0 ]]; then
        oc create -f ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/ns-admin.yaml
    fi
    if [[ $(oc get ClusterRole -o=custom-columns=NAME:.metadata.name --no-headers | grep -c 'ns-developer') -eq 0 ]]; then
        oc create -f ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/ns-developer.yaml
    fi
    if [[ $(oc get ClusterRole -o=custom-columns=NAME:.metadata.name --no-headers | grep -c 'ns-observer') -eq 0 ]]; then
        oc create -f ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/ns-observer.yaml
    fi

    # Create cluster needed for endusers
    ## Grant all authenticated users acess to strorageclass and nodes
    if [[ $(oc get clusterrole -o=custom-columns=NAME:.metadata.name --no-headers | grep -c 'allusers-ford-clusterrole') -eq 0 ]]; then
        oc create -f ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/app-teams-clusterrole.yaml
    fi

    if [[ $(oc get clusterrolebindings -o=custom-columns=NAME:.metadata.name --no-headers | grep -c 'allusers-ford-binding') -eq 0 ]]; then
        oc create -f ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/app-teams-clusterrolebinding.yaml
    fi

    # https://docs.openshift.com/container-platform/3.11/admin_guide/manage_users.html#admin-guide-managing-users-creating-groups
    # https://docs.openshift.com/container-platform/3.11/admin_guide/manage_rbac.html#managing-role-bindings
    # oc adm groups new <group_name> <user1> <user2>
    # oc delete user demo
    # oc delete identity htpasswd_auth:demo

    ## Create default users
    for user in ${ADMIN} ${DEVELOPER} ${OBSERVER}; do
        NAMESPACE_USER_NAME=${user}
        NAMESPACE_USER_PASSWD=${NAMESPACE_USER_NAME}
        if ! grep -q "${user}" /etc/origin/master/htpasswd; then
            htpasswd -b /etc/origin/master/htpasswd ${NAMESPACE_USER_NAME} ${NAMESPACE_USER_PASSWD} || true
        fi
    done

    ## Create project
    if ! oc get namespace -o=custom-columns=NAME:.metadata.name --no-headers | grep -q ${NAMESPACE}; then
        echo "Creating project "
        oc new-project ${NAMESPACE} --description="${NAMESPACE} namespace" --display-name="${NAMESPACE}" --skip-config-write=true || true

        # Add namespace annotations
        ## https://github.com/openshift/origin/blob/master/test/cmd/admin.sh#L173
        ## https://github.com/wkulhanek/advdev_homework_template
        oc annotate namespace ${NAMESPACE} openshift.io/requester=nsadmin --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/owner=nsadmin --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/createdby=$(oc whoami) --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/createdon=$(date -u +'%Y-%m-%dT%H:%M:%SZ') --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/free-trial=false --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/technology="Toys" --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/allow-gpu=false --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/itms=1234 --overwrite
        oc annotate namespace ${NAMESPACE} ford.com/scc=restricted --overwrite

        # Define namespace resourcequota
        rm -rf /tmp/compute-resources.yaml || true
        set +e
        cp ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/compute-resources.yaml /tmp/compute-resources.yaml
        sed -i "s~__NAMESPACE__~${NAMESPACE}~g" /tmp/compute-resources.yaml
        sed -i "s~__CPUREQUEST__~2000m~g" /tmp/compute-resources.yaml
        sed -i "s~__CPULIMIT__~4000m~g" /tmp/compute-resources.yaml
        sed -i "s~__MEMORYQUOTA__~16Gi~g" /tmp/compute-resources.yaml
        sed -i "s~__DISKQUOTA__~124Gi~g" /tmp/compute-resources.yaml
        sed -i '/requests.nvidia.com\/gpu/d' /tmp/compute-resources.yaml
        sed -i '/ecc-block-performance.storageclass.storage.k8s.io\/requests.storage/d' /tmp/compute-resources.yaml
        sed -i '/ecc-file-performance.storageclass.storage.k8s.io\/requests.storage/d' /tmp/compute-resources.yaml
        sed -i '/edc1h1-block-extreme.storageclass.storage.k8s.io\/requests.storage/d' /tmp/compute-resources.yaml
        sed -i '/edc1h1-block-performance.storageclass.storage.k8s.io\/requests.storage/d' /tmp/compute-resources.yaml
        sed -i '/edc1h1-file-extreme.storageclass.storage.k8s.io\/requests.storage/d' /tmp/compute-resources.yaml
        sed -i '/edc1h1-file-performance.storageclass.storage.k8s.io\/requests.storage/d' /tmp/compute-resources.yaml
        sed -i '/requests.nvidia.com\/gpu: __GPUREQUEST__/d' /tmp/compute-resources.yaml
        if oc get project | grep -q nfs-provisioner; then
            sed -i '/glusterfs-storage.storageclass.storage.k8s.io\/requests.storage: 0Gi/d' /tmp/compute-resources.yaml
            sed -i '/glusterfs-storage-block.storageclass.storage.k8s.io\/requests.storage: 0Gi/d' /tmp/compute-resources.yaml
            sed -i "/limits.memory: __MEMORYQUOTA__/a\    nfs.storageclass.storage.k8s.io/requests.storage: __DISKQUOTA__" /tmp/compute-resources.yaml
        fi
        set -e

        oc create -f /tmp/compute-resources.yaml || true

        # Define namespace limitRanges
        rm -rf /tmp/limit-range.yaml || true
        cp  ${HOST_SHARE_PATH}/templates/tenant-onboarding/manifests/limit-range.yaml /tmp/limit-range.yaml
        sed -i "s~__NAMESPACE__~${NAMESPACE}~g" /tmp/limit-range.yaml || true
        oc create -f /tmp/limit-range.yaml || true

        # Namespace RoleBindings
        oc -n ${NAMESPACE} policy add-role-to-user ns-admin nsadmin || true
        oc -n ${NAMESPACE} policy add-role-to-user ns-developer nsdeveloper || true
        oc -n ${NAMESPACE} policy add-role-to-user ns-observer nsobserver || true

        # Namespace RoleBindings to allow Jenkins tile to grant "view" to "jenkins" service account
        oc -n ${NAMESPACE} policy add-role-to-user role-grantor nsadmin || true
        oc -n ${NAMESPACE} policy add-role-to-user role-grantor nsdeveloper || true

        ## TODO: openshift-enterprise-3.11: Warning: Your changes may get lost whenever a master is restarted, unless you prevent reconciliation of this rolebinding using the following command: oc annotate clusterrolebinding.rbac self-provisioners 'rbac.authorization.kubernetes.io/autoupdate=false' --overwriteerror: unable to find target [system:authenticated]
        ## Remove ability to create projects
        ## DOCS: https://docs.openshift.com/container-platform/3.11/admin_guide/managing_projects.html#disabling-self-provisioning
        oc patch clusterrolebinding.rbac self-provisioners -p '{"subjects": null}' || true
        oc patch clusterrolebinding.rbac self-provisioners -p '{ "metadata": { "annotations": { "rbac.authorization.kubernetes.io/autoupdate": "false" } } }' || true
        oc adm policy remove-cluster-role-from-group self-provisioner system:authenticated || true

        #htpasswd /etc/origin/master/htpasswd cent
        #htpasswd -D /etc/origin/master/htpasswd cent
        #oc delete identity htpasswd_auth:nsadmin

    fi
}

function grant_view_to_olm() {
    local username=$1
    # DOCS: https://docs.openshift.com/container-platform/3.11/install_config/installing-operator-framework.html#launching-your-first-operator_installing-operator-framework
    # Only allow namespace admins acess operators
    oc policy add-role-to-user admin ${username} -n ${OPENSHIFT_EXAMPLE_NAMESPACE} || true
    oc policy add-role-to-user view ${username} -n ${OPENSHIFT_EXAMPLE_NAMESPACE} || true
    oc policy add-role-to-user view ${username} -n operator-lifecycle-manager || true
}

function configure_cnx() {

    if [ "${OPENSHIFT_USE_TIGERA_CNX_MANAGER}" = "true" ]; then
        ## Grant the default service account in kube-system namespace access to the hostnetwork SCC
        #oc project default
        oc adm policy add-scc-to-user hostnetwork -z default -n kube-system

        # STEP: Tigera Secure EE API Server
        # --------------------------------------
        oc -n kube-system get secrets calico-pull-secret -o=json --export | jq -r 'del(.metadata.annotations, .metadata.selfLink, .metadata.creationTimestamp)' | jq -r '.metadata.name |= (if . == "calico-pull-secret" then "cnx-pull-secret" else . end)' | oc -n kube-system create -f - || true

        #oc secrets link rook-ceph-osd ceph-pull-secret --for=pull --namespace=rook-ceph
        # TODO: TLS certs for cnx-manager
        oc -n kube-system apply -f ${HOST_SHARE_PATH}/templates/cnx/cnx-api.yaml
        wait_for_objects kube-system cnx-apiserver

        # STEP: Applying Tigera EE license key
        # --------------------------------------

        #export CALICOCTL_IMAGE="${CALICOCTL_IMAGE}"
        export CALICOCTL_IMAGE="files.caas.ford.com/tigera/calicoctl:v2.4.0"

        #export CNX_PULL_SECRET='cnx-pull-secret'
        export CNX_PULL_SECRET='calico-pull-secret'

        #envsubst < ${HOST_SHARE_PATH}/templates/cnx/calicoctl.yaml > ${DATA_ROOT}/calicoctl.yaml
        #oc -n kube-system apply -f ${DATA_ROOT}/calicoctl.yaml || true

        envsubst < ${HOST_SHARE_PATH}/templates/cnx/calicoctl.yaml | oc -n kube-system apply -f -

        ## Wait fot calicoctl container to start
        wait_for_objects kube-system calicoctl

        ## DOCS: https://docs.okd.io/latest/dev_guide/copy_files_to_container.html
        ## DOCS: https://www.katacoda.com/openshift/courses/introduction/transferring-files
        # https://github.com/search?l=Shell&q=oc+rsync&type=Code
        # https://github.com/openshift/origin/issues/10529
        # https://github.com/maltron/openshift-tooling/blob/master/openshift-rsync.sh
        # POD_NAME=$(oc get po | grep jenkins-server| awk '{print $1}')
        # oc rsync ${POD_NAME}:/myDir/jenkinsHome ../download --strategy='tar' --loglevel=8
        FORD_CNX_LICENSE_FILE=${HOST_SHARE_PATH}/tokens/ford-dev-license.yaml
        CALICOCTL_POD=$(oc -n kube-system get pods -l "k8s-app=calicoctl" -o=custom-columns=NAME:.metadata.name --no-headers=true)
        oc -n kube-system cp ${FORD_CNX_LICENSE_FILE} ${CALICOCTL_POD}:/tmp
        oc -n kube-system exec ${CALICOCTL_POD} -- calicoctl apply -f /tmp/ford-dev-license.yaml
        oc -n kube-system exec ${CALICOCTL_POD} -- calicoctl get license
        oc -n kube-system exec ${CALICOCTL_POD} -- sh -c "rm -rf /tmp/ford-dev-license.yaml"

        # STEP: Tigera Secure EE Manager
        # --------------------------------------

        # Create calico-monitoring if missing
        if ! oc get project | grep -q calico-monitoring; then
            oc new-project calico-monitoring
        fi

        oc adm policy add-scc-to-user anyuid system:serviceaccount:calico-monitoring:cnx-manager

        oc -n calico-monitoring delete secret cnx-manager-tls > /dev/null 2>&1 || true
        oc -n calico-monitoring create secret generic cnx-manager-tls \
            --from-file=cert=/etc/origin/master/master.server.crt \
            --from-file=key=/etc/origin/master/master.server.key

        ## Deploy CNX OAuthClient CRD
        #export CNX_OATH_ENPOINT="https://cnx-manager-kube-system.app.${OPENSHIFT_DOMAIN}/login/oauth/callback"
        export CNX_OATH_ENPOINT="https://cnx-manager.${OPENSHIFT_DOMAIN}/login/oauth/callback"
        envsubst < ${HOST_SHARE_PATH}/templates/cnx/oauth.yaml | oc -n calico-monitoring apply -f -

        oc -n kube-system get secrets calico-pull-secret -o=json --export | jq -r 'del(.metadata.annotations, .metadata.selfLink, .metadata.creationTimestamp)' | jq -r '.metadata.name |= (if . == "calico-pull-secret" then "cnx-pull-secret" else . end)' | oc -n calico-monitoring create -f - || true

        export CNX_AUTHENTICATION_TYPE='OAuth'
        export CNX_OAUTH_AUTHORITY="https://api.${OPENSHIFT_DOMAIN}:${OPENSHIFT_API_PORT}/oauth/authorize"
        export CNX_APISERVER_IMAGE="files.caas.ford.com/tigera/cnx-apiserver:v2.4.0" #"${CNX_APISERVER_IMAGE}"
        export CNX_QUERYSERVER_IMAGE="files.caas.ford.com/tigera/cnx-queryserver:v2.4.0" #"${CNX_QUERYSERVER_IMAGE}"
        export CNX_MANAGER_IMAGE="files.caas.ford.com/tigera/cnx-manager:v2.4.1" #"${CNX_MANAGER_IMAGE}"
        export CNX_MANAGER_PROXY_IMAGE="files.caas.ford.com/tigera/cnx-manager-proxy:v2.4.1" #"${CNX_MANAGER_PROXY_IMAGE}"
        export CNX_MANAGER_INIT_PEM_IMAGE="files.caas.ford.com/tigera/alpine:3.7" #"${CNX_MANAGER_INIT_PEM_IMAGE}"
        export CNX_MANAGER_KIBANA_URL="https://network-monitoring.app.${OPENSHIFT_DOMAIN}"
        export ES_PROXY_IMAGE="files.caas.ford.com/tigera/es-proxy:v2.4.0"
        export COMPLIANCE_CONTROLLER_IMAGE="files.caas.ford.com/tigera/compliance-controller:v2.4.0"
        export COMPLIANCE_REPORTER_IMAGE="files.caas.ford.com/tigera/compliance-reporter:v2.4.0"
        export COMPLIANCE_SERVER_IMAGE="files.caas.ford.com/tigera/compliance-server:v2.4.0"
        export COMPLIANCE_SNAPSHOTTER_IMAGE="files.caas.ford.com/tigera/compliance-snapshotter:v2.4.0"
        export CNX_PULL_SECRET='cnx-pull-secret'
        export CNX_MANAGER_TLS_SECRET='cnx-manager-tls'

        envsubst < ${HOST_SHARE_PATH}/templates/cnx/cnx.yaml | oc -n kube-system apply -f -


        # TODO prometheus and logging
        # STEP: Enable Metrics
        # --------------------------------------

        if ! oc -n kube-system exec ${CALICOCTL_POD} -- calicoctl get felixconfig default -o yaml --export | grep -q 'prometheusReporterEnabled'; then
            ## NOTE: leading '\' after /a is requried to escape the spaces to preserve YAML indentation
            oc -n kube-system exec ${CALICOCTL_POD} -- sh -c "calicoctl get felixconfig default -o yaml --export | sed -e \"/reportingInterval: 0s/a \  prometheusReporterEnabled: true\n  prometheusReporterPort: 9081\" | calicoctl replace -f -"
        fi

        # Allow Prometheus to scrape the metrics by opening up the port on each host
        iptables -I INPUT -p tcp --dport 9081 -j ACCEPT



    fi

    if ! oc -n kube-system get deployments | grep -q cnx-manager; then
        if [ "${OPENSHIFT_USE_TIGERA_CNX_MANAGER}" = "true" ]; then
            ## Deploy CNX OAuthClient CRD
            #export CNX_OATH_ENPOINT="https://cnx-manager-kube-system.app.${OPENSHIFT_DOMAIN}/login/oauth/callback"
            export CNX_OATH_ENPOINT="https://cnx-manager.${OPENSHIFT_DOMAIN}/login/oauth/callback"
            envsubst < ${HOST_SHARE_PATH}/templates/cnx/oauth.yaml > ${DATA_ROOT}/oauth.yaml
            oc -n kube-system apply -f ${DATA_ROOT}/oauth.yaml || true

            ## Deploy calicoctl pod
            export CALICOCTL_IMAGE="${CALICOCTL_IMAGE}"
            #export CNX_PULL_SECRET='cnx-pull-secret'
            export CNX_PULL_SECRET='calico-pull-secret'
            envsubst < ${HOST_SHARE_PATH}/templates/cnx/calicoctl.yaml > ${DATA_ROOT}/calicoctl.yaml
            oc -n kube-system apply -f ${DATA_ROOT}/calicoctl.yaml || true

            ## Wait fot calicoctl container to start
            set +e
            until oc -n kube-system get pods | grep calicoctl | grep Running ; do
            echo "Waiting for calicoctl pods to start";
            sleep 10;
            done
            set -e

            ## Apply CNX developer license
            ## DOCS: https://docs.okd.io/latest/dev_guide/copy_files_to_container.html
            ## DOCS: https://www.katacoda.com/openshift/courses/introduction/transferring-files
            # https://github.com/search?l=Shell&q=oc+rsync&type=Code
            # https://github.com/openshift/origin/issues/10529
            # https://github.com/maltron/openshift-tooling/blob/master/openshift-rsync.sh
            # POD_NAME=$(oc get po | grep jenkins-server| awk '{print $1}')
            # oc rsync ${POD_NAME}:/myDir/jenkinsHome ../download --strategy='tar' --loglevel=8
            FORD_CNX_LICENSE_FILE=ford-dev-license.yaml
            oc -n kube-system cp /root/ldev-secrets/${FORD_CNX_LICENSE_FILE} calicoctl:/tmp
            oc -n kube-system exec calicoctl -- calicoctl apply -f /tmp/${FORD_CNX_LICENSE_FILE}

            ## Install CNX Manager
            oc adm policy add-scc-to-user anyuid system:serviceaccount:kube-system:cnx-manager

            oc -n kube-system delete secret cnx-manager-tls > /dev/null 2>&1 || true
            oc create secret generic cnx-manager-tls \
                --from-file=cert=/etc/origin/master/master.server.crt \
                --from-file=key=/etc/origin/master/master.server.key -n kube-system

            export CNX_AUTHENTICATION_TYPE='OAuth'
            export CNX_OAUTH_AUTHORITY="https://api.${OPENSHIFT_DOMAIN}:${OPENSHIFT_API_PORT}/oauth/authorize"
            export CNX_APISERVER_IMAGE="${CNX_APISERVER_IMAGE}"
            export CNX_QUERYSERVER_IMAGE="${CNX_QUERYSERVER_IMAGE}"
            export CNX_MANAGER_IMAGE="${CNX_MANAGER_IMAGE}"
            export CNX_MANAGER_PROXY_IMAGE="${CNX_MANAGER_PROXY_IMAGE}"
            export CNX_MANAGER_INIT_PEM_IMAGE="${CNX_MANAGER_INIT_PEM_IMAGE}"
            export CNX_MANAGER_KIBANA_URL="https://kibana-calico-monitoring.app.${OPENSHIFT_DOMAIN}"
            #export CNX_PULL_SECRET='cnx-pull-secret'
            export CNX_PULL_SECRET='calico-pull-secret'
            export CNX_MANAGER_TLS_SECRET='cnx-manager-tls'

            envsubst < ${HOST_SHARE_PATH}/templates/cnx/cnx.yaml > ${DATA_ROOT}/cnx.yaml
            oc -n kube-system apply -f ${DATA_ROOT}/cnx.yaml || true

            #oc -n kube-system get pods --selector k8s-app=cnx-manager -o jsonpath='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'
            #oc -n kube-system get pods --selector k8s-app=cnx-manager -o jsonpath='{.items[?(@.status.phase=="Running")].metadata.name}'
            #kubectl -n kube-system get pod/calicoctl -o go-template="{{range .status.conditions}}{{if eq .type \"Ready\" }}{{.status}}{{end}}{{end}}"
            #kubectl -n kube-system get pods calico-etcd-bqvwv  -o jsonpath='{.items[*].status.phase}'

            ## Waiting for cnx-manager pod to be ready
            JSONPATH='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'; until oc -n kube-system get pods --selector k8s-app=cnx-manager -o jsonpath="$JSONPATH" 2>&1 | grep -q "Ready=True"; do sleep 1;echo "waiting for cnx-manager to be available"; oc -n kube-system get pods; done

            ## Waiting for cnx-apiserver pod to be ready
            JSONPATH='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'; until oc -n kube-system get pods --selector apiserver=true -o jsonpath="$JSONPATH" 2>&1 | grep -q "Ready=True"; do sleep 1;echo "waiting for cnx-apiserver to be available"; oc -n kube-system get pods; done

            ## Create CNX Manager route
            #export CNX_MANAGER_URL="cnx-manager-kube-system.app.${OPENSHIFT_DOMAIN}"
            export CNX_MANAGER_URL="cnx-manager.${OPENSHIFT_DOMAIN}"
            envsubst < ${HOST_SHARE_PATH}/templates/cnx/cnxmanager-route.yaml > ${DATA_ROOT}/cnxmanager-route.yaml
            oc -n kube-system apply -f ${DATA_ROOT}/cnxmanager-route.yaml || true

            ## Create calicoq pod
            export CALICOQ_IMAGE="${CALICOQ_IMAGE}"
            #export CNX_PULL_SECRET='cnx-pull-secret'
            export CNX_PULL_SECRET='calico-pull-secret'
            envsubst < ${HOST_SHARE_PATH}/templates/cnx/calicoq.yaml > ${DATA_ROOT}/calicoq.yaml
            oc -n kube-system apply -f ${DATA_ROOT}/calicoq.yaml || true

            ## Wait fot calicoq container to start
            set +e
            until oc -n kube-system get pods | grep calicoq | grep Running ; do
            echo "Waiting for calicoq pods to start";
            sleep 10;
            done
            set -e

            ## Apply default policy
            oc -n kube-system apply -f ${HOST_SHARE_PATH}/templates/cnx/cnx-policy.yaml || true

            ## https://docs.tigera.io/v2.2/getting-started/openshift/installation
            oc adm policy add-cluster-role-to-user --namespace=kube-system admin admin
            oc adm policy add-cluster-role-to-user --namespace=calico-monitoring admin admin
        fi
    fi
}

function configure_cnx_analytics() {
    if ! oc get namespace | grep -q calico-monitoring; then
        if [ "${OPENSHIFT_USE_TIGERA_ANALYTICS}" = "true" ]; then
            # Enable Metrics
            # DOCS: https://docs.tigera.io/v2.2/getting-started/openshift/installation#enable-metrics
            oc -n kube-system cp ${HOST_SHARE_PATH}/templates/cnx/default-felixconfig.yaml calicoctl:/tmp || true
            oc -n kube-system exec calicoctl -- calicoctl replace -f /tmp/default-felixconfig.yaml || true
            oc -n kube-system exec calicoctl -- rm -rf /tmp/default-felixconfig.yaml || true

            # Allow Prometheus to scrape the metrics by opening up the port on each host:
            iptables -I INPUT -p tcp --dport 9081 -j ACCEPT || true

            # Configure metrics and logs
            # DOCS: https://docs.tigera.io/v2.2/getting-started/openshift/installation#configure-metrics-and-logs
            # Apply the flow logs patch.
            oc patch daemonset calico-node -n kube-system --patch "$(cat ${HOST_SHARE_PATH}/templates/cnx/patch-flow-logs.yaml)" || true

            # Allow Prometheus to run as root.
            oc adm policy add-scc-to-user --namespace=calico-monitoring anyuid -z default || true

            # Allow Prometheus to configure and use a security context.
            oc adm policy add-scc-to-user anyuid system:serviceaccount:calico-monitoring:prometheus || true

            # Allow sleep pod to run with host networking.
            oc adm policy add-scc-to-user --namespace=calico-monitoring hostnetwork -z default || true

            # Allow Prometheus to have pods in kube-system namespace on each node.
            oc annotate ns kube-system openshift.io/node-selector="" --overwrite || true

            # Deploy es-operator
            export PROMETHEUS_OPERATOR_IMAGE="${PROMETHEUS_OPERATOR_IMAGE}"
            export ELASTICSEARCH_OPERATOR_IMAGE="${ELASTICSEARCH_OPERATOR_IMAGE}"
            envsubst <  ${HOST_SHARE_PATH}/templates/cnx/es-operator.yaml > ${DATA_ROOT}/es-operator.yaml
            oc apply -f ${DATA_ROOT}/es-operator.yaml || true

            # Wait for the alertmanagers.monitoring.coreos.com, prometheuses.monitoring.coreos.com,
            # servicemonitors.monitoring.coreos.com, and elasticsearchclusters.enterprises.upmc.com
            # custom resource definitions to be created. Check by running:
            set +e
            for crd in alertmanagers.monitoring.coreos.com prometheuses.monitoring.coreos.com \
                servicemonitors.monitoring.coreos.com elasticsearchclusters.enterprises.upmc.com; do
                until oc get customresourcedefinitions | grep $crd; do
                    echo "Waiting for CRD $crd";
                    sleep 10;
                done
            done
            set -e

            # Allow the monitoring pods to be scheduled on the master node.
            oc annotate ns calico-monitoring openshift.io/node-selector="" --overwrite || true

            # The bundled Elasticsearch operator is configured to use a StorageClass called elasticsearch-storage
            # and local storage. Use the following command to apply the manifest.
            oc apply -f ${HOST_SHARE_PATH}/templates/cnx/elastic-storage-local.yaml || true

            ## Deploy calico prometheus
            #REG_AUTH_USER=$(cat /root/.docker/config.json | jq -r '.auths."quay.io".auth' | base64 --decode | cut -d ':' -f1) || true
            #REG_AUTH_PASSWORD=$(cat /root/.docker/config.json | jq -r '.auths."quay.io".auth' | base64 --decode | cut -d ':' -f2) || true
            #oc create secret docker-registry calico-pull-secret \
            #    --docker-username="${REG_AUTH_USER}" \
            #    --docker-password="${REG_AUTH_PASSWORD}" \
            #    --docker-server="quay.io" \
            #    --namespace=calico-monitoring || true

            oc -n kube-system get secrets calico-pull-secret -o=json --export | jq -r 'del(.metadata.annotations, .metadata.selfLink, .metadata.creationTimestamp)' | oc -n calico-monitoring create -f - || true

            #export CNX_PULL_SECRET='cnx-pull-secret'
            export CNX_PULL_SECRET='calico-pull-secret'
            export TIGERA_CNX_KIBANA_HOST='kibana-calico-monitoring.app.oc.local'
            export TIGERA_ELASTICSEARCH_STORAGE_CLASS='elasticsearch-storage'
            export BUSYBOX_IMAGE="${BUSYBOX_IMAGE}"
            export FLUENTD_IMAGE="${FLUENTD_IMAGE}"
            export PROMETHEUS_ALERTMANAGER_IMAGE="${PROMETHEUS_ALERTMANAGER_IMAGE}"
            export PROMETHEUS_IMAGE="${PROMETHEUS_IMAGE}"
            export KIBANA_OSS_IMAGE="${KIBANA_OSS_IMAGE}"
            export ELASTICSEARCH_OSS_IMAGE="${ELASTICSEARCH_OSS_IMAGE}"
            #export TIGERA_ELASTICSEARCH_STORAGE-CLASS='glusterfs-storage-block'
            envsubst < ${HOST_SHARE_PATH}/templates/cnx/monitor-calico.yaml > ${DATA_ROOT}/monitor-calico.yaml
            oc apply -f ${DATA_ROOT}/monitor-calico.yaml || true

            # Wait for the pod
            # alertmanager-calico-node-alertmanager-* calico-prometheus-operator-* prometheus-calico-node-prometheus-*
            set +e
            for pod in elasticsearch-operator-* kibana-tigera-elasticsearch-* tigera-fluentd-node-*; do
                wait_for_pod calico-monitoring ${pod}
            done
            set -e

            # Reconfigure the Elasticsearch deployment.
            oc -n calico-monitoring get deployment es-client-tigera-elasticsearch -o yaml --export > /tmp/tigera-elasticsearch.yaml
            sed -i '/capabilities/,+2 d' /tmp/tigera-elasticsearch.yaml
            oc replace -n calico-monitoring -f /tmp/tigera-elasticsearch.yaml || true
            rm -rf /tmp/tigera-elasticsearch.yaml

            # Remove the ReplicaSet from the deployment we replaced.
            # get all replicasets which are not behaving well
            # oc get rs -n calico-monitoring | awk '$2 != $3 || $2 != $4 {print $0}'
            oc -n calico-monitoring delete rs $(oc get rs -n calico-monitoring | awk '$3 == 0 {print $0}' | cut -d ' ' -f1) || true

            # Reconfigure the Elasticsearch data storage.
            oc -n calico-monitoring get statefulset es-data-tigera-elasticsearch-elasticsearch-storage -o yaml --export > /tmp/data-tigera-elasticsearch-storage.yaml
            sed -i '/capabilities/,+2 d' /tmp/data-tigera-elasticsearch-storage.yaml
            oc replace -n calico-monitoring -f /tmp/data-tigera-elasticsearch-storage.yaml || true
            rm -rf /tmp/data-tigera-elasticsearch-storage.yaml

            # Reconfigure the Elasticsearch master storage.
            oc -n calico-monitoring get statefulset es-master-tigera-elasticsearch-elasticsearch-storage -o yaml --export > /tmp/master-tigera-elasticsearch-storage.yaml
            sed -i '/capabilities/,+2 d' /tmp/master-tigera-elasticsearch-storage.yaml
            oc replace -n calico-monitoring -f /tmp/master-tigera-elasticsearch-storage.yaml || true
            rm -rf /tmp/master-tigera-elasticsearch-storage.yaml

            # Reconfigure the Elasticsearch sysctl operator.
            oc -n default get ds elasticsearch-operator-sysctl -o yaml --export > /tmp/elasticsearch-operator-sysctl.yaml
            sed -i '/hostPID/d' /tmp/elasticsearch-operator-sysctl.yaml
            oc replace -n default -f /tmp/elasticsearch-operator-sysctl.yaml || true
            rm -rf /tmp/elasticsearch-operator-sysctl.yaml

            # Check if all the pods are are running
            # calico-prometheus-operator-* prometheus-calico-node-prometheus-* alertmanager-calico-node-alertmanager-*
            set +e
            for pod in elasticsearch-operator-* es-client-tigera-elasticsearch-* \
                es-data-tigera-elasticsearch-elasticsearch-storage-* \
                es-master-tigera-elasticsearch-elasticsearch-storage-* \
                kibana-tigera-elasticsearch-* tigera-fluentd-node-*; do
                wait_for_pod calico-monitoring ${pod}
            done
            set -e

            # Deploy Kibana dashboard
            export TINY_TOOLS_IMAGE="${TINY_TOOLS_IMAGE}"
            envsubst < ${HOST_SHARE_PATH}/templates/cnx/kibana-dashboards.yaml > ${DATA_ROOT}/kibana-dashboards.yaml
            oc apply -f ${DATA_ROOT}/kibana-dashboards.yaml || true
        fi
    fi
}

function configure_cnx_policy() {
    #oc -n kube-system exec -it calicoctl -- rm -rf /tmp/network-security-policy
    #oc -n kube-system exec -it calicoctl -- ls -la /tmp/network-security-policy
    #FORD_CNX_LICENSE_FILE=ford-dev-license.yaml
    #oc -n kube-system cp ${HOST_SHARE_PATH}/${FORD_CNX_LICENSE_FILE} calicoctl:/tmp
    #oc -n kube-system exec calicoctl -- calicoctl apply -f /tmp/${FORD_CNX_LICENSE_FILE}

    # Copy files
    oc -n kube-system rsync --no-perms=false --progress=true --strategy=tar ${HOST_SHARE_PATH}/templates/network-security-policy calicoctl:/tmp --loglevel=8

    # Create tiers
    oc -n kube-system exec calicoctl -- sh -c 'cd /tmp/network-security-policy/tiers; for i in $(ls .);do calicoctl apply -f $i;done'

    # Create security-admin user
    if ! grep -q "security-admin" /etc/origin/master/htpasswd; then
        htpasswd -b /etc/origin/master/htpasswd security-admin sandbox || true
    fi

    # CNX RBAC

    #
}

function check_endpoint() {
    local endpoint=$1
    index=$((0))
    sleeptime=3
    while [[ "$(curl -Lk -s -o /dev/null -w ''%{http_code}'' ${endpoint})" != "200" ]]; do
        if [[ ${index} -gt 0 ]]; then
            echo "Waiting for server ...";
        else
            echo "Waiting for server $((${index} *  ${sleeptime})) seconds ...";
        fi
        index=$(($index+1));
        sleep ${sleeptime};
    done
}

function install_nfs_provisioner() {
    if ! oc get project | grep -q nfs-provisioner; then
        oc new-project nfs-provisioner

        ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
        source /root/.docker/pull-secrets.env
        oc create secret docker-registry nfs-pull-secret \
        --docker-username="${KUBERNETES_INCUBATOR_PULL_USER}" \
        --docker-password="${KUBERNETES_INCUBATOR_PULL_TOKEN}" \
        --docker-email=caassup@ford.com \
        --docker-server=files.caas.ford.com \
        --namespace=nfs-provisioner

        ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
        #oc secrets link default nfs-pull-secret --for=pull --namespace=nfs-provisioner

        ## Base directory where the dynamic nfs provsioner will cerate PVs
        if [ ! -d /var/lib/k8s_dynamic_volumes/export ]; then
            mkdir -p /var/lib/k8s_dynamic_volumes/export
            # https://docs.openshift.com/container-platform/3.10/install_config/configuring_local.html#local-volume-mounting-local-volumes
            # https://docs.openshift.com/container-platform/3.11/install_config/persistent_storage/pod_security_context.html#selinuxoptions
            # https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/7/html/selinux_users_and_administrators_guide/chap-security-enhanced_linux-selinux_contexts
            # https://bugzilla.redhat.com/show_bug.cgi?id=1525921#c8
            # https://opensource.com/article/18/2/understanding-selinux-labels-container-runtimes
            # https://danwalsh.livejournal.com/
            # https://www.projectatomic.io/blog/2018/10/fedora-atomic-28-to-29-upgrade/
            chcon -R unconfined_u:object_r:svirt_sandbox_file_t:s0 /var/lib/k8s_dynamic_volumes/export/
        fi

        oc apply -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/scc.yaml || true
        oc apply -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/serviceaccount.yaml || true
        oc adm policy add-scc-to-user nfs-provisioner -z nfs-provisioner -n nfs-provisioner

        ## https://developers.redhat.com/blog/2017/04/21/dynamic-persistent-storage-using-the-red-hat-container-development-kit-3-0/
        #oc adm policy add-cluster-role-to-user cluster-reader system:serviceaccount:nfs-provisioner:nfs-provisioner
        #oc adm policy add-cluster-role-to-user system:pv-provisioner-controller system:serviceaccount:nfs-provisioner:nfs-provisioner
        #oc adm policy add-cluster-role-to-user system:pv-binder-controller system:serviceaccount:nfs-provisioner:nfs-provisioner
        #oc adm policy add-cluster-role-to-user system:pv-recycler-controller system:serviceaccount:nfs-provisioner:nfs-provisioner

        #oc adm policy add-scc-to-user privileged -z nfs-provisioner -n dynamic-storage
        oc apply -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/rbac.yaml || true

        export NFS_PROVISIONER_IMAGE="${NFS_PROVISIONER_IMAGE}"
        envsubst < ${HOST_SHARE_PATH}/templates/nfs-provisioner/deployment.yaml > ${DATA_ROOT}/nfs-deployment.yaml
        oc apply -f ${DATA_ROOT}/nfs-deployment.yaml || true
        ## Waiting for cnx-manager pod to be ready
        JSONPATH='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'; until oc -n nfs-provisioner get pods --selector app=nfs-provisioner -o jsonpath="$JSONPATH" 2>&1 | grep -q "Ready=True"; do sleep 1;echo "waiting for nfs-provisioner to be available"; oc -n nfs-provisioner get pods; done
        oc apply -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/storageclass.yaml || true
    fi
}

function uninstall_nfs_provisioner() {
    if oc get project | grep -q nfs-provisioner; then
        oc delete -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/deployment.yaml || true
        oc delete -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/rbac.yaml || true
        oc delete -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/storageclass.yaml || true
        oc adm policy remove-scc-to-user nfs-provisioner -z nfs-provisioner -n nfs-provisioner || true
        oc delete -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/serviceaccount.yaml || true
        oc delete -f ${HOST_SHARE_PATH}/templates/nfs-provisioner/scc.yaml || true
        rm -rf /var/lib/k8s_dynamic_volumes/export
        until [[ $(oc get pods --no-headers=true -n nfs-provisioner 2>/dev/null | wc -l) -eq 0 ]]; do
            sleep 1
        done
        oc delete project nfs-provisioner || true
    fi
}

function customize_login_page() {
    # DOCS: https://docs.openshift.com/container-platform/3.11/install_config/web_console_customization.html#customizing-the-login-page
    # DOCS: http://uncontained.io/
    # DOCS: https://github.com/darxkies/k8s-tew
    echo ""
}

function postinstall_cleanup() {
    sed -i "s|^oreg_auth_user=.*$|oreg_auth_user=''|g" ${DATA_ROOT}/inventory.ini
    sed -i "s|^oreg_auth_password=.*$|oreg_auth_password=''|g" ${DATA_ROOT}/inventory.ini

    cp -f /tmp/vagrant-shell ${DATA_ROOT}/init.sh
    chown vagrant:vagrant ${DATA_ROOT}/init.sh
    chmod 755 ${DATA_ROOT}/init.sh
    sed -i "s|^export RHSM_ORG=.*$|export RHSM_ORG=''|g" ${DATA_ROOT}/init.sh
    sed -i "s|^export RHSM_ACTIVATION_KEY=.*$|export RHSM_ACTIVATION_KEY=''|g" ${DATA_ROOT}/init.sh

    echo " "
    echo "Copying kubeconfig file to ${ARTIFACT_PATH}/.kube"
    rsync -rq --exclude=http-cache --exclude=api_int.oc.local_8443 /root/.kube ${HOST_SHARE_PATH}/artifacts/
    sed -i -e "s|https://api-int.oc.local|https://${MASTER_IP}|g" ${HOST_SHARE_PATH}/artifacts/.kube/config
    sed -i -e "s|https://api.oc.local|https://${MASTER_IP}|g" ${HOST_SHARE_PATH}/artifacts/.kube/config

    echo "Copying kubeconfig file to ${DATA_ROOT}/.kube"
    rsync -rq --exclude=http-cache --exclude=api_int.oc.local_8443 /root/.kube ${DATA_ROOT}/
    chown -R vagrant:vagrant ${DATA_ROOT}/.kube
}

function print_welcome_message() {
    echo " "
    echo "OpenShift CLI Bash completion:"
    echo "-----------------------------------------------------"
    echo "  source <(oc completion bash)"
    echo "  source <(oc completion zsh)"
    echo " "

    echo "On MacOS/Linux execute"
    echo "-----------------------------------------------------"
    echo "  export KUBECONFIG=\$(pwd)/artifacts/.kube/config"
    echo "  export PATH=\$(pwd)/artifacts/bin:\$PATH"
    #echo "  ${ARTIFACT_PATH}/bin/oc login -u ${OPENSHIFT_USER_NAME} -p ${OPENSHIFT_USER_PASSWD} https://console.${OPENSHIFT_DOMAIN}:${OPENSHIFT_API_PORT}/"
    echo " "

    echo "On Windows execute:"
    echo "-----------------------------------------------------"
    echo "  \$env:KUBECONFIG = \"\$PWD\\artifacts\\.kube\\config\""
    echo "  \$env:path = \"\$PWD\\artifacts\\bin\;\$env:ProgramFiles\\Git\\bin;\$env:ProgramFiles\\Git\\usr\\bin;\$env:path\""
    #echo "  ${ARTIFACT_PATH}/bin/oc.exe login -u ${OPENSHIFT_USER_NAME} -p ${OPENSHIFT_USER_PASSWD} https://console.${OPENSHIFT_DOMAIN}:${OPENSHIFT_API_PORT}/"
    echo " "

    echo "OpenShift console:"
    echo "-----------------------------------------------------"
    echo "  Url:      https://console.${OPENSHIFT_DOMAIN}:${OPENSHIFT_API_PORT} or https://console.app.${OPENSHIFT_DOMAIN}"
    echo "  Username: ${OPENSHIFT_USER_NAME}"
    echo "  Password: ${OPENSHIFT_USER_PASSWD}"
    echo " "

    echo "OpenShift test namespace:"
    echo "-----------------------------------------------------"
    echo "  NameSpace: ${OPENSHIFT_EXAMPLE_NAMESPACE}"
    echo " "
    echo "  example namespace Users/Creds:"
    echo "   Admin      : nsadmin/nsadmin"
    echo "   nsdeveloper: nsdeveloper/nsdeveloper"
    echo "   nsobserver : nsobserver/nsobserver"
    echo " "
}

function install_build_tools() {
    # https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux_atomic_host/7/html-single/managing_containers/#installing_podman
    #subscription-manager repos \
    #    --enable=rhel-7-server-rpms \
    #    --enable=rhel-7-server-extras-rpms \
    #    --enable=rhel-7-server-optional-rpms || true
    yum -y install buildah podman || true
}

function scale_crds() {
    # https://github.com/openshift/openshift-windows/blob/master/3.11/standalone/allinone.sh
    # https://github.com/opentable/ansible-examples/blob/master/ansible.cfg
    # https://www.jeffgeerling.com/blog/2017/slow-ansible-playbook-check-ansiblecfg
    # https://jsherz.com/ansible/infrastructure/platform/engineering/2017/02/23/speed-up-ansible-builds.html
    # https://unix.stackexchange.com/questions/79960/how-to-disable-requiretty-for-a-single-command-in-sudoers
    # https://github.com/moritata/Vagrant/blob/master/aws/Vagrantfile#L41
    # https://github.com/kpischke/HPC-Pack-2012/blob/master/openshift-origin-rhel/scripts/deployOpenShift.sh
    # https://github.com/cappetta/vagrant_aws_bootstrap/blob/master/cloud-init/linux_initialize_w_CAcrt.txt#L3
    # https://github.com/marcinbojko/hv-packer/blob/master/extra/files/gen2-centos/vagrant.sh
    # https://github.com/oki2a24/packer-templates/blob/master/centos-5.11-x86_64/anaconda-ks.cfg#L37
    # https://github.com/agnaldo-asl/OPM/blob/master/Azure/HPC-Cluster/azuredeploy.sh
    # https://github.com/ironcladlou/openshift4-libvirt-gcp
    # https://github.com/imcsk8/origin-tools
    # https://github.com/operator-framework/operator-metering/blob/master/hack/lib/util.sh
    # https://sysdig.com/blog/kubernetes-monitoring-prometheus-operator-part3/
    # https://supergiant.io/blog/simple-management-of-prometheus-monitoring-pipeline-with-the-prometheus-operator/

    # https://stackoverflow.com/a/32895908
    oc -n openshift-monitoring get Alertmanager/main -o yaml | sed "s/replicas: 3/replicas: 1/" | oc replace -f -
    oc -n openshift-monitoring get StatefulSet/alertmanager-main -o yaml | sed "s/replicas: 3/replicas: 1/" | oc replace -f -

    oc -n openshift-monitoring get Prometheus/k8s -o yaml | sed "s/replicas: 2/replicas: 1/" | oc replace -f -
    oc -n openshift-monitoring get StatefulSet/prometheus-k8s -o yaml | sed "s/replicas: 2/replicas: 1/" | oc replace -f -
}

function customize_loginscreen() {
    \cp --force ${HOST_SHARE_PATH}/templates/login.html /etc/origin/master/login.html

	# NOTE: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
	login_patch=$(cat <<- EOF
	admissionConfig:
	oauthConfig:
	  templates:
	    login: /etc/origin/master/login.html
	EOF
	)

    \cp --force "/etc/origin/master/master-config.yaml" "/etc/origin/master/master-config.yaml.bkp"
    \cp --force "/etc/origin/master/master-config.yaml.bkp" "/etc/origin/master/master-config.yaml.prepatch"
    oc ex config patch /etc/origin/master/master-config.yaml.prepatch --patch "${login_patch}" > /etc/origin/master/master-config.yaml
    rm -rf /etc/origin/master/master-config.yaml.prepatch

    #restart_control_plane
    #wait_for_k8s_apiserver
}

function clean_openshift_catalog() {
    # Delete ImageStreams
    declare -A is_to_keep=()
    for i in dotnet dotnet-runtime httpd java jenkins nginx nodejs perl python redhat-openjdk18-openshift ruby; do
        is_to_keep[$i]=$i
    done
    for is in $(oc -n openshift get is -o=custom-columns=NAME:.metadata.name --no-headers); do
        if [[ -z "${is_to_keep[${is}]}" ]]; then
            #echo "I will delete is $is not in ${is_to_keep[${is}]}"
            oc -n openshift delete is/${is}
        else
            #echo "I will patch is $is"
            # WORK AROUND: patch imageStream update the referencePolicy:\ntype: Local
            # DOCS: https://blog.openshift.com/image-streams-faq/
            # DOCS: https://docs.openshift.com/container-platform/3.11/dev_guide/managing_images.html#reference-policy
            # REFS: https://github.com/radanalyticsio/radanalyticsio.github.io/blob/master/resources.yaml
            oc -n openshift get is/${is} -o yaml | sed "s/type: Local/type: Source/" | oc replace -f -
        fi
    done

    # Delete Templates
    declare -A tmpl_to_keep=()
    for t in dotnet-example dotnet-runtime-example httpd-example jenkins-ephemeral jenkins-persistent nginx-example openjdk18-web-basic-s2i; do
        tmpl_to_keep[$t]=$t
    done
    for tmpl in $(oc -n openshift get templates -o=custom-columns=NAME:.metadata.name --no-headers); do
        if [[ -z "${tmpl_to_keep[${tmpl}]}" ]]; then
            #echo "I will delete template $tmpl not in ${is_to_keep[${tmpl}]}"
            oc -n openshift delete templates/${tmpl}
        fi
    done
}

# BUG: https://access.redhat.com/support/cases/#/case/02238130
function patch_imagestreams() {
    for is in $(oc -n openshift get is -o=custom-columns=NAME:.metadata.name --no-headers); do
        oc -n openshift get is/${is} -o yaml | sed "s/type: Local/type: Source/" | oc replace -f -
    done
}

function backup_quay_database() {
    local quay_namespace=$1
    local quay_dbname=$2
    local quay_pgclustername=$3
    local backup_dir=$4

    read -r -p "This will scale down quay to zero instances. Are you sure? [y/n] " response

    if [[ $response =~ ^([yY][eE][sS]|[yY])+$ ]]; then
        if [ "${QUAY_SETUP}" = "true" ]; then
            QUAY_DEPLOYMENT_NAME=$(oc -n ${quay_namespace} get deployment --selector=quay-enterprise-component=config --no-headers=true -o=custom-columns=NAME:.metadata.name 2>/dev/null || true)
        else
            QUAY_DEPLOYMENT_NAME=$(oc -n ${quay_namespace} get deployment --selector=quay-enterprise-component=app --no-headers=true -o=custom-columns=NAME:.metadata.name 2>/dev/null || true)
        fi

        if [ "${QUAY_DEPLOYMENT_NAME}" != "" ]; then
            # scale down quay pod's to zero
            oc -n ${quay_namespace} scale --replicas=0 deployment ${QUAY_DEPLOYMENT_NAME}

            # Wait for quay pod to terminate
            until [ $(oc -n ${quay_namespace} get deployment ${QUAY_DEPLOYMENT_NAME} -ojsonpath="{.spec.replicas}") == "0" ] > /dev/null 2>&1; do sleep 1; oc -n ${quay_namespace} get deployment ${QUAY_DEPLOYMENT_NAME}; done
        else
            echo "No Quay deployment found"
            exit 1
        fi

        # This assumes that there are no DDL statements running on the database
        # backup quay postgresql database
        local QUAY_DB_DEPLOYMENT=$(oc -n ${quay_namespace} get deployment --selector=service-name=${quay_pgclustername} --no-headers=true -o=custom-columns=NAME:.metadata.name 2>/dev/null || true)
        local QUAY_DB_POD=$(oc -n ${QUAY_NAMESPACE} get pods -l service-name=${quay_pgclustername} --no-headers=true -o=custom-columns=NAME:.metadata.name 2>/dev/null || true)
        mkdir -p ${backup_dir}

        if [ "${QUAY_DB_DEPLOYMENT}" != "" ] && [ "${QUAY_DB_POD}" != "" ]; then
            oc -n ${quay_namespace} exec ${QUAY_DB_POD} -c database -- /bin/bash -c "/usr/pgsql-11/bin/pg_dumpall --globals-only > /pgdata/${QUAY_DB_DEPLOYMENT}/quaydb_global.sql"
            oc -n ${quay_namespace} exec ${QUAY_DB_POD} -c database -- /bin/bash -c "/usr/pgsql-11/bin/pg_dump -Fc -b \"${QUAY_POSTGRESQL_DATABASE}\" --lock-wait-timeout=5000 > /pgdata/${QUAY_DB_DEPLOYMENT}/quaydb.dump"
            oc -n ${quay_namespace} cp ${QUAY_DB_POD}:/pgdata/${QUAY_DB_DEPLOYMENT}/quaydb_global.sql ${backup_dir}/quaydb_global.sql -c database
            oc -n ${quay_namespace} cp ${QUAY_DB_POD}:/pgdata/${QUAY_DB_DEPLOYMENT}/quaydb.dump ${backup_dir}/quaydb.dump -c database
            oc -n ${quay_namespace} exec ${QUAY_DB_POD} -c database -- /bin/bash -c "rm -rf /pgdata/${QUAY_DB_DEPLOYMENT}/quaydb_global.sql"
            oc -n ${quay_namespace} exec ${QUAY_DB_POD} -c database -- /bin/bash -c "rm -rf /pgdata/${QUAY_DB_DEPLOYMENT}/quaydb.dump"
    fi
    else
        echo "Nothing to do here, have a great day :-)"
        exit
    fi
}

function install_quay() {
    local overrides=${1:-}

    # https://stackoverflow.com/a/43709191
    # https://stackoverflow.com/a/43708054
    # https://kvz.io/blog/2013/11/21/bash-best-practices/
    # http://www.gnu.org/savannah-checkouts/gnu/bash/manual/bash.html#Shell-Parameter-Expansion
    # https://linuxhint.com/bash_export_command/

    if [[ "${overrides}x" != "x"  && -f ${overrides} ]]; then
        set -a
        source ${overrides}
        set +a
    fi

    ## Deleting namespace stuck at "Terminating" state
    ## https://github.com/kubernetes/kubernetes/issues/60807#issuecomment-497542245
    #export QUAY_NAMESPACE='quay-enterprise'
    #kubectl proxy &>/dev/null &
    #PROXY_PID=$!
    #kubectl get namespace "$QUAY_NAMESPACE" -o json | jq 'del(.spec.finalizers[] | select("kubernetes"))' | curl -s -k -H "Content-Type: application/json" -X PUT -o /dev/null --data-binary @- http://localhost:8001/api/v1/namespaces/$QUAY_NAMESPACE/finalize && echo "Killed namespace: $QUAY_NAMESPACE"
    #kill $PROXY_PID
    #oc delete namespace $QUAY_NAMESPACE

    #export HOST_SHARE_PATH='/home/vagrant/share'
    #source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh
    #install_quay

    #export CERT_PATH='/home/vagrant/cfssl'

    # BUG SEE: https://access.redhat.com/solutions/4083831

    # REFS:
    #   https://github.com/siamaksade/ansible-openshift-quay
    #   https://github.com/epe105/devsecops-workshop/tree/master/scripts/quay
    #   https://github.com/sapcc/helm-charts/tree/master/global/quay

    # QUAY:
    #   [Accessing Red Hat Quay (formerly Quay Enterprise) without a CoreOS login](https://access.redhat.com/solutions/3533201)
    #   [Migrate from LocalStorage to object storage](https://access.redhat.com/solutions/3892551)
    #   [Monitoring Quay with Prometheus and Grafana](https://access.redhat.com/solutions/3750281)
    #   [Red Hat Quay Log Debugging](https://access.redhat.com/solutions/3663691)
    #   [Back up and Restore Quay Enterprise](https://access.redhat.com/solutions/3498981)
    #   [Quay Enterprise: Public Namespaces](https://access.redhat.com/solutions/3563291)
    #   [How to deploy the Quay registry in the OpenShift Container Platform?](https://access.redhat.com/solutions/3625141)
    #   [Quay Enterprise 3.x Tested Integrations](https://access.redhat.com/articles/4067991)
    #   [Reroute Quay Enterprise logging for FluentD](https://access.redhat.com/solutions/3544061)
    #   [Quay database connection pooling](https://access.redhat.com/solutions/3911651)
    #   [Quay Enterprise additional configuration options](https://access.redhat.com/articles/3998301)

    export QUAY_NAMESPACE='quay-enterprise'

    export CERTIFICATE_DIR="${CERTIFICATE_DIR:=/home/vagrant/share/envs/certs}"

    export FEATURE_MINIO_ENABLED="${FEATURE_MINIO_ENABLED:=true}"
    export FEATURE_CLAIR_ENABLED="${FEATURE_CLAIR_ENABLED:=true}"
    export FEATURE_CRUNCHY_OPERATOR_ENABLED="${FEATURE_CRUNCHY_OPERATOR_ENABLED:=false}"

    export DEFAULT_ROUTE_SUFFIX="${DEFAULT_ROUTE_SUFFIX:=app.oc.local}"

    export GEN_MINIO_CERTS=${GEN_MINIO_CERTS:=true}
    export MINIO_PULL_USER=${MINIO_PULL_USER?}
    export MINIO_PULL_TOKEN=${MINIO_PULL_TOKEN?}
    export MINIO_ACCESS_KEY=${MINIO_ACCESS_KEY?}
    export MINIO_SECRET_KEY=${MINIO_SECRET_KEY?}
    export MINIO_PULL_SECRET='minio-pull-secret'
    export MINIO_K8S_NAME='minio'
    export MINIO_NAMESPACE=${QUAY_NAMESPACE}
    export MINIO_SERVICE_ACCOUNT=${MINIO_SERVICE_ACCOUNT:='minio'}
    export MINIO_IMAGE="${MINIO_IMAGE:=files.caas.ford.com/minio/minio:RELEASE.2019-09-05T23-24-38Z}"
    #export MINIO_STORAGECLASS='rook-ceph-block-replicated'
    export MINIO_STORAGECLASS="${MINIO_STORAGECLASS:=nfs}"
    export MINIO_STORAGE_ACCESSMODE="${MINIO_STORAGE_ACCESSMODE:=ReadWriteMany}"
    export MINIO_STORAGE_SIZE="${MINIO_STORAGE_SIZE:=5Gi}"
    export MINIO_HOSTNAME="${MINIO_HOSTNAME:=minio.${DEFAULT_ROUTE_SUFFIX}}"
    export MINIO_RESOURCES_REQUESTS_CPU="${MINIO_RESOURCES_REQUESTS_CPU:=100m}"
    export MINIO_RESOURCES_REQUESTS_MEMORY="${MINIO_RESOURCES_REQUESTS_MEMORY:=100Mi}"
    export MINIO_RESOURCES_LIMITS_CPU="${MINIO_RESOURCES_LIMITS_CPU:=750m}"
    export MINIO_RESOURCES_LIMITS_MEMORY="${MINIO_RESOURCES_LIMITS_MEMORY:=750Mi}"

    export GEN_DEX_CERTS=${GEN_DEX_CERTS:=true}
    export DEX_LDAP_BIND_PASSWORD=${DEX_LDAP_BIND_PASSWORD?}
    export DEX_LDAP_GID=${DEX_LDAP_GID?}
    export DEX_LDAP_ROOTCA_CERT=${DEX_LDAP_ROOTCA_CERT?}
    export QUAY_PULL_USER=${QUAY_PULL_USER?}
    export QUAY_PULL_TOKEN=${QUAY_PULL_TOKEN?}
    export DEX_TLS_SECRET="${DEX_TLS_SECRET:=dex-tls-secret}"
    export DEX_K8S_NAME='dex'
    export DEX_SERVICE_ACCOUNT="${DEX_SERVICE_ACCOUNT:=dex}"
    export DEX_HOSTNAME="${DEX_HOSTNAME:=dex.${DEFAULT_ROUTE_SUFFIX}}"
    export DEX_LDAP_SERVER='fds.ford.com:636'
    export DEX_IMAGE="${DEX_IMAGE:=files.caas.ford.com/quay/dex:v2.19.0}"
    export DEX_REPLICA_COUNT="${DEX_REPLICA_COUNT:=1}"
    export DEX_RESOURCES_REQUESTS_CPU="${DEX_RESOURCES_REQUESTS_CPU:=100m}"
    export DEX_RESOURCES_REQUESTS_MEMORY="${DEX_RESOURCES_REQUESTS_MEMORY:=100Mi}"
    export DEX_RESOURCES_LIMITS_CPU="${DEX_RESOURCES_LIMITS_CPU:=200m}"
    export DEX_RESOURCES_LIMITS_MEMORY="${DEX_RESOURCES_LIMITS_MEMORY:=500Mi}"

    export QUAY_POSTGRESQL_DATABASE=${QUAY_POSTGRESQL_DATABASE?}
    export QUAY_POSTGRESQL_USER=${QUAY_POSTGRESQL_USER?}
    export QUAY_POSTGRESQL_PASSWORD=${QUAY_POSTGRESQL_PASSWORD?}

    export QUAY_REDIS_PASSWORD=${QUAY_REDIS_PASSWORD?}
    export QUAY_REDIS_K8S_NAME='quay-redis'
    export QUAY_REDIS_SERVICE_ACCOUNT="${QUAY_REDIS_SERVICE_ACCOUNT:=quay-redis}"
    #export QUAY_REDIS_IMAGE='registry.redhat.io/rhscl/redis-32-rhel7:3.2-38'
    export QUAY_REDIS_IMAGE="${QUAY_REDIS_IMAGE:=registry.redhat.io/rhel8/redis-5:1-25}"
    #export QUAY_REDIS_STORAGECLASS='rook-ceph-block-replicated'
    export QUAY_REDIS_STORAGECLASS="${QUAY_REDIS_STORAGECLASS:=nfs}"
    export QUAY_REDIS_STORAGE_ACCESSMODE="${QUAY_REDIS_STORAGE_ACCESSMODE:=ReadWriteMany}"
    export QUAY_REDIS_STORAGE_SIZE="${QUAY_REDIS_STORAGE_SIZE:=2Gi}"
    export QUAY_REDIS_RESOURCES_REQUESTS_CPU="${QUAY_REDIS_RESOURCES_REQUESTS_CPU:=100m}"
    export QUAY_REDIS_RESOURCES_REQUESTS_MEMORY="${QUAY_REDIS_RESOURCES_REQUESTS_MEMORY:=100Mi}"
    export QUAY_REDIS_RESOURCES_LIMITS_CPU="${QUAY_REDIS_RESOURCES_LIMITS_CPU:=750m}"
    export QUAY_REDIS_RESOURCES_LIMITS_MEMORY="${QUAY_REDIS_RESOURCES_LIMITS_MEMORY:=750Mi}"

    export GEN_QUAY_CERTS=${GEN_QUAY_CERTS:=true}
    export QUAY_PULL_USER=${QUAY_PULL_USER?}
    export QUAY_PULL_TOKEN=${QUAY_PULL_TOKEN?}
    #export GITHUB_LOGIN_CLIENT_ID=${GITHUB_LOGIN_CLIENT_ID?}
    #export GITHUB_LOGIN_CLIENT_SECRET=${GITHUB_LOGIN_CLIENT_SECRET?}
    #export GITHUB_LOGIN_ENDPOINT=${GITHUB_LOGIN_ENDPOINT?}
    export QUAY_SUPER_USERS=${QUAY_SUPER_USERS?}
    export QUAY_PULL_SECRET='quay-pull-secret'
    export QUAY_K8S_NAME='quay-enterprise'
    export QUAY_SERVICE_ACCOUNT="${QUAY_SERVICE_ACCOUNT:=quay}"
    export QUAY_SETUP="${QUAY_SETUP:=false}"
    export QUAY_SETUP_PASSWORD=${QUAY_SETUP_PASSWORD?}
    export QUAY_NSEXPORTS_DIR=${QUAY_NSEXPORTS_DIR:=-}
    export QUAY_REPLICA_COUNT=${QUAY_REPLICA_COUNT:=1}
    export QUAY_IMAGE="${QUAY_IMAGE:=files.caas.ford.com/quay/quay:v3.0.5}"
    #export QUAY_STORAGECLASS='rook-ceph-block-replicated'
    export QUAY_STORAGECLASS="${QUAY_STORAGECLASS:=nfs}"
    export QUAY_STORAGE_ACCESSMODE="${QUAY_STORAGE_ACCESSMODE:=ReadWriteMany}"
    export QUAY_STORAGE_SIZE="${QUAY_STORAGE_SIZE:=2Gi}"
    export QUAY_RESOURCES_REQUESTS_CPU="${QUAY_RESOURCES_REQUESTS_CPU:=1000m}"
    export QUAY_RESOURCES_REQUESTS_MEMORY="${QUAY_RESOURCES_REQUESTS_MEMORY:=800Mi}"
    export QUAY_RESOURCES_LIMITS_CPU="${QUAY_RESOURCES_LIMITS_CPU:=2000m}"
    export QUAY_RESOURCES_LIMITS_MEMORY="${QUAY_RESOURCES_LIMITS_MEMORY:=4Gi}"
    export QUAY_DATABASE_BACKUP="${QUAY_DATABASE_BACKUP:=/home/vagrant/share/templates/quay/quay/quaydb_seed.tar}"
    export QUAY_DB_URI="${QUAY_DB_URI:=postgresql://${QUAY_POSTGRESQL_USER}:${QUAY_POSTGRESQL_PASSWORD}@${QUAY_POSTGRESQL_K8S_NAME}.${QUAY_NAMESPACE}.svc/${QUAY_POSTGRESQL_DATABASE}}"
    export QUAY_REDIS_HOST="${QUAY_REDIS_HOST:=${QUAY_REDIS_K8S_NAME}.${QUAY_NAMESPACE}.svc}"
    export QUAY_REDIS_PORT="6379"
    export QUAY_REDIS_PASSWORD="${QUAY_REDIS_PASSWORD}"
    export QUAY_OIDC_SERVER="https://${DEX_HOSTNAME}"
    export QUAY_S3_HOST="${QUAY_S3_HOST:=${MINIO_HOSTNAME}}"
    export QUAY_S3_PORT="${QUAY_S3_PORT:=443}"
    export QUAY_S3_VERSION="${QUAY_S3_VERSION:=4}" # Use S3v2 for ECS
    export QUAY_S3_ACCESS_KEY="${QUAY_S3_ACCESS_KEY:=${MINIO_ACCESS_KEY}}"
    export QUAY_S3_SECRET_KEY="${QUAY_S3_SECRET_KEY:=${MINIO_SECRET_KEY}}"
    export QUAY_HOSTNAME="${QUAY_HOSTNAME:=registry.${DEFAULT_ROUTE_SUFFIX}}"
    export QUAY_MIRROR_HOSTANAME="${REPO_MIRROR_SVC_URL:=http://${QUAY_K8S_NAME}-mirror.${QUAY_NAMESPACE}.svc:8443}"
    export QUAY_CLAIR_HOSTNAME="${QUAY_CLAIR_HOSTNAME:=clair.${DEFAULT_ROUTE_SUFFIX}}"
    export QUAY_MAIL_SERVER="${QUAY_MAIL_SERVER:=apprl.azell.com}"
    export QUAY_MAIL_PORT="${QUAY_MAIL_PORT:=25}"
    export QUAY_MAIL_DEFAULT_SENDER="${QUAY_MAIL_DEFAULT_SENDER:=quayadm@ford.com}"

    ## Quay DOCS:
    ##  https://access.redhat.com/documentation/en-us/red_hat_quay/2.9/
    ##  [How to deploy the Quay registry in the OpenShift Container Platform](https://access.redhat.com/solutions/3625141)

    # Create quay namespace if missing
    if ! oc get project | grep -q ${QUAY_NAMESPACE}; then
        oc new-project ${QUAY_NAMESPACE}
    fi

    ## https://github.com/openshift/installer/blob/master/data/data/bootstrap/files/usr/local/bin/installer-gather.sh
    ## https://github.com/openshift/installer/blob/master/data/data/bootstrap/files/usr/local/bin/report-progress.sh
    #NS=$(oc get project | grep ${QUAY_NAMESPACE} | cat)
    #if [ ! "${NS}" ]; then
    #    oc new-project ${QUAY_NAMESPACE}
    #}

    if [ "${FEATURE_MINIO_ENABLED}" = "true" ]; then
        ## Install minio to provide object storage backend
        ## --------------------------------------------------------
        ## DOCS:
        ##  https://docs.min.io/docs/how-to-secure-access-to-minio-server-with-tls.html#using-go
        ##  https://developers.redhat.com/blog/2017/01/24/end-to-end-encryption-with-openshift-part-1-two-way-ssl/
        # Create minio service account if missing
        if ! oc get serviceaccounts -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${MINIO_SERVICE_ACCOUNT}$"; then
            oc create serviceaccount ${MINIO_SERVICE_ACCOUNT} -n ${QUAY_NAMESPACE} || true
        fi

        ## Create minio pull secret if missing
        if ! oc get secrets -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${MINIO_PULL_SECRET}$"; then
            ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
            oc create secret docker-registry ${MINIO_PULL_SECRET} \
            --docker-username="${MINIO_PULL_USER}" \
            --docker-password="${MINIO_PULL_TOKEN}" \
            --docker-email=caassup@ford.com \
            --docker-server=$(echo ${MINIO_IMAGE} | cut -d/ -f1) \
            --namespace=${QUAY_NAMESPACE}

            ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
            ## https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/
            oc secrets link ${MINIO_SERVICE_ACCOUNT} ${MINIO_PULL_SECRET} --for=pull --namespace=${QUAY_NAMESPACE} || true
        fi

        if [ "${GEN_MINIO_CERTS}" = "true" ]; then
            minio_cn=${MINIO_HOSTNAME}
            minio_san="${MINIO_K8S_NAME}.${QUAY_NAMESPACE}.svc.cluster.local,${MINIO_K8S_NAME}.${QUAY_NAMESPACE}.svc"
            minio_ip=''
            create_certs ${CERTIFICATE_DIR} ${minio_cn} ${minio_san} ${minio_ip}
        fi

        if [ ! -f ${CERTIFICATE_DIR}/certs/${MINIO_HOSTNAME}/${MINIO_HOSTNAME}.bundle.pem ]; then
            cat ${CERTIFICATE_DIR}/certs/${MINIO_HOSTNAME}/${MINIO_HOSTNAME}.pem ${CERTIFICATE_DIR}/ca/ca.pem > \
                ${CERTIFICATE_DIR}/certs/${MINIO_HOSTNAME}/${MINIO_HOSTNAME}.bundle.pem
        fi

        if ! oc -n ${QUAY_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^minio-tls-certs$"; then
            oc create secret generic minio-tls-certs \
                --from-file=tls.crt=${CERTIFICATE_DIR}/certs/${MINIO_HOSTNAME}/${MINIO_HOSTNAME}.bundle.pem \
                --from-file=tls.key=${CERTIFICATE_DIR}/certs/${MINIO_HOSTNAME}/${MINIO_HOSTNAME}.key \
                --type=kubernetes.io/tls -o json --dry-run | oc -n ${MINIO_NAMESPACE} apply -f -
        fi

        if ! oc get services -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${MINIO_NAMESPACE} | grep -q minio-service; then
            envsubst < ${HOST_SHARE_PATH}/templates/quay/minio/minio-distributed-service.yaml | oc apply -f -
        fi

        if ! oc get pdb -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${MINIO_NAMESPACE} | grep -qE "^${MINIO_K8S_NAME}$"; then
            envsubst < ${HOST_SHARE_PATH}/templates/quay/minio/minio-distributed-pdb.yaml | oc apply -f -
        fi

        if ! oc get routes -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${MINIO_NAMESPACE} | grep -qE "^${MINIO_K8S_NAME}$"; then
            envsubst < ${HOST_SHARE_PATH}/templates/quay/minio/minio-distributed-route.yaml | oc apply -f -
        fi

        if ! oc get persistentvolumeclaims -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${MINIO_K8S_NAME}$"; then
            envsubst < ${HOST_SHARE_PATH}/templates/quay/minio/minio-standalone-pvc.yaml | oc apply -f -
        fi

        if ! oc get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${MINIO_NAMESPACE} | grep -qE "^${MINIO_K8S_NAME}$"; then
            ## https://docs.min.io/docs/deploy-minio-on-kubernetes.html
            ## https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/
            envsubst < ${HOST_SHARE_PATH}/templates/quay/minio/minio-standalone-deployment.yaml | oc apply -f -
            #until [[ $(oc -n ${MINIO_NAMESPACE} get deployments ${MINIO_K8S_NAME} -o=custom-columns=READYREPLICAS:.status.readyReplicas --no-headers=true 2>/dev/null) -eq 1 ]]; do
            #    echo "waiting from minio deployment ...."
            #    sleep 1
            #done
            wait_for_objects ${QUAY_NAMESPACE} ${MINIO_K8S_NAME}
            wait_for_objects quay-enterprise minio
        fi

        # Check if minio server is online
        check_endpoint "https://${MINIO_HOSTNAME}/minio/health/ready"
    fi

    ## Install Dex authentication proxy
    ## --------------------------------------------------------
    # Generate self-signed certificates for dex

    ## https://uptoknow.github.io/post/openshift-with-coreos-dex-openid-provider/ (OpenShift with CoreOS Dex Openid Provider)
    ## https://access.redhat.com/solutions/3469681 (Deploy Dex on Openshift)
    ## https://access.redhat.com/solutions/3482251 (Configure Dex as an OIDC provider for OpenShift)

    if [ "${GEN_DEX_CERTS}" = "true" ]; then
        local dex_cn=${DEX_HOSTNAME}
        local dex_san="${DEX_K8S_NAME}.${QUAY_NAMESPACE}.svc.cluster.local,${DEX_K8S_NAME}.${QUAY_NAMESPACE}.svc"
        local dex_ip=''
        create_certs ${CERTIFICATE_DIR} ${dex_cn} ${dex_san} ${dex_ip}
    fi

    if [ ! -f ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.bundle.pem ]; then
        cat ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.pem ${CERTIFICATE_DIR}/ca/ca.pem > \
            ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.bundle.pem
    fi

    if [ "${GEN_DEX_CERTS}" = "false" ]; then
        current_dex_secret="${QUAY_NSEXPORTS_DIR}/${QUAY_NAMESPACE}/Secret.dex-tls.yaml"
        if [ -f ${current_dex_secret} ]; then
            yq read ${current_dex_secret} 'data.[tls.crt]' | \
                base64 --decode > \
                ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.bundle.pem

            yq read ${current_dex_secret} 'data.[tls.key]' | \
                base64 --decode > \
                ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.key
        fi
    fi

    if [ ! -f ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.bundle.pem ] || [ ! -f ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.key ]; then
        echo "ERROR: Missing Dex certificates in ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}"
        exit
    fi

    if ! oc -n ${QUAY_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${DEX_TLS_SECRET}$"; then
        oc -n ${QUAY_NAMESPACE} create secret tls ${DEX_TLS_SECRET} \
            --key ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.key \
            --cert ${CERTIFICATE_DIR}/certs/${DEX_HOSTNAME}/${DEX_HOSTNAME}.bundle.pem
    fi

    if ! oc -n ${QUAY_NAMESPACE} get serviceaccounts -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${DEX_SERVICE_ACCOUNT}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/dex/dex-serviceaccout.yaml | oc create -f -
    fi

    ## Create quay pull secret if missing
    if ! oc -n ${QUAY_NAMESPACE} get secrets -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_PULL_SECRET}$"; then
        ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
        oc create secret docker-registry ${QUAY_PULL_SECRET} \
        --docker-username="${QUAY_PULL_USER}" \
        --docker-password="${QUAY_PULL_TOKEN}" \
        --docker-email=caassup@ford.com \
        --docker-server=$(echo ${DEX_IMAGE} | cut -d/ -f1) \
        --namespace=${QUAY_NAMESPACE}
    fi

    ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
    ## https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/
    oc secrets link ${DEX_SERVICE_ACCOUNT} ${QUAY_PULL_SECRET} --for=pull --namespace=${QUAY_NAMESPACE}

    # https://github.com/danielorf/gangwaydexdemo/blob/master/configs/dex.yaml
    # https://github.com/conorfennell/optimizer-k8s/blob/master/charts/argocd/templates/deployments.yaml
    # https://github.com/ObjectifLibre/kube-oidc
    # https://github.com/AmadeusITGroup/kanary/blob/master/examples/multi-kanary/demo.sh

    if ! oc -n ${QUAY_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${DEX_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/dex/dex-configmap.yaml | oc create -f -
    fi

    if ! oc get clusterroles -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${DEX_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/dex/dex-clusterrole.yaml | oc create -f -
    fi

    if ! oc get clusterrolebindings -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${DEX_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/dex/dex-clusterrolebinding.yaml | oc create -f -
    fi

    if ! oc get services -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${DEX_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/dex/dex-service.yaml | oc create -f -
    fi

    if ! oc get routes -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${DEX_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/dex/dex-route.yaml | oc create -f -
    fi

    if ! oc -n ${QUAY_NAMESPACE} get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${DEX_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/dex/dex-deployment.yaml | oc create -f -
        wait_for_objects ${QUAY_NAMESPACE} ${DEX_K8S_NAME}
    fi

    # Check if dex server is online
    check_endpoint "https://${DEX_HOSTNAME}/.well-known/openid-configuration"

    install_crunchydata
    create_crunchydb_instance ${QUAY_NAMESPACE} ${QUAY_PGCLUSTER_NAME} ${QUAYDB_PGBACKREST_FULL_SCHEDULE} ${QUAYDB_PGBACKREST_INCR_SCHEDULE}


    ## Install redis for Quay
    ## --------------------------------------------------------
    if ! oc -n ${QUAY_NAMESPACE} get serviceaccounts -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_REDIS_SERVICE_ACCOUNT}$"; then
        oc create serviceaccount ${QUAY_REDIS_SERVICE_ACCOUNT} -n ${QUAY_NAMESPACE}
    fi

    if ! oc get persistentvolumeclaims -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${QUAY_REDIS_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-redis-pvc.yaml | oc create -f -
    fi

    if ! oc get services -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${QUAY_REDIS_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-redis.service.yaml | oc create -f -
    fi

    if ! oc -n ${QUAY_NAMESPACE} get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_REDIS_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-redis-deployment.yaml | oc create -f -
        wait_for_objects ${QUAY_NAMESPACE} ${QUAY_REDIS_K8S_NAME}
    fi


    ## Install Quay
    ## --------------------------------------------------------

    # See: https://github.com/coreos/docs/tree/master/quay-enterprise/tectonic/files
    # See: https://access.redhat.com/documentation/en-us/red_hat_quay/2.9/html/deploy_red_hat_quay_on_openshift/set_up_red_hat_quay_services

    # Grant anyuid SCC to quay service since Quay runs only as root
    #oc adm policy add-scc-to-user anyuid -n ${QUAY_NAMESPACE} -z ${QUAY_SERVICE_ACCOUNT}
    oc adm policy add-scc-to-user anyuid -n ${QUAY_NAMESPACE} -z default

    if ! oc get serviceaccounts -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${QUAY_SERVICE_ACCOUNT}$"; then
        oc create serviceaccount ${QUAY_SERVICE_ACCOUNT} -n ${QUAY_NAMESPACE}
    fi

    ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
    ## https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/
    oc secrets link ${QUAY_SERVICE_ACCOUNT} ${QUAY_PULL_SECRET} --for=pull --namespace=${QUAY_NAMESPACE}
    oc secrets link default ${QUAY_PULL_SECRET} --for=pull --namespace=${QUAY_NAMESPACE}

    if ! oc get roles -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${QUAY_K8S_NAME}-serviceaccount$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-servicetoken-role.yaml | oc create -f -
    fi

    if ! oc get clusterrolebindings -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${QUAY_K8S_NAME}-secret-writer$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-servicetoken-role-binding.yaml | oc create -f -
    fi

    if ! oc get persistentvolumeclaims -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^log-${QUAY_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-logvol-pvc.yaml | oc create -f -
    fi

    # See: https://access.redhat.com/solutions/3496181
    # See: https://access.redhat.com/solutions/3450102
    if ! oc -n ${QUAY_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_K8S_NAME}-cert-secret$"; then
        oc -n ${QUAY_NAMESPACE} create secret generic ${QUAY_K8S_NAME}-cert-secret --from-file=ca.pem=${CERTIFICATE_DIR}/ca/ca.pem
    fi


    if [ "${GEN_QUAY_CERTS}" = "true" ]; then
        local quay_cn=${QUAY_HOSTNAME}
        local quay_san="${QUAY_K8S_NAME}.${QUAY_NAMESPACE}.svc.cluster.local,${QUAY_K8S_NAME}.${QUAY_NAMESPACE}.svc"
        local quay_ip=''
        create_certs ${CERTIFICATE_DIR} ${quay_cn} ${quay_san} ${quay_ip}
    fi

    if [ ! -f ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.bundle.pem ]; then
        cat ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.pem ${CERTIFICATE_DIR}/ca/ca.pem > \
            ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.bundle.pem
    fi

    if [ "${GEN_QUAY_CERTS}" = "false" ]; then
        current_quay_secret="${QUAY_NSEXPORTS_DIR}/${QUAY_NAMESPACE}/Secret.quay-enterprise-config-secret.yaml"
        if [ -f ${current_quay_secret} ]; then
            yq read ${current_quay_secret} 'data.[ssl.cert]' | \
                base64 --decode > \
                ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.bundle.pem

            yq read ${current_quay_secret} 'data.[ssl.key]' | \
                base64 --decode > \
                ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.key
        fi
    fi

    if [ ! -f ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.bundle.pem ] || [ ! -f ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.key ]; then
        echo "ERROR: Missing Quay certificates in ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}"
        exit
    fi

    # Enable the PostgreSQL database extensions
    QUAY_DBPOD=$(oc -n ${QUAY_NAMESPACE} get pods -l service-name=${QUAY_PGCLUSTER_NAME} --no-headers=true -o=custom-columns=NAME:.metadata.name)
    ##DBPOD=$(oc get pods -l pg-cluster=quay-db -l name=quay-db -n quay-enterprise --no-headers=true -o=custom-columns=NAME:.metadata.name)
    if [ "x${QUAY_DBPOD}" = "x" ]; then
        echo "unable to get postgresql pod name"
        exit 1
    fi

    # Create s3 bucket
    if [ "${FEATURE_MINIO_ENABLED}" = "true"]; then
        rm -rf ~/.mc/config.json
        mc config host add s3 https://${QUAY_S3_HOST}:${QUAY_S3_PORT} ${QUAY_S3_ACCESS_KEY} ${QUAY_S3_SECRET_KEY} --api "S3v${QUAY_S3_VERSION}"
        mc mb --insecure s3/quay/datastorage/registry/ || true
    fi

    ## IMPORTANT NOTE: THIS IS ONLY REQUIRED TO RUN QUAY CONFIG APP
    if [ "${QUAY_SETUP}" = "true" ]; then

        # Configure PostgreSQL database
        oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "echo \"CREATE USER \"${QUAY_POSTGRESQL_USER}\" WITH SUPERUSER;\" | /usr/pgsql-11/bin/psql -U postgres -d postgres"
        oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "echo \"ALTER USER \"${QUAY_POSTGRESQL_USER}\" WITH password '${QUAY_POSTGRESQL_PASSWORD}';\" | /usr/pgsql-11/bin/psql"
        oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "echo \"CREATE DATABASE \"${QUAY_POSTGRESQL_DATABASE}\" OWNER \"${QUAY_POSTGRESQL_USER}\";\" | /usr/pgsql-11/bin/psql"
        oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c 'echo "SELECT * FROM pg_available_extensions;" | /usr/pgsql-11/bin/psql'
        oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -d \"${QUAY_POSTGRESQL_DATABASE}\" -c \"CREATE EXTENSION IF NOT EXISTS pg_trgm;\""
        oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -d \"${QUAY_POSTGRESQL_DATABASE}\" -c \"SELECT * FROM pg_extension;"\"
        oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -d \"${QUAY_POSTGRESQL_DATABASE}\" -c \"CREATE EXTENSION IF NOT EXISTS pg_trgm;\""

        if ! oc get services -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${QUAY_K8S_NAME}-config$"; then
            envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-config-service.yaml | oc create -f -
        fi

        if ! oc get routes -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE '^${QUAY_K8S_NAME}-config$'; then
            envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-config-route.yaml | oc create -f -
        fi

        if ! oc -n ${QUAY_NAMESPACE} get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_K8S_NAME}-config$"; then
            envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-config.yaml | oc create -f -
            wait_for_objects ${QUAY_NAMESPACE} ${QUAY_K8S_NAME}-config
        fi

        echo "To complete setup open https://${QUAY_HOSTNAME} and login as:"
        echo "  Username: quayconfig"
        echo "  Password: ${QUAY_SETUP_PASSWORD}"
        echo ""
        echo "Docs: https://access.redhat.com/documentation/en-us/red_hat_quay/3/html/deploy_red_hat_quay_on_openshift/set_up_red_hat_quay_services"
        return
    fi

    # Restore database
    if ! oc -n ${QUAY_NAMESPACE} get configmap -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^install-db-config$"; then
        DEPLOYMENT=$(oc -n ${QUAY_NAMESPACE} get deployment --selector=service-name=${QUAY_PGCLUSTER_NAME} --no-headers=true -o=custom-columns=NAME:.metadata.name 2> /dev/null || true)
        QUAY_DBPOD=$(oc -n ${QUAY_NAMESPACE} get pods -l service-name=${QUAY_PGCLUSTER_NAME} --no-headers=true -o=custom-columns=NAME:.metadata.name 2> /dev/null || true)
        if [[ ! -z ${DEPLOYMENT} && ! -z ${QUAY_DBPOD} && -f "${QUAY_DB_BACKUPDIR}/quaydb_global.sql" && -f "${QUAY_DB_BACKUPDIR}/quaydb.dump" ]]; then
            oc -n ${QUAY_NAMESPACE} cp ${QUAY_DB_BACKUPDIR}/quaydb.dump ${QUAY_DBPOD}:/pgdata/${DEPLOYMENT}/quaydb.dump -c database
            oc -n ${QUAY_NAMESPACE} cp ${QUAY_DB_BACKUPDIR}/quaydb_global.sql ${QUAY_DBPOD}:/pgdata/${DEPLOYMENT}/quaydb_global.sql -c database
            oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "cat /pgdata/${DEPLOYMENT}/quaydb_global.sql | grep -v \"\(postgres\|primaryuser\|ccp_monitoring\|testuser\)\" > /pgdata/${DEPLOYMENT}/quaydb_global_clean.sql"
            oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -f /pgdata/${DEPLOYMENT}/quaydb_global_clean.sql"
            oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/pg_restore --format=custom --create --verbose /pgdata/${DEPLOYMENT}/quaydb.dump | /usr/pgsql-11/bin/psql -U postgres"
            # TODO:
            #oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -f <FILE-NAME>"
            oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "rm -rf /pgdata/${DEPLOYMENT}/quaydb_global.sql /pgdata/${DEPLOYMENT}/quaydb_global_clean.sql /pgdata/${DEPLOYMENT}/quaydb.dump"
            if [[ ! $QUAY_HOSTNAME =~ *.app.oc.local$ && "${EXISTING_QUAY_POSTGRESQL_USER}" != "" && "${EXISTING_QUAY_POSTGRESQL_DATABASE}" != "" ]]; then
                oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "echo \"ALTER USER \"${QUAY_POSTGRESQL_USER}\" RENAME TO '${NEW-USER-NAME}';\" | /usr/pgsql-11/bin/psql"
                oc -n ${QUAY_NAMESPACE} exec ${QUAY_DBPOD} --container database -- /bin/bash -c "echo \"ALTER DATABASE \"${OLD-DATABASE-NAME}\" RENAME TO \"${NEW-DATABASE-NAME}\";\" | /usr/pgsql-11/bin/psql"
            fi
        fi
        ## Update the sentinel, indicating the database has been restored
        oc -n ${QUAY_NAMESPACE} create configmap install-db-config --from-literal=db.restorestatus=complete --from-literal=db.version=4.0.1
    fi



    if ! oc -n ${QUAY_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_K8S_NAME}-config-secret$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-configmap.yaml > /tmp/quay-enterprise-config.yaml
        oc -n ${QUAY_NAMESPACE} create secret generic ${QUAY_K8S_NAME}-config-secret \
            --from-file=ssl.cert=${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.bundle.pem \
            --from-file=ssl.key=${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}/${QUAY_HOSTNAME}.key \
            --from-file=config.yaml=/tmp/quay-enterprise-config.yaml
        rm -rf /tmp/quay-enterprise-config.yaml
    fi

    if ! oc get services -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${QUAY_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-service.yaml | oc create -f -
    fi

    if ! oc get routes -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE '^${QUAY_K8S_NAME}$'; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-route.yaml | oc create -f -
    fi

    ## DOCS: https://access.redhat.com/documentation/en-us/red_hat_quay/3/html-single/deploy_red_hat_quay_on_openshift/index#add-repo-mirroring
    #if ! oc -n ${QUAY_NAMESPACE} get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_K8S_NAME}-mirror-app$"; then
    #    envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-mirror.yaml | oc create -f -
    #    wait_for_objects ${QUAY_NAMESPACE} ${QUAY_K8S_NAME}-mirror
    #fi

    if ! oc -n ${QUAY_NAMESPACE} get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${QUAY_K8S_NAME}-app$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/quay/quay-enterprise-deployment.yaml | oc create -f -
        wait_for_objects ${QUAY_NAMESPACE} ${QUAY_K8S_NAME}
    fi
}

function install_clair() {
    local overrides=${1:-}

    ## DOCS:
    ##  https://access.redhat.com/documentation/en-us/red_hat_quay/3/html-single/manage_red_hat_quay/index#quay-security-scanner
    ##  https://registry.ford.com/superuser/?tab=servicekeys
    ##  https://registry.app.oc.local/superuser/?tab=servicekeys

    if [[ "${overrides}x" != "x"  && -f ${overrides} ]]; then
        set -a
        source ${overrides}
        set +a
    fi

    export CLAIR_PGCLUSTER_NAME=${CLAIR_PGCLUSTER_NAME?}
    export CLAIR_POSTGRESQL_DATABASE=${CLAIR_POSTGRESQL_DATABASE?}
    export CLAIR_POSTGRESQL_USER=${CLAIR_POSTGRESQL_USER?}
    export CLAIR_POSTGRESQL_PASSWORD=${CLAIR_POSTGRESQL_PASSWORD?}
    export CLAIRDB_PGBACKREST_FULL_SCHEDULE=${CLAIRDB_PGBACKREST_FULL_SCHEDULE?}
    export CLAIRDB_PGBACKREST_INCR_SCHEDULE=${CLAIRDB_PGBACKREST_INCR_SCHEDULE?}

    export CLAIR_SCANNER_KEY_ID=${CLAIR_SCANNER_KEY_ID?}
    export CLAIR_SCANNER_PEM=${CLAIR_SCANNER_PEM?}

    export GEN_CLAIR_CERTS=${GEN_CLAIR_CERTS:=true}
    export CLAIR_K8S_NAME='clair'
    export CLAIR_SERVICE_ACCOUNT="${CLAIR_SERVICE_ACCOUNT:=clair}"
    export CLAIR_HOSTNAME="${CLAIR_HOSTNAME:=clair.app.oc.local}"
    export CLAIR_IMAGE="${CLAIR_IMAGE:=files.caas.ford.com/quay/clair-jwt:v3.0.5}"
    export CLAIR_RESOURCES_REQUESTS_CPU="${CLAIR_RESOURCES_REQUESTS_CPU:=100m}"
    export CLAIR_RESOURCES_REQUESTS_MEMORY="${CLAIR_RESOURCES_REQUESTS_MEMORY:=100Mi}"
    export CLAIR_RESOURCES_LIMITS_CPU="${CLAIR_RESOURCES_LIMITS_CPU:=1000m}"
    export CLAIR_RESOURCES_LIMITS_MEMORY="${CLAIR_RESOURCES_LIMITS_MEMORY:=1Gi}"

    create_crunchydb_instance ${QUAY_NAMESPACE} ${CLAIR_PGCLUSTER_NAME} ${CLAIRDB_PGBACKREST_FULL_SCHEDULE} ${CLAIRDB_PGBACKREST_INCR_SCHEDULE}

    #until [ $(oc -n ${QUAY_NAMESPACE} get pods -l service-name=${CLAIR_PGCLUSTER_NAME} --no-headers=true -o=custom-columns=NAME:.metadata.name 2> /dev/null || true) != "" ] > /dev/null 2>&1; do echo "Waiting for Clair DB pod to come online"; sleep 1; done
    wait_for_objects ${QUAY_NAMESPACE} ${CLAIR_PGCLUSTER_NAME}

    # Configure PostgreSQL database
    CLAIR_DBPOD=$(oc -n ${QUAY_NAMESPACE} get pods -l service-name=${CLAIR_PGCLUSTER_NAME} --no-headers=true -o=custom-columns=NAME:.metadata.name)
    if [ "${CLAIR_DBPOD}" = "" ]; then
        echo "Clair DB pod not found"
        exit 1
    fi
    oc -n ${QUAY_NAMESPACE} exec ${CLAIR_DBPOD} --container database -- /bin/bash -c "echo \"CREATE USER \"${CLAIR_POSTGRESQL_USER}\" WITH SUPERUSER;\" | /usr/pgsql-11/bin/psql -U postgres -d postgres"
    oc -n ${QUAY_NAMESPACE} exec ${CLAIR_DBPOD} --container database -- /bin/bash -c "echo \"ALTER USER \"${CLAIR_POSTGRESQL_USER}\" WITH password '${CLAIR_POSTGRESQL_PASSWORD}';\" | /usr/pgsql-11/bin/psql"
    oc -n ${QUAY_NAMESPACE} exec ${CLAIR_DBPOD} --container database -- /bin/bash -c "echo \"CREATE DATABASE \"${CLAIR_POSTGRESQL_DATABASE}\" OWNER \"${CLAIR_POSTGRESQL_USER}\";\" | /usr/pgsql-11/bin/psql"
    oc -n ${QUAY_NAMESPACE} exec ${CLAIR_DBPOD} --container database -- /bin/bash -c 'echo "SELECT * FROM pg_available_extensions;" | /usr/pgsql-11/bin/psql'
    oc -n ${QUAY_NAMESPACE} exec ${CLAIR_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -d \"${CLAIR_POSTGRESQL_DATABASE}\" -c \"CREATE EXTENSION IF NOT EXISTS pg_trgm;\""
    oc -n ${QUAY_NAMESPACE} exec ${CLAIR_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -d \"${CLAIR_POSTGRESQL_DATABASE}\" -c \"SELECT * FROM pg_extension;"\"
    oc -n ${QUAY_NAMESPACE} exec ${CLAIR_DBPOD} --container database -- /bin/bash -c "/usr/pgsql-11/bin/psql -U postgres -d \"${CLAIR_POSTGRESQL_DATABASE}\" -c \"CREATE EXTENSION IF NOT EXISTS pg_trgm;\""

    # Generate clair certs
    if [ "${GEN_CLAIR_CERTS}" = "true" ]; then
        local clair_cn=${CLAIR_HOSTNAME}
        local clair_san="${CLAIR_K8S_NAME}.${QUAY_NAMESPACE}.svc.cluster.local,${CLAIR_K8S_NAME}.${QUAY_NAMESPACE}.svc"
        local clair_ip=''
        create_certs ${CERTIFICATE_DIR} ${clair_cn} ${clair_san} ${clair_ip}
    fi

    if [ ! -f ${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.bundle.pem ]; then
        cat ${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.pem ${CERTIFICATE_DIR}/ca/ca.pem > \
            ${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.bundle.pem
    fi

    if [ ! -f ${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.bundle.pem ] || [ ! -f ${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.key ]; then
        echo "ERROR: Missing Quay certificates in ${CERTIFICATE_DIR}/certs/${QUAY_HOSTNAME}"
        exit
    fi

    if ! oc -n ${QUAY_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${CLAIR_K8S_NAME}-ca-cert$"; then
        oc -n ${QUAY_NAMESPACE} create secret generic clair-ca-cert --from-file=ca.pem=${CERTIFICATE_DIR}/ca/ca.pem
    fi

    if ! oc -n ${QUAY_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^clair-app-cert$"; then
         oc -n ${QUAY_NAMESPACE} create secret generic clair-app-cert \
            --from-file=clair.crt=${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.bundle.pem \
            --from-file=clair.key=${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.key
    fi

    if ! oc -n ${QUAY_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${CLAIR_K8S_NAME}-config-secret$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/clair/clair-config.yaml > /tmp/clair-config.yaml
        oc -n ${QUAY_NAMESPACE} create secret generic ${CLAIR_K8S_NAME}-config-secret \
            --from-file=clair.crt=${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.bundle.pem \
            --from-file=clair.key=${CERTIFICATE_DIR}/certs/${CLAIR_HOSTNAME}/${CLAIR_HOSTNAME}.key \
            --from-file=security_scanner.pem=${CLAIR_SCANNER_PEM} \
            --from-file=config.yaml=/tmp/clair-config.yaml
        rm -rf /tmp/quay-enterprise-config.yaml
    fi

    if ! oc -n ${QUAY_NAMESPACE} get serviceaccounts -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${CLAIR_SERVICE_ACCOUNT}$"; then
        oc create serviceaccount ${CLAIR_SERVICE_ACCOUNT} -n ${QUAY_NAMESPACE}
    fi

    ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
    ## https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/
    oc secrets link ${CLAIR_SERVICE_ACCOUNT} quay-pull-secret --for=pull --namespace=${QUAY_NAMESPACE}

    if ! oc get services -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE "^${CLAIR_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/clair/clair-service.yaml | oc create -f -
    fi

    if ! oc get routes -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${QUAY_NAMESPACE} | grep -qE '^${CLAIR_K8S_NAME}$'; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/clair/clair-route.yaml | oc create -f -
    fi

    # Grant anyuid SCC to clair service since Clair runs only as root
    oc adm policy add-scc-to-user anyuid -n ${QUAY_NAMESPACE} -z ${CLAIR_SERVICE_ACCOUNT}

    if ! oc -n ${QUAY_NAMESPACE} get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${CLAIR_K8S_NAME}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/quay/clair/clair-deployment.yaml | oc create -f -
        wait_for_objects ${QUAY_NAMESPACE} ${CLAIR_K8S_NAME}
    fi

    #curl -k -X GET -I https://${CLAIR_HOSTNAME}:6061/health
    #curl -k -X GET -I https://localhost:6061/health
    #curl -X GET -I http://localhost:6061/health
}

function install_rook() {

    ## TODO: DISK CLEAN UP PROCEDURE
    #dmsetup info -c
    #dmsetup remove logvol_name
    #wipefs -af /dev/sdc

    #export HOST_SHARE_PATH='/home/vagrant/share'
    #source /root/.docker/pull-secrets.env
    #source ${HOST_SHARE_PATH}/templates/openshift/lib-openshift.sh


    ## https://rook.io/docs/rook/v1.0/ceph-quickstart.html
    ## https://github.com/rook/rook/tree/release-1.0/cluster/examples/kubernetes/ceph

    oc apply -f ${HOST_SHARE_PATH}/templates/rook/1-common.yaml

    ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
    oc create secret docker-registry rook-pull-secret \
    --docker-username="${ROOK_PULL_USER}" \
    --docker-password="${ROOK_PULL_TOKEN}" \
    --docker-email=caassup@ford.com \
    --docker-server=${ROOK_IMAGE_REPOSITORY} \
    --namespace=rook-ceph

    oc create secret docker-registry ceph-pull-secret \
    --docker-username="${CEPH_PULL_USER}" \
    --docker-password="${CEPH_PULL_TOKEN}" \
    --docker-email=caassup@ford.com \
    --docker-server=${CEPH_IMAGE_REPOSITORY} \
    --namespace=rook-ceph

    ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
    oc secrets link default rook-pull-secret --for=pull --namespace=rook-ceph
    oc secrets link rook-ceph-system rook-pull-secret --for=pull --namespace=rook-ceph

    oc secrets link default ceph-pull-secret --for=pull --namespace=rook-ceph
    oc secrets link rook-ceph-mgr ceph-pull-secret --for=pull --namespace=rook-ceph
    oc secrets link rook-ceph-osd ceph-pull-secret --for=pull --namespace=rook-ceph

    # Rook operator
    oc apply -f ${HOST_SHARE_PATH}/templates/rook/2-operator.yaml

    #set +e
    #for pod in rook-ceph-operator-* rook-ceph-agent-* rook-discover-*; do
    #    wait_for_pod rook-ceph-system ${pod}
    #done
    #set -e

    # verify the rook-ceph-operator, rook-ceph-agent, and rook-discover pods are in the `Running` state before proceeding
    wait_for_objects rook-ceph rook-ceph-operator

    #until [ "$(oc get pods $(oc -n rook-ceph get pods -l "app=rook-ceph-agent" -o=custom-columns=NAME:.metadata.name --no-headers=true) -o 'jsonpath={.status.conditions[?(@.type=="Ready")].status}')" == 'True' ] > /dev/null 2>&1; do sleep 10; oc -n rook-ceph get pods; done

    #until [ "$(oc get pods $(oc -n rook-ceph get pods -l "app=rook-discover" -o=custom-columns=NAME:.metadata.name --no-headers=true) -o 'jsonpath={.status.conditions[?(@.type=="Ready")].status}')" == 'True' ] > /dev/null 2>&1; do sleep 10; oc -n rook-ceph get pods; done

    # Deploy ceph cluster
    oc apply -f ${HOST_SHARE_PATH}/templates/rook/3-cluster.yaml

    chars=( {a..z} )
    NUM_SERVER=1
    for ((i=0; i<NUM_SERVER; i++)); do
        set +e
        # There is only one rook-ceph-mgr
        if [[ ${i} -eq 0 ]]; then
            wait_for_objects rook-ceph rook-ceph-mgr-${chars[i]}
        fi

        # Check rook-ceph-mon
        wait_for_objects rook-ceph rook-ceph-mon-${chars[i]}

        # Check rook-ceph-osd
        wait_for_objects rook-ceph rook-ceph-osd-${i}
        set -e
    done

    # Deploy Ceph toolbox
    oc apply -f ${HOST_SHARE_PATH}/templates/rook/4-ceph-toolbox.yaml
    set +e
    wait_for_objects rook-ceph rook-ceph-tools
    set -e

    # Check ceph status
    TOOLS_POD=$(oc -n rook-ceph get pod -l "app=rook-ceph-tools" -o jsonpath='{.items[0].metadata.name}')
    #CEPH_HEALTH=$(oc -n rook-ceph exec -it ${TOOLS_POD} -- ceph status | grep 'health:' | awk '{print $2}' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
    CEPH_HEALTH=$(oc -n rook-ceph exec -it ${TOOLS_POD} -- ceph status | grep 'health:' | awk '{print $2}' | tr -d '[:space:]')
    if [[ ${CEPH_HEALTH} != HEALTH_OK ]]; then
        echo "Ceph is un-healthy .. please validate before continuing"
    fi

    # Create ceph block storage
    oc apply -f ${HOST_SHARE_PATH}/templates/rook/5-block-storage.yaml

    # Create ceph object storage
    #oc apply -f ${HOST_SHARE_PATH}/templates/rook/6-object-storage.yaml

    # Confirm the object store is configured, wait for the rgw pod to start
    #until [ $(oc -n rook-ceph get deployment rook-ceph-rgw-obj-store-1 -ojsonpath="{.status.conditions[?(@.type=='Available')].status}") == "True" ] > /dev/null 2>&1; do sleep 10; oc -n rook-ceph get deploymentrook-ceph-rgw-obj-store-1; done

    # Create ceph dashboard
    oc apply -f ${HOST_SHARE_PATH}/templates/rook/7-ceph-dashboard.yaml

    # https://github.com/rook/rook/issues/3106
    oc -n rook-ceph exec -it ${TOOLS_POD} -- bash -c ' \
    ceph dashboard ac-role-create admin-no-iscsi
    for scope in dashboard-settings log rgw \
            prometheus grafana nfs-ganesha manager \
            hosts rbd-image config-opt rbd-mirroring \
            cephfs user osd pool monitor; do
        ceph dashboard ac-role-add-scope-perms admin-no-iscsi ${scope} create delete read update;
    done
    ceph dashboard ac-user-set-roles admin admin-no-iscsi'

    # Create ceph file storage
    #oc apply -f ${HOST_SHARE_PATH}/templates/rook/9-file-storage.yaml

    ## Deploy Ceph NFS
    #oc apply -f ${HOST_SHARE_PATH}/templates/rook/8a-nfs-operator-ns-sa.yaml
    #
    #oc create secret docker-registry rook-pull-secret \
    #--docker-username="${ROOK_PULL_USER}" \
    #--docker-password="${ROOK_PULL_TOKEN}" \
    #--docker-email=mysecret@ford.com \
    #--docker-server ${IMAGE_REPOSITORY} \
    #--namespace=rook-nfs-system
    #
    #oc secrets link default rook-pull-secret --for=pull --namespace=rook-nfs-system
    #oc secrets link rook-nfs-operator rook-pull-secret --for=pull --namespace=rook-nfs-system
    #oc secrets link rook-nfs-provisioner rook-pull-secret --for=pull --namespace=rook-nfs-system
    #
    #oc apply -f ${HOST_SHARE_PATH}/templates/rook/8b-nfs-operator.yaml
    #
    #until [ $(oc -n rook-nfs-system get deployment rook-nfs-operator -ojsonpath="{.status.conditions[?(@.type=='Available')].status}") == "True" ] > /dev/null 2>&1; do sleep 10; oc -n rook-ceph get deployment rook-nfs-operator; done
    #
    #until [ $(oc -n rook-nfs-system get deployment rook-nfs-provisioner -ojsonpath="{.status.conditions[?(@.type=='Available')].status}") == "True" ] > /dev/null 2>&1; do sleep 10; oc -n rook-ceph get deployment rook-nfs-provisioner; done
    #
    #oc apply -f ${HOST_SHARE_PATH}/templates/rook/8c-nfs-storage.yaml

    ## file storage class
    #oc apply -f ${HOST_SHARE_PATH}/templates/rook/6a-filesystem.yaml
    ##kubectl -n rook-ceph get pod -l app=rook-ceph-mds
    #set +e
    #for pod in rook-ceph-mds-myfs-a-* rook-ceph-mds-myfs-b-*; do
    #    wait_for_pod rook-ceph ${pod}
    #done
    #set -e

    ## https://remysharp.com/drafts/jq-recipes
    #oc -n rook-ceph-system get secret default-dockercfg-blzsh -o yaml | yq r - data.[.dockercfg] | base64 --decode | jq -r . > old.json
    #jq -s '.[0] * .[1]' old.json new.json > brand-new.json
    #oc -n rook-ceph-system get secret default-dockercfg-blzsh -o yaml | yq w - data.[.dockercfg] $(cat brand-new.json | base64 -w0) | oc -n rook-ceph-system apply -f -
}

function install_grafana() {

    export GF_NAMESPACE="${GF_NAMESPACE:=cluster-ops-grafana}"
    export GF_PULL_SECRET="${GF_PULL_SECRET:=gafana-pull-secret}"
    export GF_SERVICE_ACCOUNT="${GF_SERVICE_ACCOUNT:=grafana}"
    export GF_CONTAINER_IMAGE="${GF_CONTAINER_IMAGE:=files.caas.ford.com/caas-infra/grafana:6.3.3}"
    export GF_OAUTH_PROXY_IMAGE="${GF_OAUTH_PROXY_IMAGE:=registry.redhat.io/openshift3/oauth-proxy:v3.11.135}"
    export GF_ROUTE_HOST="${GF_ROUTE_HOST:=grafana.app.oc.local}"
    export GF_REPLICA_COUNT="${GF_REPLICA_COUNT:=1}"
    export SDE_GRAPHITE_URL="${SDE_GRAPHITE_URL:=http://sde-graphite-sde.app.caas.ford.com/}"

    # Create namespace
    if ! oc get project | grep -q ${GF_NAMESPACE}; then
        oc new-project ${GF_NAMESPACE}
    fi

    # Create service account
    if ! oc get serviceaccounts -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${GF_NAMESPACE} | grep -qE "^${GF_SERVICE_ACCOUNT}$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/sa-grafana.yaml | oc apply -f -
    fi

    # Create image pull secret
    if ! oc get secrets -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${GF_NAMESPACE} | grep -qE "^${GF_PULL_SECRET}$"; then
        ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
        oc create secret docker-registry ${GF_PULL_SECRET} \
        --docker-username="${CAASINFRA_PULL_USER}" \
        --docker-password="${CAASINFRA_PULL_TOKEN}" \
        --docker-email=mysecret@ford.com \
        --docker-server ${CAASINFRA_IMAGE_REPOSITORY} \
        --namespace=${GF_NAMESPACE}

        ## https://docs.openshift.com/container-platform/3.11/dev_guide/service_accounts.html#managing-allowed-secrets
        ## https://kubernetes.io/docs/tasks/configure-pod-container/configure-service-account/
        oc secrets link ${GF_SERVICE_ACCOUNT} ${GF_PULL_SECRET} --for=pull --namespace=${GF_NAMESPACE} || true
    fi

    # Create grafana.ini secert
    if ! oc -n ${GF_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-config$"; then
        oc create secret generic grafana-config \
            --from-file=grafana.ini=${HOST_SHARE_PATH}/templates/monitoring/manifests/grafana.ini \
            --namespace ${GF_NAMESPACE}
    fi

    # Create Oauth proxy session secret
    if ! oc -n ${GF_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-proxy$"; then
        oc -n ${GF_NAMESPACE} create secret generic grafana-proxy --from-literal=session_secret=$(openssl rand -base64 32)
    fi

    #if ! oc -n ${GF_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-htpasswd$"; then
    #    htpasswd -c -b -s /tmp/htpasswd gadmin ${GRAFANA_SECRET}
    #    oc -n ${GF_NAMESPACE} create secret generic grafana-htpasswd --from-file=auth=/tmp/htpasswd
    #fi

    # grant role to enable openshift authentication
    oc adm policy add-cluster-role-to-user system:auth-delegator -z ${GF_SERVICE_ACCOUNT} -n ${GF_NAMESPACE}

    # Default prometheus endpoint
    export OCP_PROMETHEUS_URL="https://prometheus-k8s.openshift-monitoring.svc:9091"
    # Default prometheus user and credentails, see https://access.redhat.com/solutions/{4153221,4234811} for details
    export OCP_PROM_USER=$(oc -n openshift-monitoring get secret grafana-datasources -o json | jq -r '.data["prometheus.yaml"]' | base64 -d | jq -r '.datasources[] |.basicAuthUser')
    export OCP_PROM_PASSWD=$(oc -n openshift-monitoring get secret grafana-datasources -o json | jq -r '.data["prometheus.yaml"]' | base64 -d | jq -r '.datasources[] |.basicAuthPassword')

    # Configure default grafana datasource
    if ! oc -n ${GF_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-datasources$"; then
        #envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/sec-grafana-datasources-v1.yaml | oc apply -f -
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/sec-grafana-datasources.yaml | oc apply -f -
    fi

    # Create grafana service object, note the annotation to generate self-signed cert
    if ! oc -n ${GF_NAMESPACE} get service -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/svc-grafana.yaml | oc apply -f -
    fi

    # Create grafana route object
    if ! oc -n ${GF_NAMESPACE} get route -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/ing-grafana.yaml | oc apply -f -
    fi

    # Configure default localtion to save dashboards
    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboards$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/cm-grafana-dashboards.yaml | oc create -f -
    fi

    # Load default grafana dashboards
    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-cluster-rsrc-use$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-cluster-rsrc-use \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-cluster-rsrc-use.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-node-rsrc-use$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-node-rsrc-use \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-node-rsrc-use.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-resources-cluster$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-resources-cluster \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-resources-cluster.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-resources-namespace$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-resources-namespace \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-resources-namespace.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboard-k8s-resources-pod$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboard-k8s-resources-pod \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/k8s-resources-pod.json
    fi

    if ! oc -n ${GF_NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^grafana-dashboards-sde$"; then
        oc --namespace=${GF_NAMESPACE} create configmap \
            grafana-dashboards-sde \
            --from-file=${HOST_SHARE_PATH}/templates/monitoring/dashboards/sde
    fi

    # Deploy grafana deployment
    if ! oc get deployments -o=custom-columns=NAME:.metadata.name --no-headers=true -n ${GF_NAMESPACE} | grep -qE "^grafana$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/monitoring/manifests/deployment.yaml | oc apply -f -
        wait_for_objects ${GF_NAMESPACE} grafana
    fi
}

function install_registry() {
    export REG_CONTAINER_IMAGE="${REG_CONTAINER_IMAGE:=registry.redhat.io/openshift3/ose-docker-registry:v3.11.135}"
    export REG_REPLICA_COUNT="${REG_REPLICA_COUNT:=1}"
    export REG_STORAGECLASS_NAME="${REG_STORAGECLASS_NAME:=nfs}"
    export REG_STORAGE_ACCESSMODE="${REG_STORAGE_ACCESSMODE:=ReadWriteMany}"
    export REG_STORAGE_SIZE="${REG_STORAGE_SIZE:=10Gi}"
    export REG_CLUSTER_TLD="${REG_CLUSTER_TLD:=oc.local}"
    export REG_APP_TLD="${REG_APP_TLD:=app.${REG_CLUSTER_TLD}}"
    export REG_ROUTE="${REG_ROUTE:=registry-int.${REG_APP_TLD}}"
    export REG_CONSOLE_ROUTE="${REG_CONSOLE_ROUTE:=registry-console.${REG_APP_TLD}}"
    export REG_KUBE_API_SERVER="${REG_KUBE_API_SERVER:=api.${REG_CLUSTER_TLD}:8443}"

    # https://docs.openshift.com/container-platform/3.11/install_config/registry/index.html
    # https://docs.openshift.com/container-platform/3.11/install_config/registry/securing_and_exposing_registry.html
    # https://docs.openshift.com/container-platform/3.11/admin_guide/image_policy.html
    # https://docs.openshift.com/container-platform/3.11/install_config/registry/accessing_registry.html#access-user-prerequisites

    # Deploy grafana deployment
    if ! oc get DeploymentConfig -o=custom-columns=NAME:.metadata.name --no-headers=true -n default | grep -qE "^docker-registry$"; then
        envsubst < ${HOST_SHARE_PATH}/templates/registry/manifests/registry.yaml | oc -n default apply -f -
    fi
    oc -n default rollout pause dc/docker-registry

    # kubectl get --all-namespaces svc -l "app.kubernetes.io/app=gestalt" -o jsonpath='{.items[*].metadata.labels.app\.kubernetes\.io/name}' | tr ' ' '\n' | uniq
    # kubectl get pods --field-selector=status.phase!=Running
    # https://github.com/kubeless/http-trigger/blob/master/script/libtest.bash
    # https://github.com/sololabs/demos/blob/master/gloo_transformation/knative_transform_test.sh

    until [ $(oc -n default get svc docker-registry -ojsonpath='{.spec.clusterIP}') != "" ] > /dev/null 2>&1; do sleep 3; done;
    export REG_CLUSTERIP=$(oc -n default get svc docker-registry -ojsonpath='{.spec.clusterIP}')

    oc adm ca create-server-cert \
        --signer-cert=/etc/origin/master/ca.crt \
        --signer-key=/etc/origin/master/ca.key \
        --signer-serial=/etc/origin/master/ca.serial.txt \
        --hostnames="docker-registry.default.svc.cluster.local,docker-registry.default.svc,${REG_CLUSTERIP},${REG_ROUTE}" \
        --cert=/etc/origin/master/registry.crt \
        --key=/etc/origin/master/registry.key

    oc -n default create secret generic registry-certificates \
        --from-file=/etc/origin/master/registry.crt \
        --from-file=/etc/origin/master/registry.key

    oc -n default secrets link registry registry-certificates
    oc -n default secrets link default  registry-certificates

    oc -n default rollout resume dc/docker-registry
    wait_for_objects default docker-registry DeploymentConfig

    oc -n default create route passthrough \
        --service=docker-registry \
        --hostname=${REG_ROUTE} \
        --insecure-policy=Redirect

    oc -n default create route passthrough \
        --service registry-console \
        --port registry-console \
        --hostname=${REG_CONSOLE_ROUTE} \
        --insecure-policy=Redirect

    oc -n openshift create \
        -f ${HOST_SHARE_PATH}/templates/registry/manifests/registry-console.yaml

    oc new-app -n default --template=registry-console \
        -p OPENSHIFT_OAUTH_PROVIDER_URL="https://${REG_KUBE_API_SERVER}" \
        -p REGISTRY_HOST=$(oc get route docker-registry -n default --template='{{ .spec.host }}') \
        -p COCKPIT_KUBE_URL=$(oc get route registry-console -n default --template='https://{{ .spec.host }}')

    dcertsdir=/etc/docker/certs.d
    destdir_addr=$dcertsdir/${REG_CLUSTERIP}:5000
    destdir_name=$dcertsdir/docker-registry.default.svc:5000
    mkdir -p $destdir_addr $destdir_name
    \cp -f /etc/origin/master/ca.crt $destdir_addr
    \cp -f /etc/origin/master/ca.crt $destdir_name

    \cp -f /etc/origin/master/ca.crt /etc/pki/ca-trust/source/anchors/registry.oc.local.crt
    update-ca-trust enable

    systemctl daemon-reload
    systemctl restart docker

    if ! grep --quiet -e "- ${REG_CLUSTERIP}:5000" /etc/origin/master/master-config.yaml; then
        sed -i "/- docker-registry.default.svc:5000/i \          - ${REG_CLUSTERIP}:5000" /etc/origin/master/master-config.yaml
    fi
    if ! grep --quiet -e "- domainName: ${REG_CLUSTERIP}:5000" /etc/origin/master/master-config.yaml; then
        sed -i "/- domainName: docker-registry.default.svc:5000/i \  - domainName: ${REG_CLUSTERIP}:5000" /etc/origin/master/master-config.yaml
    fi

    if ! grep --quiet -e "- ${REG_ROUTE}" /etc/origin/master/master-config.yaml; then
        sed -i "/- docker-registry.default.svc:5000/i \          - ${REG_ROUTE}" /etc/origin/master/master-config.yaml
    fi
    if ! grep --quiet -e "- domainName: ${REG_ROUTE}" /etc/origin/master/master-config.yaml; then
        sed -i "/- domainName: docker-registry.default.svc:5000/i \  - domainName: ${REG_ROUTE}" /etc/origin/master/master-config.yaml
    fi

    #oc policy add-role-to-user registry-viewer nsadmin
    #oc policy add-role-to-user registry-editor nsadmin
    #oc policy add-role-to-user system:image-builder nsadmin

    #oc login
    #docker pull busybox
    #docker tag docker.io/busybox:latest docker-registry.default.svc:5000/openshift/busybox
    #docker login -u openshift -p $(oc whoami -t) docker-registry.default.svc:5000
    #docker push docker-registry.default.svc:5000/openshift/busybox

    #/usr/local/bin/master-restart api
    #/usr/local/bin/master-restart controllers
    restart_control_plane
    wait_for_k8s_apiserver https://${REG_KUBE_API_SERVER}
}

function export_namespace() {
    local ns_to_export=$1
    local yaml_dir=$2
    local objects

    mkdir -p ${yaml_dir}

    echo "Backing up object definitions"
    objects=$(oc -n ${ns_to_export} get -o=custom-columns=NAMESPACE:.metadata.namespace,KIND:.kind,NAME:.metadata.name configmap,route,service,secret,deployment,deploymentconfig,statefulset,hpa,job,cronjob,role,rolebinding,serviceaccount,buildconfig,builds,imagestream --no-headers)
    if [[ -z "${objects}" ]]; then
        echo "ERROR: No objects found"
        exit 1
    fi
    while read -r line; do
        local NS=$(echo "${line}" | awk '{print $1}')
        local KIND=$(echo "${line}" | awk '{print $2}')
        local NAME=$(echo "${line}" | awk '{print $3}')
        mkdir -p "${yaml_dir}/$NS"
        if [[ $KIND == Secret ]]; then
            local yaml=$((oc -n $NS get $KIND $NAME -o=yaml) 2>/dev/null)
            if [[ $yaml =~ (service-account-token|dockercfg) ]]; then
                continue
            fi
        fi
        if [[ $KIND == RoleBinding ]]; then
            local yaml=$((oc -n $NS get $KIND $NAME -o=yaml) 2>/dev/null)
            if [[ $yaml =~ (system:image-builders|system:deployers|system:image-pullers) ]]; then
                continue
            fi
        fi
        if [[ $KIND == ServiceAccount ]]; then
            local yaml=$((oc -n $NS get $KIND $NAME -o=yaml) 2>/dev/null)
            if [[ $yaml =~ (builder|default|deployer) ]]; then
                continue
            fi
        fi
        echo -n "Saving ${NS}/${KIND}.${NAME}.yaml"
        cmdOpts=""
        if [[ Role == $KIND || RoleBinding == $KIND ]]; then
            cmdOpts=""
        else
            cmdOpts="--export"
        fi
        oc -n $NS get $KIND $NAME -o=yaml $cmd | \
            yq delete - metadata.creationTimestamp | \
            yq delete - metadata.selfLink | \
            yq delete - metadata.resourceVersion | \
            yq delete - metadata.uid | \
            yq delete - metadata.generation | \
            yq delete - status > "${yaml_dir}/$NS/$KIND.$NAME.yaml"
        echo ""
    done <<< "${objects}"
}

function purge_namespace() {
    local namespace_to_purge=$1
    local yaml_dir=$2

    if ! oc get namespace ${namespace_to_purge}; then
        echo "Namespace ${namespace_to_purge} does not exists"
        exit 1
    fi

    if [ ! -d ${yaml_dir} ]; then
        echo "Directory ${yaml_dir} does not exists"
        exit 1
    fi

    for file in $(ls "${yaml_dir}/${namespace_to_purge}"); do
        extension="${file##*.}"
        filename="${filename%.*}"
        if [[ $extension != yaml ]]; then
            continue
        fi
        oc -n ${namespace_to_purge} delete -f "${yaml_dir}/${namespace_to_purge}/${file}"
    done
}

function proxy_check() {
    export ENABLE_PROXY=false
    set +e
    HTTP_CODE=$( \
        curl \
        --head \
        --insecure \
        --location \
        --silent \
        --fail \
        --output /dev/null \
        --write-out "%{http_code}" \
        --connect-timeout 10 \
        --proxy http://internet.ford.com:83 \
        https://google.com
    )
    if [ "$HTTP_CODE" = "200" ]; then
        export ENABLE_PROXY=true
    fi
    set -e

    if [ "$ENABLE_PROXY" = "true" ]; then
        export http_proxy="http://internet.ford.com:83"
        export https_proxy="http://internet.ford.com:83"
        export no_proxy="localhost,127.0.0.1,.ford.com,.local"
    else
        export http_proxy=""
        export https_proxy=""
        export no_proxy=""
    fi
}

function create_certs() {
    ## openssl
    # https://github.com/matsmith/rawgit/blob/master/scripts/bootstrap.sh
    # https://github.com/cpadilla/eve-twitch-dev-jam-2019/blob/master/bin/generate_cert.sh
    # https://unix.stackexchange.com/questions/104171/create-ssl-certificate-non-interactively
    # https://deliciousbrains.com/ssl-certificate-authority-for-local-https-development/
    # https://gist.github.com/Soarez/9688998
    # https://www.openssl.org/docs/manmaster/man5/x509v3_config.html
    # https://roll.urown.net/ca/ca_root_setup.html
    # https://jamielinux.com/docs/openssl-certificate-authority/index.html
    # https://pki-tutorial.readthedocs.io/en/latest/simple/root-ca.conf.html
    # https://roll.urown.net/ca/ca_root_setup.html
    # https://github.com/fluffle/ca-scripts
    # https://www.phildev.net/ssl/opensslconf.html

    ## cfssl
    # https://medium.com/containerum/installing-kubernetes-from-binaries-pt-2-configuring-certificates-with-cfssl-8137d6e791ef
    # https://coreos.com/os/docs/latest/generate-self-signed-certificates.html
    # https://github.com/drewfarris/sample-cfssl-ca
    # https://scriptcrunch.com/create-ca-tls-ssl-certificates-keys/
    # https://github.com/knative/observability/blob/master/cmd/cert-generator/entrypoint.sh

    local OUTDIR=$1
    local CN=$2
    local SAN=${3:-}
    local IP=${4:-}

    local CRL_DIR="${OUTDIR}/crl"
    local CA_DIR="${OUTDIR}/ca"
    local CNF_PATH="${OUTDIR}/certs/${CN}/openssl.cnf"
    local SITE_DIR="${OUTDIR}/certs/${CN}"

    export CA_HOME=${OUTDIR}

    mkdir -p ${OUTDIR} ${CA_DIR} ${SITE_DIR} ${CRL_DIR}
    if [ ! -f ${CRL_DIR}/ca.srl ]; then
        echo 1000 > ${CRL_DIR}/ca.srl
    fi

    SCRPT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
    if [ ! -f ${CNF_PATH} ]; then
        cp $(dirname ${SCRPT_ROOT})/openssl.cnf ${CNF_PATH}
    fi

    if [ "${SAN}" != "" ] || [ "${IP}" != "" ]; then
        echo "subjectAltName = @alt_names" >> ${CNF_PATH}
        echo "[alt_names]" >> ${CNF_PATH}
    fi

    if [ "${SAN}" != "" ]; then
        OIFS=$IFS
        IFS=","
        sanArray=($SAN)
        for ((i=0; i<${#sanArray[@]}; ++i)); do
            #echo "san $i: ${sanArray[$i]}"
            echo "DNS.$(($i+1)) = ${sanArray[$i]}" >> ${CNF_PATH}
        done
        IFS=$OIFS
    fi

    if [ "${IP}" != "" ]; then
        OIFS=$IFS
        IFS=","
        ipArray=($IP)
        for ((i=0; i<${#ipArray[@]}; ++i)); do
            #echo "san $i: ${ipArray[$i]}"
            echo "IP.$(($i+1)) = ${ipArray[$i]}" >> ${CNF_PATH}
        done
        IFS=$OIFS
    fi

    # Generate root CA key
    if [ ! -f ${CA_DIR}/ca.key ]; then
        #openssl genrsa -des3 -out myCA.key 2048
        openssl genrsa -out ${CA_DIR}/ca.key 2048
    fi

    # Generate root CA certificate
    #-CAcreateserial \
    if [ ! -f ${CA_DIR}/ca.pem ]; then
        openssl req -x509 -new -nodes \
            -key ${CA_DIR}/ca.key -sha256 \
            -days 1825 \
            -out ${CA_DIR}/ca.pem \
            -subj "/C=US/ST=Michigan/L=Dearborn/O=Ford/OU=ITO/CN=localCA" \
            -config ${CNF_PATH}
    fi

    # Generate private key for site
    if [ ! -f ${SITE_DIR}/${CN}.key ]; then
        openssl genrsa -out ${SITE_DIR}/${CN}.key 2048
    fi

    # Generate site CSR
    #echo "openssl req -in ${SITE_DIR}/${CN}.csr -noout -text"
    if [ ! -f ${SITE_DIR}/${CN}.csr ]; then
        openssl req -new \
            -key ${SITE_DIR}/${CN}.key \
            -out ${SITE_DIR}/${CN}.csr \
            -subj "/C=US/ST=Michigan/L=Dearborn/O=Ford/OU=ITO/CN=${CN}" \
            -config ${CNF_PATH}
    fi

    # Sign site certificate
    #echo "openssl x509 -in ${SITE_DIR}/${CN}.pem -noout -text"
    # -CAserial serial \
    if [ ! -f ${SITE_DIR}/${CN}.pem ]; then
        openssl x509 -req \
            -in ${SITE_DIR}/${CN}.csr \
            -out ${SITE_DIR}/${CN}.pem \
            -CA ${CA_DIR}/ca.pem \
            -CAkey ${CA_DIR}/ca.key \
            -CAserial ${CRL_DIR}/ca.srl\
            -days 1825 -sha256 \
            -extensions v3_req \
            -extfile ${CNF_PATH}
    fi

    # Bundle site certificate and the ca certificate.
    #cat ${SITE_DIR}/${CN}.pem ${CA_DIR}/ca.pem > ${SITE_DIR}/${CN}.bundle.pem
}

function install_crunchydata() {
    local overrides=${1:-}

    if [[ "${overrides}x" != "x"  && -f ${overrides} ]]; then
        set -a
        source ${overrides}
        set +a
    fi

    # Ref: https://unix.stackexchange.com/a/122848
    export MANIFEST_PATH="${MANIFEST_PATH:=${HOST_SHARE_PATH}/templates/crunchydata}"
    export DOTPGO_PATH="${DOTPGO_PATH:=${HOST_SHARE_PATH:-HOME}/envs/.pgo}"
    export PGO_DNS_SUFFIX="${PGO_DNS_SUFFIX:=app.oc.local}"

    export PGO_VERSION="${PGO_VERSION:=4.0.1}"
    export PGO_NAMESPACE="${PGO_NAMESPACE:=example}"

    export DEFAULT_POD_CLASS="${DEFAULT_POD_CLASS:=mini}"
    export DEFAULT_PG_MAJOR="${DEFAULT_PG_MAJOR:=11}"

    export FEATURE_OPERATOR=${FEATURE_OPERATOR:=true}
    export FEATURE_CREATE_PGCLUSTER=${FEATURE_CREATE_PGCLUSTER:=true}
    export FEATURE_SETUP_PGBACKREST_BACKUPS=${FEATURE_SETUP_PGBACKREST_BACKUPS:=true}
    export FEATURE_DEPLOY_MONITORING=${FEATURE_DEPLOY_MONITORING:=false}
    export FEATURE_DEPLOY_PGADMIN=${FEATURE_DEPLOY_PGADMIN:=false}

    # Ref: https://en.wikipedia.org/wiki/Cron#Overview
    export PGBACKREST_FULL_SCHEDULE="${PGBACKREST_FULL_SCHEDULE:=00 20 * * 0}"
    export PGBACKREST_INCR_SCHEDULE="${PGBACKREST_INCR_SCHEDULE:=00 20 * * 1-6}"

    export PGOROLE="${PGOROLE:=pgoadmin}"
    export PGO_USERNAME="${PGO_USERNAME:=pgoadminuser}"
    export PGO_PASSWORD="${PGO_PASSWORD:=$(cat /dev/urandom | env LC_CTYPE=C tr -dc 'a-zA-Z0-9' | fold -w 12 | head -n 1)}"

    # Image version
    export CRUNCHYDATA_PULL_USER=${CRUNCHYDATA_PULL_USER?}
    export CRUNCHYDATA_PULL_TOKEN=${CRUNCHYDATA_PULL_TOKEN?}
    export IMAGE_REPOSITORY="${IMAGE_REPOSITORY:=files.caas.ford.com}"
    export PGO_IMAGE_PREFIX="${IMAGE_REPOSITORY}/crunchydata"
    export CCP_IMAGE_TAG="${CCP_IMAGE_TAG:=11.4-2.4.1}"
    export CCP_IMAGE_PREFIX=${PGO_IMAGE_PREFIX}

    # PGO defaults
    export DB_PVC_SIZE=${DB_PVC_SIZE:=5} # in Gi
    export BACKUP_PVC_SIZE=${BACKUP_PVC_SIZE:=5} # in Gi
    export PRIMARY_STORAGE_CLASS="${PRIMARY_STORAGE_CLASS:=nfs}"
    export BACKUP_STORAGE_CLASS="${BACKUP_STORAGE_CLASS:=nfs}"
    export BACKREST_STORAGE_CLASS="${BACKREST_STORAGE_CLASS:=nfs}"
    export REPLICA_STORAGE_CLASS="${REPLICA_STORAGE_CLASS:=nfs}"
    #export ACCESS_MODE="${ACCESS_MODE:=ReadWriteOnce}"
    #export BACKUP_ACCESS_MODE="${BACKUP_ACCESS_MODE:=ReadWriteMany}"
    export ACCESS_MODE="${ACCESS_MODE:=ReadWriteMany}"
    export BACKUP_ACCESS_MODE="${BACKUP_ACCESS_MODE:=ReadWriteMany}"
    export SERVICE_TYPE="${SERVICE_TYPE:=ClusterIP}"
    export PRIMARY_NODE_LABEL="${PRIMARY_NODE_LABEL:=''}"
    export REPLICA_NODE_LABEL="${REPLICA_NODE_LABEL:=''}"
    #export PRIMARY_NODE_LABEL="failure-domain.ford.com/zone=edc1-dh1"
    #export REPLICA_NODE_LABEL="failure-domain.ford.com/zone=ecc"

    # pgadmin4
    export CCP_STORAGE_CLASS="${CCP_STORAGE_CLASS:=nfs}"
    export PGADMIN_SERVICE_TYPE="${PGADMIN_SERVICE_TYPE:=ClusterIP}"
    export CCP_IMAGE_PREFIX="${CCP_IMAGE_PREFIX:=crunchydata}"
    export CCP_IMAGE_TAG="${CCP_IMAGE_TAG:=centos7-11.4-2.4.1}"
    export CCP_STORAGE_CAPACITY="${CCP_STORAGE_CAPACITY:=10Gi}"
    export CCP_STORAGE_MODE="${CCP_STORAGE_MODE:=ReadWriteOnce}"
    export CCP_NAMESPACE=${PGO_NAMESPACE}
    export PGADMIN4USERNAME="${PGADMIN4USERNAME:=pgadmin}"
    export PGADMIN4PASSWORD="${PGADMIN4PASSWORD:=$(cat /dev/urandom | env LC_CTYPE=C tr -dc 'a-zA-Z0-9' | fold -w 12 | head -n 1)}"

    # psql monitoring
    export ALERT_EMAIL_LIST="${ALERT_EMAIL_LIST:=caassup@ford.com}"
    export MON_NAMESPACE="${PGO_NAMESPACE}"
    export IMAGE_REGISTRY=${IMAGE_REPOSITORY}
    export REPOSITORY="${REPOSITORY:=crunchydata}"
    export CCP_STORAGE_CLASS="${CCP_STORAGE_CLASS:=nfs}"
    export SERVICE_TYPE="${SERVICE_TYPE:=ClusterIP}"
    export CCP_IMAGE_PREFIX="$IMAGE_REGISTRY/$REPOSITORY"
    export PROM_IMAGE_PREFIX="$IMAGE_REGISTRY/$REPOSITORY"
    export PROM_IMAGE_NAME="${PROM_IMAGE_NAME:=crunchy-prometheus}"
    export PROM_IMAGE_TAG="${PROM_IMAGE_TAG:=centos7-10.6-2.2.0}"
    export ALERT_IMAGE_PREFIX="${ALERT_IMAGE_PREFIX:=registry.redhat.io/openshift3}"
    export ALERT_IMAGE_NAME="${ALERT_IMAGE_NAME:=prometheus-alertmanager}"
    export ALERT_IMAGE_TAG="${ALERT_IMAGE_TAG:=v3.11.88-2}"
    export GRAFANA_IMAGE_PREFIX="$IMAGE_REGISTRY/$REPOSITORY"
    export GRAFANA_IMAGE_NAME="${GRAFANA_IMAGE_NAME:=crunchy-grafana}"
    export GRAFANA_IMAGE_TAG="${GRAFANA_IMAGE_TAG:=centos7-11.2-2.3.1}"
    export CCP_STORAGE_MODE="${CCP_STORAGE_MODE:=ReadWriteOnce}"
    export CCPROOT="$HOME/cdev/src/github.com/crunchydata/crunchy-containers/"
    export KUBE_CLI="${KUBE_CLI:=oc}"
    export CCP_STORAGE_CAPACITY="${CCP_STORAGE_CAPACITY:=5Gi}"
    export CCP_STORAGE_MODE="${CCP_STORAGE_MODE:=ReadWriteOnce}"
    export CCP_SECURITY_CONTEXT="${CCP_SECURITY_CONTEXT:=''}"
    export CCP_IMAGE_TAG="${CCP_IMAGE_TAG:=centos7-10.6-2.2.0}"

    export GLOBAL_CONFIG_MAP="${GLOBAL_CONFIG_MAP:=pgo-custom-pg-config}"
    export GOPATH=${DOTPGO_PATH}/${PGO_NAMESPACE}/pgop${PGO_VERSION}
    export GOBIN=${GOPATH}/bin
    export PATH=$PATH:$GOBIN
    mkdir -p ${GOPATH}/{pkg,bin,Manifests}
    mkdir -p ${GOPATH}/src/github.com/crunchydata/postgres-operator

    #export PGO_APISERVER_URL=https://$(oc -n ${PGO_OPERATOR_NAMESPACE} get route pgoperator -o=jsonpath="{.spec.host}")
	cat > "${GOPATH}/pgopenv" <<-EOF
	export PGO_VERSION=${PGO_VERSION}
	export PGO_OPERATOR_NAMESPACE=${PGO_NAMESPACE} # ns where operator is installed
    export TARGET_NAMESPACE=${PGO_NAMESPACE}
	export PGO_NAMESPACE=${PGO_NAMESPACE}
	export NAMESPACE=${PGO_NAMESPACE}
	export NAMESPACES=${PGO_NAMESPACE} # comma delimited list of ns the opertaor watches
	export PGORELEASE=${PGO_VERSION}
	export PGO_APISERVER_URL=https://pgoperator-${PGO_NAMESPACE}.${PGO_DNS_SUFFIX}:8443
	#export CLUSTER='prod'
	export PGO_IMAGE_PREFIX=${PGO_IMAGE_PREFIX}
	export GOBIN=${GOPATH}/bin
	export PATH=${GOBIN}:${PATH}
	export PGOROOT=${GOPATH}/src/github.com/crunchydata/postgres-operator
	export PGO_BASEOS=centos7
	export PGO_IMAGE_TAG=\${PGO_BASEOS}-${PGO_VERSION}
	export PGO_CMD=oc
	export PGO_CA_CERT=\${PGOROOT}/conf/postgres-operator/server.crt
	export PGO_CLIENT_CERT=\${PGOROOT}/conf/postgres-operator/server.crt
	export PGO_CLIENT_KEY=\${PGOROOT}/conf/postgres-operator/server.key
	export PGOUSER=${GOPATH}/pgouser
	setip() {
	    export PGO_APISERVER_URL=https://\$(oc -n ${PGO_OPERATOR_NAMESPACE} get service postgres-operator -o=jsonpath="{.spec.clusterIP}"):8443
	}
	pfpgo() {
	    PODNAME=\$(oc get pod --selector=name=postgres-operator -ojsonpath='{.items[0].metadata.name}')
	    oc port-forward \${PODNAME} 18443:8443 > /dev/null 2>&1 &
	    export PGO_APISERVER_URL=https://127.0.0.1:18443
	}
	EOF

    proxy_check
    source ${GOPATH}/pgopenv

    echo "Downloading CrunchyData PostgreSQL Operator v${PGORELEASE}"
    curl \
        --connect-timeout "${CURL_CONNECTION_TIMEOUT:-20}" \
        --retry "${CURL_RETRY:-5}" \
        --retry-delay "${CURL_RETRY_DELAY:-0}" \
        --retry-max-time "${CURL_RETRY_MAX_TIME:-60}" \
        --progress-bar \
        --location \
        --fail \
        --show-error \
        --output /tmp/postgres-operator.${PGORELEASE}.tar.gz \
        https://github.com/CrunchyData/postgres-operator/releases/download/${PGORELEASE}/postgres-operator.${PGORELEASE}.tar.gz

    pushd ${PGOROOT}
    mv /tmp/postgres-operator.${PGORELEASE}.tar.gz .
    tar -xvzf postgres-operator.${PGORELEASE}.tar.gz --overwrite
    /bin/cp -f pgo ${GOBIN}/pgo
    /bin/cp -f expenv ${GOBIN}/expenv
    chmod +x ${GOBIN}/{pgo,expenv}
    rm -rf postgres-operator.${PGORELEASE}.tar.gz
    popd

    # Place the Crunchydata Operator manifest
    envsubst < ${MANIFEST_PATH}/pgo.yaml > ${GOPATH}/Manifests/pgo.yaml
    /bin/cp -f ${MANIFEST_PATH}/operator/${PGORELEASE}/* ${GOPATH}/Manifests

    # TODO (SPURANAM): Delete PGO deployed resources
    # Delete existsing operators
    echo "Deleting existing oprator install"
    oc --namespace=${PGO_OPERATOR_NAMESPACE} delete secret/pgo-backrest-repo-config > /dev/null 2>&1 || true
    oc --namespace=${PGO_OPERATOR_NAMESPACE} delete secret/pgo.tls > /dev/null 2>&1 || true
    oc --namespace=${PGO_OPERATOR_NAMESPACE} delete configmap/pgo-config > /dev/null 2>&1 || true
    oc --namespace=${PGO_OPERATOR_NAMESPACE} delete service/postgres-operator > /dev/null 2>&1 || true
    oc --namespace=${PGO_OPERATOR_NAMESPACE} delete deployment/postgres-operator > /dev/null 2>&1 || true

    # Copying service and roles manifest to $GOPATH/Manifests
    /bin/cp -f ${PGOROOT}/deploy/service-accounts.yaml ${GOPATH}/Manifests
    /bin/cp -f ${PGOROOT}/deploy/crd.yaml ${GOPATH}/Manifests
    /bin/cp -f ${PGOROOT}/deploy/deployment.json ${GOPATH}/Manifests
    /bin/cp -f ${PGOROOT}/deploy/rbac.yaml ${GOPATH}/Manifests
    /bin/cp -f ${PGOROOT}/deploy/service.json ${GOPATH}/Manifests

    # Create namespace if missing
    if ! oc get namespace | grep -q ${PGO_OPERATOR_NAMESPACE}; then
        echo "Creating namespace ${PGO_OPERATOR_NAMESPACE} for the PGO operator"
        oc create namespace ${PGO_OPERATOR_NAMESPACE}
    fi

    # TODO (SPURANAM): Add TLS support for PostgreSQL
    #   https://jelastic.com/blog/establish-secure-ssl-connection-to-postgresql-database-server/
    #   https://www.howtoforge.com/postgresql-ssl-certificates
    #   https://access.redhat.com/articles/1462183
    #   https://www.postgresql.org/docs/11/ssl-tcp.html
    #   https://github.com/CrunchyData/postgres-operator/tree/master/examples/custom-config-ssl
    #   https://github.com/CrunchyData/postgres-operator/blob/master/deploy/gen-api-keys.sh
    #   https://access.crunchydata.com/documentation/postgres-operator/4.0.1/gettingstarted/
    #   https://github.ford.com/Platform-Enablement/postgresql
    if ! oc -n ${NAMESPACE} get configmaps -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${GLOBAL_CONFIG_MAP}$"; then
        echo "Creating custom configmap for PGO operator"
        oc -n ${NAMESPACE} create configmap ${GLOBAL_CONFIG_MAP} \
        --from-file=${MANIFEST_PATH}/operator/configs/${DEFAULT_POD_CLASS}/postgresql.conf \
        --from-file=${MANIFEST_PATH}/operator/configs/pg_hba.conf \
        --from-file=${MANIFEST_PATH}/operator/configs/setup.sql
    fi

    # WARNING : Can break existing PostgreSQL instances across the cluster
    # This updates cluster wide resources
    #if oc auth can-i create clusterroles --as $(oc whoami) --quiet=true; then
    if oc auth can-i create clusterroles --quiet=true; then
        echo "Creating CRD, ClusterRoles and ClusterRoleBindings for PGO operator"
        expenv -f ${GOPATH}/Manifests/crd.yaml | oc create -f - || true
        # Using apply to accomodate any existing defintions in the cluster
        expenv -f ${GOPATH}/Manifests/cluster-roles.yaml | oc apply -f - || true
        expenv -f ${GOPATH}/Manifests/cluster-role-bindings.yaml | oc create -f - || true
    fi

    # Crunchy Operator master configuration
    expenv -f ${GOPATH}/Manifests/pgo.yaml > ${PGOROOT}/conf/postgres-operator/pgo.yaml

    # Override default PGO userfile used for basicAuth
    echo "Creating user database for PGO operator"
    echo "${PGO_USERNAME}:${PGO_PASSWORD}:${PGOROLE}:${PGO_OPERATOR_NAMESPACE}" > ${GOPATH}/pgouser
    \cp -f ${GOPATH}/pgouser ${PGOROOT}/conf/postgres-operator/pgouser

    # Using custom resources for crunchy collect and pgbackrest container
    \cp -f ${GOPATH}/Manifests/collect.json ${PGOROOT}/conf/postgres-operator/collect.json
    \cp -f ${GOPATH}/Manifests/pgo-backrest-repo-template.json ${PGOROOT}/conf/postgres-operator/pgo-backrest-repo-template.json

    # Create service accounts and grant roles
    expenv -f ${GOPATH}/Manifests/service-accounts.yaml | oc create -f - || true
    expenv -f ${GOPATH}/Manifests/rbac.yaml | oc create -f - || true

    # Create container image pull secret
    if ! oc -n ${PGO_OPERATOR_NAMESPACE} get secret -o=custom-columns=NAME:.metadata.name --no-headers=true | grep -qE "^${PGO_OPERATOR_NAMESPACE}-pull-secret$"; then
        echo "Creating imagePull secret PGO operator"
        oc create secret docker-registry ${PGO_OPERATOR_NAMESPACE}-pull-secret  \
            --docker-username="${CRUNCHYDATA_PULL_USER}" \
            --docker-email="caassup@ford.com" \
            --docker-password="${CRUNCHYDATA_PULL_TOKEN}" \
            --docker-server=${IMAGE_REPOSITORY} \
            --namespace=${PGO_OPERATOR_NAMESPACE}
    fi

    # link pull secret with service account
    oc secrets link default ${PGO_OPERATOR_NAMESPACE}-pull-secret \
        --for=pull --namespace=${PGO_OPERATOR_NAMESPACE} || true

    oc secrets link postgres-operator ${PGO_OPERATOR_NAMESPACE}-pull-secret \
        --for=pull --namespace=${PGO_OPERATOR_NAMESPACE} || true

    oc secrets link pgo-backrest ${PGO_OPERATOR_NAMESPACE}-pull-secret \
        --for=pull --namespace=${PGO_OPERATOR_NAMESPACE} || true

    # Enable pgbackrest
    rm -f ${PGOROOT}/conf/pgo-backrest-repo/ssh_*
    rm -f ${PGOROOT}/conf/pgo-backrest-repo/id_*
    rm -f ${PGOROOT}/conf/pgo-backrest-repo/authorized_keys
    ${PGOROOT}/deploy/gen-sshd-keys.sh
    ${PGOROOT}/deploy/gen-api-keys.sh

    # Credentials for pgbackrest sshd
    oc create secret generic pgo-backrest-repo-config \
        --namespace=${PGO_OPERATOR_NAMESPACE} \
        --from-file=config=${PGOROOT}/conf/pgo-backrest-repo/config \
        --from-file=sshd_config=${PGOROOT}/conf/pgo-backrest-repo/sshd_config \
        --from-file=aws-s3-credentials.yaml=${PGOROOT}/conf/pgo-backrest-repo/aws-s3-credentials.yaml \
        --from-file=aws-s3-ca.crt=${PGOROOT}/conf/pgo-backrest-repo/aws-s3-ca.crt

    # credentials for pgo-apiserver TLS REST API
    oc create secret tls pgo.tls \
        --namespace=${PGO_OPERATOR_NAMESPACE} \
        --key=${PGOROOT}/conf/postgres-operator/server.key \
        --cert=${PGOROOT}/conf/postgres-operator/server.crt

    # Gather up operator default templates
    oc create configmap pgo-config \
        --namespace=${PGO_OPERATOR_NAMESPACE} \
        --from-file=${PGOROOT}/conf/postgres-operator/

    # deploy operator
    expenv -f ${PGOROOT}/deploy/deployment.json | oc --namespace=${PGO_OPERATOR_NAMESPACE} create -f -

    # deploy operator's api server service object
    oc -n ${PGO_OPERATOR_NAMESPACE} create -f ${GOPATH}/Manifests/service.json

    # deploy operator's api server route object
    expenv -f ${GOPATH}/Manifests/route.yaml | oc -n ${PGO_OPERATOR_NAMESPACE} apply -f -

    #until oc -n ${PGO_OPERATOR_NAMESPACE} get pods --selector=name=postgres-operator -ojsonpath='{.items[0].status.phase}' | grep Running ; do sleep 10; oc -n ${PGO_OPERATOR_NAMESPACE} get pods --selector=name=${PGCLUSTER_NAME}; done

    #until [ "$(oc -n ${PGO_OPERATOR_NAMESPACE} get deployment postgres-operator -ojsonpath="{.status.conditions[?(@.type=='Available')].status}")" == "True" ] > /dev/null 2>&1; do echo "Waiting for postgres-operator" sleep 10; oc -n ${PGO_OPERATOR_NAMESPACE} get deployment postgres-operator; done

    # Wait for opertor pod
    JSONPATH='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'; until oc -n ${PGO_OPERATOR_NAMESPACE} get pods --selector=name=postgres-operator -o jsonpath="$JSONPATH" 2>&1 | grep -q "Ready=True"; do echo "waiting for postgres-operator to be available"; sleep 1; oc -n ${PGO_OPERATOR_NAMESPACE} get pods --selector=name=postgres-operator; done

    ## TODO (SPURANAM): After everything works scale up the database cluster to have atleast one (1) read replica
    ## Make sure that AUTOFAIL=true and pgo create cluster looks like this
    ## pgo create cluster ${PGCLUSTER_NAME} --replica-count=1
    # source /home/vagrant/share/backups/.pgo/quay-enterprise/pgop4.0.1/pgopenv
    # export PGO_APISERVER_URL=https://$(oc -n ${PGO_OPERATOR_NAMESPACE} get svc postgres-operator -o=custom-columns=NAME:.spec.clusterIP --no-headers):8443
    # pgo scale ${PGCLUSTER_NAME} --resources-config=${DEFAULT_POD_CLASS} --replica-count=1

    ## TODO (SPURANAM): Force manual backup run
    ## date -u +'%Y-%m-%dT%H:%M:%S.s'
    # source /home/vagrant/share/backups/.pgo/quay-enterprise/pgop4.0.1/pgopenv
    # export PGO_APISERVER_URL=https://$(oc -n ${PGO_OPERATOR_NAMESPACE} get svc postgres-operator -o=custom-columns=NAME:.spec.clusterIP --no-headers):8443
    # export PGBACKREST_FULL_SCHEDULE="$(date -ud @$((60+$(date +%s))) +'%M %H') * * *"
    # export PGCLUSTER_NAME='quay-db'
    # pgo create schedule \
    #    --schedule="${PGBACKREST_FULL_SCHEDULE}" \
    #    --schedule-type=pgbackrest \
    #    --pgbackrest-backup-type=full \
    #    ${PGCLUSTER_NAME}

    # Deploy PSQL Monitoring
    if [ "${FEATURE_DEPLOY_MONITORING}" = "true" ]; then
        oc delete --namespace=${MON_NAMESPACE} clusterrolebinding prometheus-crb > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} clusterrole prometheus-cr > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} rolebinding prometheus-rb > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} role prometheus-r > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} sa prometheus-sa > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} deployment monitoring > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} service monitoring > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} route prometheus grafana alertmanager > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} configmap prometheus-cm > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} configmap alertmanager-cm > /dev/null 2>&1 || true
        oc delete --namespace=${MON_NAMESPACE} pvc monitoring-${MON_NAMESPACE}-prometheusdata monitoring-${MON_NAMESPACE?}-grafanadata > /dev/null 2>&1 || true

        expenv -f ${MANIFEST_PATH}/monitoring/metrics-pvc-sc.json | oc create --namespace=${MON_NAMESPACE} -f -
        expenv -f ${MANIFEST_PATH}/monitoring/prometheus.template > ${MANIFEST_PATH}/monitoring/prometheus.yml
        expenv -f ${MANIFEST_PATH}/monitoring/alertmanager.template > ${MANIFEST_PATH}/monitoring/alertmanager.yml

        echo "Creating configMap using prometheus.yml" > /dev/null 2>&1
        oc create --namespace=${MON_NAMESPACE} configmap prometheus-cm \
            --from-file=${MANIFEST_PATH}/monitoring/prometheus.yml \
            --from-file=${MANIFEST_PATH}/monitoring/crunchy-alert-rules.yml

        echo "Creating configMap using alertmanager.yml"
        oc create --namespace=${MON_NAMESPACE?} configmap alertmanager-cm \
        --from-file=${MANIFEST_PATH}/monitoring/alertmanager.yml

        #expenv -f ${MANIFEST_PATH}/monitoring/cluster-rbac.json | oc create --namespace=${MON_NAMESPACE?} -f -
        expenv -f ${MANIFEST_PATH}/monitoring/rbac.json | oc create --namespace=${MON_NAMESPACE} -f -
        expenv -f ${MANIFEST_PATH}/monitoring/deployment.yaml | oc create --namespace=${MON_NAMESPACE} -f -
        expenv -f ${MANIFEST_PATH}/monitoring/service.json | oc create -f -
        expenv -f ${MANIFEST_PATH}/monitoring/route.yaml | oc create -f -

        until oc -n ${MON_NAMESPACE} get pods --selector=name=monitoring -ojsonpath='{.items[0].status.phase}' | grep Running ; do sleep 10; oc -n ${MON_NAMESPACE} get pods --selector=name=monitoring; done

        # TODO (SPURANAM): Upload Dashboards

    fi

    # Deploy pgadmin4
    if [ "${FEATURE_DEPLOY_PGADMIN}" = "true" ]; then

        oc delete --namespace=${CCP_NAMESPACE} route pgadmin4 > /dev/null 2>&1 || true
        oc delete --namespace=${CCP_NAMESPACE} service pgadmin4-http > /dev/null 2>&1 || true
        oc delete --namespace=${CCP_NAMESPACE} deployment  pgadmin4 > /dev/null 2>&1 || true
        oc delete --namespace=${CCP_NAMESPACE} pod pgadmin4-http > /dev/null 2>&1 || true
        oc delete --namespace=${CCP_NAMESPACE} secret pgadmin4-http-secrets > /dev/null 2>&1 || true
        oc delete --namespace=${CCP_NAMESPACE} pvc pgadmin4-http-data > /dev/null 2>&1 || true

        expenv -f ${MANIFEST_PATH}/pgadmin4-http/pgadmin4-http-pvc-sc.json | oc create --namespace=${CCP_NAMESPACE?} -f -

        oc create --namespace=${CCP_NAMESPACE} secret generic pgadmin4-http-secrets \
            --from-literal=pgadmin-email=${PGADMIN4USERNAME} \
            --from-literal=pgadmin-password=${PGADMIN4PASSWORD}

        expenv -f ${MANIFEST_PATH}/pgadmin4-http/deployment.yaml | oc create --namespace=${CCP_NAMESPACE} -f -
        expenv -f ${MANIFEST_PATH}/pgadmin4-http/service.yaml | oc create --namespace=${CCP_NAMESPACE} -f -
        expenv -f $DIR/pgadmin4-route.yaml | oc create --namespace=${CCP_NAMESPACE} -f -

        until oc -n ${CCP_NAMESPACE} get pods --selector=name=pgadmin4 -ojsonpath='{.items[0].status.phase}' | grep Running ; do sleep 10; oc -n ${CCP_NAMESPACE} get pods --selector=name=pgadmin4; done
    fi

}

function create_crunchydb_instance() {
    local pgo_operator_namespace=$1
    local pgcluster_name=$2
    local full_backup_schedule=${3:-}
    local incr_backup_schedule=${4:-}
    local enable_database_backups=${5:-true}

    source ${GOPATH}/pgopenv

    # check if the cluster exits
    exists=$(oc -n ${pgo_operator_namespace} get pods --selector=name=${pgcluster_name} --no-headers 2>/dev/null| wc -l)
    if [ $exists -ne 0 ]; then
        echo "Error creating cluster ${pgcluster_name}: already exists."
        exit 1
    fi

    echo "Creating PG Cluster ${pgcluster_name}"
    export PGO_APISERVER_URL=https://$(oc -n ${pgo_operator_namespace} get svc postgres-operator -o=custom-columns=NAME:.spec.clusterIP --no-headers):8443

    if ! oc -n ${pgo_operator_namespace} get pgclusters.crunchydata.com -o=custom-columns=NAME:.metadata.name --no-headers | grep -qE "^${pgcluster_name}$"; then
        pgo create cluster ${pgcluster_name}
        if [ $? -ne 0 ]; then
            echo "Error creating cluster $pgcluster_name: pgo create error"
            exit 1
        fi
    fi

    # Sleep to allow Crunchy operator to respond to create cluster request
    wait_for_objects ${pgo_operator_namespace} ${pgcluster_name}

    # Wait for database deployment
    JSONPATH='{range .items[*]}{@.metadata.name}:{range @.status.conditions[*]}{@.type}={@.status};{end}{end}'; until oc -n ${pgo_operator_namespace} get pods --selector=pg-cluster=${pgcluster_name} -o jsonpath="$JSONPATH" 2>&1 | grep -q "Ready=True"; do echo "waiting for postgres-operator to be available"; sleep 1; oc -n ${pgo_operator_namespace} get pods --selector=pg-cluster=${pgcluster_name},service-name=${pgcluster_name}; done


    # Deploy PSQL Backups
    if [ ! -z ${pgcluster_name} ] && [ "${enable_database_backups}" = "true" ]; then
        # check if the cluster exists
        not_present=$(oc -n ${pgo_operator_namespace} get pods --selector=name=${pgcluster_name} --no-headers 1> /dev/null | wc -l)
        if [ ${not_present} -eq 0 ]; then
            # remove existing pgbackrest backup schedules
            existing_schedules=$(pgo show schedule --selector=pg-cluster=${pgcluster_name} | grep "automated" | grep pgbackrest | sed 's/://g')
            for schedule in ${existing_schedules}; do
                pgo delete schedule --schedule-name=$schedule --no-prompt
            done
            # Create schedule
            if [ ! -z "${full_backup_schedule}" ]; then
                echo "Setting up pgbackrest full backup using schedule: ${full_backup_schedule}"
                pgo create schedule --schedule="${full_backup_schedule}" \
                    --schedule-type=pgbackrest \
                    --pgbackrest-backup-type=full ${pgcluster_name}
            fi
            if [ ! -z "$incr_backup_schedule" ]; then
                echo "Setting up pgbackrest incr backup using schedule: ${incr_backup_schedule}"
                pgo create schedule --schedule="${incr_backup_schedule}" \
                    --schedule-type=pgbackrest \
                    --pgbackrest-backup-type=incr ${pgcluster_name}
            fi
            pgo show schedule ${pgcluster_name}
        fi

        # Wait for backrest
        #until [ "$(oc -n ${pgo_operator_namespace} get job ${pgcluster_name}-stanza-create -ojsonpath="{.status.conditions[?(@.type=='Complete')].status}")" == "True" ] > /dev/null 2>&1; do echo "Waiting for backrest repo to initialize" sleep 10; oc -n ${pgo_operator_namespace} get job ${pgcluster_name}-stanza-create; done
    fi
}

# https://access.redhat.com/support/cases/#/case/02352498
# https://access.redhat.com/support/cases/#/case/02335414
function patch_olm(){
    echo ""
}
