#!/bin/bash

set -o errexit
set -o nounset
set -o pipefail

export SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd )
export DATA_ROOT=/home/vagrant

source $SCRIPT_ROOT/lib-common.sh
source $SCRIPT_ROOT/lib-openshift.sh

function enable_proxy() {
    # enable proxy i.e uncomment lines
    local filename=$1
    sed -i '/^#HTTP_PROXY/s/^#//g' $filename
    sed -i '/^#HTTPS_PROXY/s/^#//g' $filename
    sed -i '/^#NO_PROXY/s/^#//g' $filename
}

function disable_proxy() {
    # disable proxy i.e comment lines
    local filename=$1
    sed -i '/^HTTP_PROXY/s/^/#/g' $filename
    sed -i '/^HTTPS_PROXY/s/^/#/g' $filename
    sed -i '/^NO_PROXY/s/^/#/g' $filename
}

if systemctl is-active atomic-openshift-node.service >/dev/null; then
    systemctl stop atomic-openshift-node || true
    systemctl disable atomic-openshift-node || true
fi

if systemctl is-active docker.service >/dev/null; then
    docker stop $(docker ps -aq) >/dev/null 2>&1 || true
    systemctl stop docker || true
    systemctl disable docker || true
fi

for f in /etc/sysconfig/docker /etc/sysconfig/docker-storage /etc/sysconfig/docker-network; do
    if [[ ! -f ${f} ]]; then
        touch $f
    fi
done

if [ "${LOCAL_DEV_PROFILE}" = "build-host" ]; then
    if [ -z "${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}" ]; then
        export http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
        export https_proxy="${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}"
        export no_proxy="${NO_PROXY:-${no_proxy}}"

        # Disable yum proxy
        sed -i '/^proxy/s/^/#/g' /etc/yum.conf

        for f in /etc/environment /etc/sysconfig/docker; do
            if [[ -f ${f} ]]; then
                echo "Disabling proxy configurations in the file $f"
                disable_proxy $f
            fi
        done
    else
        export http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
        export https_proxy="${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}"
        export no_proxy="${NO_PROXY:-${no_proxy}}"

        # Enable yum proxy
        sed -i "/^proxy=.*/d" /etc/yum.conf
        sed -i "/\[main\]/a proxy=${http_proxy}" /etc/yum.conf

        for f in /etc/environment /etc/sysconfig/docker; do
           if [[ -f ${f} ]]; then
                echo "Enaling proxy configurations in the file $f"
                enable_proxy $f
            fi
        done
    fi

    # Start services
    systemctl enable docker || true
    systemctl start docker
    wait_for_service docker

    #docker info
    #systemctl show docker --property Environment
fi

# Update motd
sed -i "s/RHEL OpenShift localdev profile .*/RHEL OpenShift localdev profile         ${LOCAL_DEV_PROFILE}/" /etc/motd

if [ "${LOCAL_DEV_PROFILE}" = "build-host" ]; then
    ## No further action is required for docker host
    echo "NO FURTHER ACTION REQUIRED"
    exit 0
fi

# Since the basebox was built inside a proxied enviornment we need to remove the proxy variables
# from various configurations files and restart the services, if we nolonger in the proxied environment
set +u
if [ -z "${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}" ]; then
    export http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
    export https_proxy="${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}"
    export no_proxy="${NO_PROXY:-${no_proxy}}"

    # https://docs.openshift.com/container-platform/3.11/install_config/http_proxies.html
    # https://docs.openshift.com/container-platform/3.11/admin_guide/manage_nodes.html#modifying-nodes

    # Disable yum proxy
    sed -i '/^proxy/s/^/#/g' /etc/yum.conf

    # Disable proxy configurations
    for f in /etc/environment /etc/sysconfig/atomic-openshift-node /etc/sysconfig/docker /etc/origin/master/master.env; do
        if [[ -f ${f} ]]; then
            echo "Disabling proxy configurations in the file $f"
            disable_proxy $f
        fi
    done

    # Remove proxy settings from master-config.yaml
    if [ ! -f /etc/origin/master/master-config.yaml.original ]; then
        \cp -f /etc/origin/master/master-config.yaml /etc/origin/master/master-config.yaml.original
    fi
    yq d --inplace /etc/origin/master/master-config.yaml admissionConfig.pluginConfig.BuildDefaults.configuration.env || true
    yq d --inplace /etc/origin/master/master-config.yaml admissionConfig.pluginConfig.BuildDefaults.configuration.gitHTTPProxy || true
    yq d --inplace /etc/origin/master/master-config.yaml admissionConfig.pluginConfig.BuildDefaults.configuration.gitHTTPSProxy || true
    yq d --inplace /etc/origin/master/master-config.yaml admissionConfig.pluginConfig.BuildDefaults.configuration.gitNoProxy || true
else
    export http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
    export https_proxy="${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}"
    export no_proxy="${NO_PROXY:-${no_proxy}}"

    # https://docs.openshift.com/container-platform/3.11/install_config/http_proxies.html
    # https://docs.openshift.com/container-platform/3.11/admin_guide/manage_nodes.html#modifying-nodes

    # Enable yum proxy
    sed -i "/^proxy=.*/d" /etc/yum.conf
    sed -i "/\[main\]/a proxy=${http_proxy}" /etc/yum.conf

    # Enale proxy configurations
    for f in /etc/environment /etc/sysconfig/atomic-openshift-node /etc/sysconfig/docker /etc/origin/master/master.env; do
        if [[ -f ${f} ]]; then
            echo "Enabling proxy configurations in the file $f"
            enable_proxy $f
        fi
    done

    # Restore master-config.yaml
    \cp --force ${HOST_SHARE_PATH}/templates/openshift/master-config.yaml /etc/origin/master/master-config.yaml
fi
set -u

# TODO: Delete the hostlocal storage used by Tigera CNX
#rm -rf /var/tigera/elastic-data/*
#rm -rf /var/tigera/elastic-data/*

# Start services
systemctl enable docker || true
systemctl start docker
wait_for_service docker


systemctl enable atomic-openshift-node || true
systemctl start atomic-openshift-node
wait_for_service atomic-openshift-node

## Restart OpenShift control plane
#restart_control_plane

## Wait for OpenShift API server
wait_for_k8s_apiserver https://api.oc.local:8443

## https://stackoverflow.com/questions/1494178/how-to-define-hash-tables-in-bash
## http://www.artificialworlds.net/blog/2012/10/17/bash-associative-array-examples/
## https://lzone.de/cheat-sheet/Bash%20Associative%20Array
#declare -A pods
#pods=( \
#    ["master-etcd-m1.oc.local"]="kube-system" \
#    ["master-api-m1.oc.local"]="kube-system" \
#    ["master-controllers-m1.oc.local"]="kube-system" \
#    ["calico-etcd-*"]="kube-system" \
#    ["calico-kube-controllers-*"]="kube-system" \
#    ["calico-node-*"]="kube-system" \
#    ["docker-registry-*"]="kube-system"
#    )
##echo "${pods[master-etcd-m1.oc.local]}"
##for pod in "${!pods[@]}"; do echo "$pod - ${pods[$pod]}"; done
##for ns in "${pods[@]}"; do echo "$ns - ${pods[$ns]}"; done

# Wait OpenShift Static pods
for pod in master-etcd-m1.oc.local master-api-m1.oc.local master-controllers-m1.oc.local; do
    wait_for_pod kube-system ${pod}
done

# Wait for Calico pods
for pod in calico-etcd-* calico-node-* calico-kube-controllers-*; do
    wait_for_pod kube-system ${pod}
done

# Wait for Kube-proxy pod
# for pod in proxy-*; do
#     wait_for_pod kube-proxy ${pod}
# done

for pod in sync-*; do
    wait_for_pod openshift-node ${pod}
done

#for pod in docker-registry-* registry-console-*; do
#    wait_for_pod default ${pod}
#done

for pod in ipfailover-* router-*; do
    wait_for_pod default ${pod}
done

for pod in webconsole-*; do
    wait_for_pod openshift-web-console ${pod}
done

# for pod in apiserver-*; do
#     wait_for_pod openshift-template-service-broker ${pod}
# done

for pod in kube-state-metrics-* cluster-monitoring-operator-* prometheus-operator-* \
    node-exporter-* prometheus-k8s-* alertmanager-main-* grafana-*; do
    wait_for_pod openshift-monitoring ${pod}
done

if [ "${OPENSHIFT_DEPLOY_CONSOLE}" = "true" ]; then
    for pod in console-*; do
        wait_for_pod openshift-console ${pod}
    done
fi

##oc -n kube-system scale deployment cnx-apiserver --replicas=0 || true
##oc -n kube-system scale deployment cnx-manager --replicas=0 || true
#if [ "${OPENSHIFT_USE_TIGERA_CNX_MANAGER}" = "true" ]; then
#    if oc -n kube-system get deployments | grep -q cnx-manager; then
#        for pod in calicoq cnx-apiserver-* cnx-manager-*; do
#            wait_for_pod kube-system ${pod}
#        done
#    fi
#fi

#oc -n kube-service-catalog scale ds apiserver --replicas=0
#oc -n kube-service-catalog scale ds controller-manager --replicas=0
#oc autoscale deployment.v1.apps/nginx-deployment --min=10 --max=15 --cpu-percent=80

#oc -n operator-lifecycle-manager scale deployment catalog-operator --replicas=0 || true
#oc -n operator-lifecycle-manager scale deployment olm-operator --replicas=0 || true
set +e
if [ "${OPENSHIFT_DEPLOY_OLM}" = "true" ]; then
    if oc -n operator-lifecycle-manager get deployments -o=custom-columns=NAME:.metadata.name --no-headers | grep -qE 'catalog-operator|olm-operator'; then
        for pod in catalog-operator-* olm-operator-*; do
            wait_for_pod operator-lifecycle-manager ${pod}
        done
    fi
fi
set -e

#if [ "${OPENSHIFT_DEPLOY_TMPL_SERVICE_BROKER}" = "true" ]; then
#    # asb-1-*
#    for pod in apiserver-* controller-manager-*; do
#        wait_for_pod kube-service-catalog ${pod}
#    done
#fi

if [ "${OPENSHIFT_NODE_PROBLEM_DETECTOR}" = "true" ]; then
    set +e
    until oc get pods --all-namespaces | grep ${pod} | grep Running; do
        echo "Waiting for ${pod} pod to start";
        sleep 5;
    done
    set -e
fi

# calico-prometheus-operator-* prometheus-calico-node-prometheus-* alertmanager-calico-node-alertmanager-*
if [ "${OPENSHIFT_USE_TIGERA_ANALYTICS}" = "true" ]; then
    set +e
    if oc get project | grep -q calico-monitoring; then
        for pod in elasticsearch-operator-* es-client-tigera-elasticsearch-* \
            es-data-tigera-elasticsearch-elasticsearch-storage-* \
            es-master-tigera-elasticsearch-elasticsearch-storage-* \
            kibana-tigera-elasticsearch-* tigera-fluentd-node-*; do
            wait_for_pod calico-monitoring ${pod}
        done
    fi
    set -e
fi

if [ "${OPENSHIFT_GLUSTERFS}" = "true" ]; then
    set +e
    if oc get project | grep -q glusterfs; then
        for pod in glusterblock-storage-provisioner-* glusterfs-storage-* heketi-storage-*; do
            wait_for_pod glusterfs ${pod}
        done
    fi
    set -e
fi

#if [ "${OPENSHIFT_GLUSTERFS}" = "false" ]; then
#    set +e
#    if oc get project | grep -q nfs-provisioner; then
#        for pod in nfs-provisioner-*; do
#            wait_for_pod nfs-provisioner ${pod}
#        done
#    fi
#    set -e
#fi

if [ "${OPENSHIFT_DEPLOY_LOGGING}" = "true" ]; then
    set +e
    if ! oc -n openshift-logging get deploymentconfig -o jsonpath='{range .items[*]} {@.metadata.name}{end}' | grep -qE 'logging-es-data-master-*|logging-kibana'; then
        for pod in logging-es-data-master-* logging-fluentd-* logging-kibana-*; do
            wait_for_pod openshift-logging ${pod}
        done
    fi
    set -e
fi

oc -n openshift-monitoring scale statefulset/prometheus-k8s --replicas=1
#oc -n openshift-monitoring scale statefulset/alertmanager-main --replicas=1

#set +u
#if [ -z "${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}" ]; then
#    export http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
#    export https_proxy="${HTTPS_PROXY:-${https_proxy:-${HTTP_PROXY:-${http_proxy}}}}"
#    export no_proxy="${NO_PROXY:-${no_proxy}}"
#    # oc -n default get dc/docker-registry -o yaml --export
#    # https://docs.openshift.com/container-platform/3.11/dev_guide/environment_variables.html
#    ## List env variable
#    #oc set env dc/docker-registry -n default --list
#    ## Set env variable
#    #oc set env dc/docker-registry -n default --overwrite HTTP_PROXY='http://internet.ford.com:83'
#
#    ## Unset env variable, if registry is enabled
#    oc set env dc/docker-registry -n default HTTP_PROXY-
#    oc set env dc/docker-registry -n default HTTPS_PROXY-
#    oc set env dc/docker-registry -n default NO_PROXY-
#
#    #oc patch deploymentconfig docker-registry -n default --patch "$(cat ${HOST_SHARE_PATH}/templates/openshift/patch-deploymentconfig-docker-registry.noproxy.yaml)"
#
#    ##oc -n openshift-monitoring get Alertmanager main -o yaml --export
#    ##oc patch alertmanager main -n openshift-monitoring --patch "$(cat ${HOST_SHARE_PATH}/templates/openshift/patch-alertmanager-main.noproxy.yaml)"
#    #oc set env Alertmanager/main -n openshift-monitoring HTTP_PROXY-
#    #oc set env Alertmanager/main -n openshift-monitoring HTTPS_PROXY-
#    #oc set env Alertmanager/main -n openshift-monitoring NO_PROXY-
#else
#    ## Set env variable
#    oc set env dc/docker-registry -n default --overwrite HTTP_PROXY="${http_proxy}"
#    oc set env dc/docker-registry -n default --overwrite HTTPS_PROXY="${https_proxy}"
#    oc set env dc/docker-registry -n default --overwrite NO_PROXY='.cluster.local,.ford.com,.local,.svc,.default.svc,127.0.0.1,169.254.169.254,172.17.4.3,172.30.0.1,api-int.oc.local,localhost,m1.oc.local'
#fi
#set -u


## GlusterFS feature toggle, i know this a very silly way to handle this but it works for now
if [ "${OPENSHIFT_GLUSTERFS}" = "true" ]; then
    export GLUSTERFS_FEATURE_TOGGLE=''
else
    export GLUSTERFS_FEATURE_TOGGLE='#'
fi

# Registry auth credentials
# DOCS: https://access.redhat.com/RegistryAuthentication
# DOCS: https://access.redhat.com/articles/3560571
# DOCS/ https://access.redhat.com/articles/3643972
# curl -u $REG_AUTH_USER:$REG_AUTH_PASSWORD "https://sso.redhat.com/auth/realms/rhcc/protocol/redhat-docker-v2/auth?service=docker-registry&client_id=curl&scope=repository:rhel:pull" -vvv
# DOCS: https://docs.okd.io/latest/dev_guide/managing_images.html#allowing-pods-to-reference-images-from-other-secured-registries
export REG_AUTH_USER=$(cat /root/.docker/config.json | jq -r '.auths."registry.redhat.io".auth' | base64 --decode | cut -d ':' -f1) || true
export REG_AUTH_PASSWORD=$(cat /root/.docker/config.json | jq -r '.auths."registry.redhat.io".auth' | base64 --decode | cut -d ':' -f2) || true

echo "Generate ansible inventory file"
envsubst < ${ANSIBLE_INVENTORY_FILE} > ${DATA_ROOT}/inventory.ini

## Deploy OpenShift
echo "Purge ansible cache"
rm -rf /etc/ansible/ansible.cfg

## Install GlusterFS block and file providers
#if [ "${LOCAL_DEV_PROFILE}" = "glusterfs" ]; then
#    if oc get project | grep -q nfs-provisioner; then
#        uninstall_nfs_provisioner
#    fi
#
#    if ! oc get project | grep -q glusterfs; then
#        install_glusterfs
#    fi
#fi

## Install Console
#if [ "${OPENSHIFT_DEPLOY_CONSOLE}" = "true" ]; then
#    install_console
#fi

## Install Operator Lifecycle Manager (OLM)
#if [ "${OPENSHIFT_DEPLOY_OLM}" = "true" ]; then
#    install_olm
#    grant_view_to_olm
#fi

## Install multi-tenant ElasticSearch
if [ "${OPENSHIFT_DEPLOY_LOGGING}" = "true" ]; then
    install_logging
fi

## Install Tigera network security suite
if [ "${OPENSHIFT_USE_TIGERA_ANALYTICS}" = "true" ]; then
    configure_cnx
    configure_cnx_analytics
fi

# TODO: remove http_proxy setting Alertmanager.main in openshift-monitoring namespace
# oc -n openshift-monitoring get Alertmanager main -o yaml --export > /home/vagrant/share/main.Alertmanager.yaml
# oc -n openshift-monitoring get Prometheus k8s -o yaml --export > /home/vagrant/share/k8s.Prometheus.yaml
# oc -n openshift-monitoring get PrometheusRule prometheus-k8s-rules -o yaml --export > /home/vagrant/share/prometheus-k8s-rules.PrometheusRule.yaml

# OpenShift bootkube https://github.com/openshift/openshift-ansible/pull/10451/files

## Copy KUBECONFIG file to host
postinstall_cleanup

## Display welcome message to user
print_welcome_message

exit 0
