#!/bin/bash

set -o errexit
set -o nounset
set -o pipefail

export SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd )
export DATA_ROOT=/home/vagrant

oc -n kube-system delete deployment cnx-apiserver || true
oc -n kube-system delete deployment cnx-manager || true
oc -n kube-system delete pod calicoctl --force --grace-period=0 || true
oc -n kube-system delete pod calicoq --force --grace-period=0 || true

oc -n kube-service-catalog delete ds apiserver || true
oc -n kube-service-catalog delete ds controller-manager || true

oc -n operator-lifecycle-manager delete deployment catalog-operator || true
oc -n operator-lifecycle-manager delete deployment olm-operator || true

#oc -n openshift-ansible-service-broker delete deployment asb || true
#oc -n openshift-template-service-broker delete deployment apiserver || true
