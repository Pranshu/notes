

export ANSIBLE_ROOT=${DATA_ROOT}
export ANSIBLE_CONFIG=${HOST_SHARE_PATH}/templates/ansible.cfg

export OPENSHIFT_USE_TIGERA_CNX=false
export OPENSHIFT_USE_TIGERA_CNX_MANAGER=false
export OPENSHIFT_USE_TIGERA_ANALYTICS=false
export OPENSHIFT_DEPLOY_LOGGING=false
export OPENSHIFT_USE_GIT_RELEASE=false
export OPENSHIFT_NODE_PROBLEM_DETECTOR=false
export OPENSHIFT_DEPLOY_EXAMPLES=true
export OPENSHIFT_DEPLOY_WEBCONSOLE=true
export OPENSHIFT_DEPLOY_CONSOLE=true
export OPENSHIFT_DEPLOY_ASB_SERVICE_BROKER=false
export OPENSHIFT_DEPLOY_TMPL_SERVICE_BROKER=false
export OPENSHIFT_DEPLOY_OLM=true
export OPENSHIFT_GLUSTERFS=false

if [ "${LOCAL_DEV_PROFILE}" = "basic-ovs" ]; then
    echo ""
elif [ "${LOCAL_DEV_PROFILE}" = "basic-calico" ]; then
    export OPENSHIFT_USE_CALICO_SDN=true
elif [ "${LOCAL_DEV_PROFILE}" = "basic-cnx" ]; then
    export OPENSHIFT_USE_CALICO_SDN=true
    export OPENSHIFT_USE_TIGERA_CNX=true
    export OPENSHIFT_USE_TIGERA_CNX_MANAGER=true
#elif [ "${LOCAL_DEV_PROFILE}" = "basic-cnxmngr" ]; then
#    export OPENSHIFT_USE_CALICO_SDN=true
#    export OPENSHIFT_USE_TIGERA_CNX=true
#    export OPENSHIFT_USE_TIGERA_CNX_MANAGER=true
#elif [ "${LOCAL_DEV_PROFILE}" = "glusterfs" ]; then
#    export OPENSHIFT_USE_CALICO_SDN=true
#    export OPENSHIFT_USE_TIGERA_CNX=true
#    export OPENSHIFT_GLUSTERFS=true
elif [ "${LOCAL_DEV_PROFILE}" = "netsecurity" ]; then
    export OPENSHIFT_USE_CALICO_SDN=true
    export OPENSHIFT_USE_TIGERA_CNX=true
    export OPENSHIFT_USE_TIGERA_ANALYTICS=true
elif [ "${LOCAL_DEV_PROFILE}" = "logging" ]; then
    export OPENSHIFT_USE_CALICO_SDN=true
    export OPENSHIFT_USE_TIGERA_CNX=true
    export OPENSHIFT_GLUSTERFS=true
    export OPENSHIFT_DEPLOY_LOGGING=true
elif [ "${LOCAL_DEV_PROFILE}" = "fullmonty" ]; then
    export OPENSHIFT_USE_CALICO_SDN=true
    export OPENSHIFT_USE_TIGERA_CNX=true
    export OPENSHIFT_USE_TIGERA_ANALYTICS=true
    export OPENSHIFT_GLUSTERFS=true
    export OPENSHIFT_DEPLOY_EXAMPLES=true
    export OPENSHIFT_DEPLOY_WEBCONSOLE=true
    export OPENSHIFT_DEPLOY_CONSOLE=true
    export OPENSHIFT_DEPLOY_LOGGING=true
elif [ "${LOCAL_DEV_PROFILE}" = "build-host" ]; then
    echo ""
fi

echo "DEFAULT_HOST_IP=$DEFAULT_HOST_IP"

if ! grep -q "console.${OPENSHIFT_DOMAIN}" /etc/hosts; then
	echo "Updating /etc/hosts file"
	# Note: DO NOT REPLACE TAB INDENT CHARACTER WITH SPACE, THIS WILL BREAK THE HEREDOC BELOW
	cat <<- EOD > /etc/hosts
	127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
	::1         localhost localhost.localdomain localhost6 localhost6.localdomain6

	${MASTER_IP} ${MASTER_FQDN} ${MASTER_HOSTNAME}
	${MASTER_IP} console.${OPENSHIFT_DOMAIN} console
	${MASTER_IP} api.${OPENSHIFT_DOMAIN} api
	${MASTER_IP} api-int.${OPENSHIFT_DOMAIN} api-int
	EOD
fi

# Make sure that ipv6 is enabled
if grep -q "^net.ipv6.conf." /etc/sysctl.conf; then
    sed -i -e 's@^net.ipv6.conf.*@@' /etc/sysctl.conf
    sysctl -p /etc/sysctl.conf
    dracut -f
    echo "You must issue the following commands, to complete the localdev build:"
    echo "  vagrant halt"
    echo "  vagrant up --provision"
    #systemctl poweroff
    exit 0
fi

#if [ "${VAGRANT_BUILD_CONTEXT}" = "true" ]; then
#    set +e
#    gwdev=$(nmcli dev | grep ethernet | egrep 'unmanaged' | head -n 1 | awk '{print $1}')
#    set -e
#    if [ "${gwdev}" = "eth0" ]; then
#        rm -rf /etc/sysconfig/network-scripts/ifcfg-eth0
#        rm -rf /var/lib/NetworkManager/*
#        systemctl restart NetworkManager
#
#        nmcli connection delete eth0
#        nmcli con add type ethernet ifname eth0 con-name "eth0"
#    fi
#
#fi

# Manually configure DNS settings on the guest to refer to CoreDNS on the host.
nmcli con mod "eth0" ipv4.dns "${DEFAULT_HOST_IP}"
nmcli con mod "eth0" ipv4.dns-search "oc.local"
nmcli con mod "eth0" ipv4.dns-priority 1
nmcli con mod "eth0" ipv4.ignore-auto-dns yes
nmcli connection up eth0
systemctl restart NetworkManager

if [ "${VAGRANT_BUILD_CONTEXT}" = "true" ]; then
    if ! grep -q "^%vagrant ALL=(ALL) NOPASSWD: ALL" /etc/sudoers.d/vagrant; then
		cat <<- EOF | sudo tee /etc/sudoers.d/vagrant
			#%vagrant ALL = (root) NOPASSWD : ALL
			%vagrant ALL=(ALL) NOPASSWD: ALL
			Defaults:vagrant !requiretty
		EOF
		chmod 0440 /etc/sudoers.d/vagrant
    fi
fi

# https://github.com/Mosibi/mosquitto/blob/master/files/generate-CA.sh
set +u
rm -f /etc/environment || true
rm -f /etc/sysconfig/docker || true
if [ "${ENABLE_HTTP_PROXY}" = "true" ]; then
	cat <<- EOF | sudo tee /etc/environment
		HTTP_PROXY="${HTTP_PROXY}"
		HTTPS_PROXY="${HTTPS_PROXY}"
		NO_PROXY="${NO_PROXY}"

		REGISTRY_AUTH_FILE=/root/.docker/config.json
	EOF
	cat <<-EOF | sudo tee -a /etc/sysconfig/docker
		HTTP_PROXY="${HTTP_PROXY}"
		HTTPS_PROXY="${HTTPS_PROXY}"
		NO_PROXY="${NO_PROXY}"
	EOF
else
    unset HTTP_PROXY HTTPS_PROXY NO_PROXY http_proxy https_proxy no_proxy
	cat <<- EOF | sudo tee /etc/environment
		REGISTRY_AUTH_FILE=/root/.docker/config.json
	EOF
fi
set -u

NTP_UPDATE_REQUIRED=false
NTP_STRING='pool pool.ntp.org iburst minpoll 6 maxpoll 10'

## Setup http proxy variables
set +u
if [ ! -z "${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}" ]; then
    export http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
    export https_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
    export no_proxy="${NO_PROXY:-${no_proxy}}"

    # These are consumed by ansible inventory file
    export openshift_http_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
    export openshift_https_proxy="${HTTP_PROXY:-${http_proxy:-${HTTPS_PROXY:-${https_proxy}}}}"
    export openshift_no_proxy="${NO_PROXY:-${no_proxy}}"

    # Configure Yum proxy
    sed -i "/^proxy=.*/d" /etc/yum.conf
    sed -i "/\[main\]/a proxy=${http_proxy}" /etc/yum.conf

    if [ "${OPENSHIFT_DEPLOYMENT_TYPE}" = "openshift-enterprise" ] && [ "${RHSM_ORG}" != "" ] && [ "${RHSM_ACTIVATION_KEY}" != "" ] &&  [ "${VAGRANT_USE_CENTOS}" != "true" ]; then
        http_proxy_re='^https?://(([^:]{1,128}):([^@]{1,256})@)?([^:/]{1,255})(:([0-9]{1,5}))?/?'
        # http_proxy_re='^http:\/\/(([^:]+):?(\S+)?@)?([^:]+)(:(\d+))?\/?$'
        if [[ "$http_proxy" =~ $http_proxy_re ]]; then
            # skip parent nesting groups 1 and 5
            export proxy_user=${BASH_REMATCH[2]}
            export proxy_pass=${BASH_REMATCH[3]}
            export proxy_host=${BASH_REMATCH[4]}
            export proxy_port=${BASH_REMATCH[6]}
        fi
        subscription-manager config --server.proxy_hostname="${proxy_host}" --server.proxy_port="${proxy_port}" --server.no_proxy="${no_proxy}"
    fi

    NTP_STRING='server time.ford.com iburst minpoll 6 maxpoll 10'
else
    # These are consumed by ansible inventory file
    export openshift_http_proxy=""
    export openshift_https_proxy=""
    export openshift_no_proxy=""

    # Delete the line, with proxy configuration from /etc/yum.conf
    sed -i "/^proxy=.*/d" /etc/yum.conf

    # if [ "${OPENSHIFT_DEPLOYMENT_TYPE}" = "openshift-enterprise" ] && [ "${RHSM_ORG}" != "" ] && [ "${RHSM_ACTIVATION_KEY}" != "" ]; then
    if [ "${OPENSHIFT_DEPLOYMENT_TYPE}" = "openshift-enterprise" ] &&  [ "${VAGRANT_USE_CENTOS}" != "true" ]; then
        subscription-manager config --server.proxy_hostname='' --server.proxy_port='' --server.no_proxy=''
    fi
fi

if ! grep -q "^${NTP_STRING}$" /etc/chrony.conf; then
	NTP_UPDATE_REQUIRED=true
fi

if [ ${NTP_UPDATE_REQUIRED} ]; then
	if [ $(systemctl is-active chronyd) = "active" ]; then
		systemctl stop chronyd >/dev/null
	fi

	## Delete existing configs
	sed -Ei "/^(server|pool) .*$/d" /etc/chrony.conf

	## Add new configs
	sed -i "3s/^/${NTP_STRING}\n/" /etc/chrony.conf

	if ! systemctl is-active chronyd >/dev/null; then
		systemctl enable chronyd >/dev/null || true
		systemctl start chronyd >/dev/null
	fi
fi

# Test internet connectivity
CONNECTION_TEST_URL='www.google.com'
HTTP_CODE=$( curl \
                --connect-timeout 20 --retry 5  --retry-delay 0 --head --insecure \
                --location --silent --show-error --fail --output /dev/null \
                --write-out "%{http_code}" \
                $CONNECTION_TEST_URL
)
if [ "$HTTP_CODE" != "200" ]; then
    echo "Please check your internet connectivity"
    exit 1
else
    echo "Your internet connectivity has been successfully verified !"
fi
set -u

echo "${MASTER_FQDN}" > /etc/hostname

# RHSM subscription setup
#local SUBSTATUS=$(subscription-manager status | grep "^Overall" | awk '{print $NF}') || true
#IDENTITY=$(LANG=C subscription-manager identity 2> /dev/null | sed -n 's/system identity: //p')
#[ "${IDENTITY}" ] || exit_msg "Host is not registered. Skipping."
set +e
/sbin/subscription-manager identity > /dev/null
if [ $? -ne 0 ] && [ "${RHSM_ORG}" != "" ] && [ "${RHSM_ACTIVATION_KEY}" != "" ]; then
    echo "Enrolling VM with Red Hat Subscription-Manager"
    subscription-manager register --org="${RHSM_ORG}" --activationkey="${RHSM_ACTIVATION_KEY}" || true
fi
set -e

echo "Enable RHEL repositories"
#yum makecache fast
subscription-manager repos \
    --enable="rhel-7-server-rpms" \
    --enable="rhel-7-server-extras-rpms" \
    --enable="rhel-7-server-ose-${OPENSHIFT_RELEASE_MAJOR_VERSION}-rpms" \
    --enable="rhel-7-server-ansible-2.6-rpms" \
    --enable="rhel-7-fast-datapath-rpms" \
    --enable="rh-gluster-3-client-for-rhel-7-server-rpms" \
    --enable="rhel-7-server-optional-rpms" || true

if ! which openssl > /dev/null; then
    yum install -y openssl
fi

export OPENSHIFT_USER_PASSWD_ENC="$(echo $OPENSHIFT_USER_PASSWD | openssl passwd -stdin -apr1)"

if [ "${OPENSHIFT_DEPLOYMENT_TYPE}" = "openshift-enterprise" ] &&  [ "${VAGRANT_USE_CENTOS}" != "true" ]; then
    export ANSIBLE_ROOT=/usr/share/ansible
fi

declare -A TOOLS=( \
    ['https://github.com/stedolan/jq/releases/download/jq-1.6/jq-linux64']='/usr/local/bin/jq' \
    ['https://github.com/mikefarah/yq/releases/download/2.4.0/yq_linux_amd64']='/usr/local/bin/yq' \
    ['https://files.caas.ford.com:9443/cfssl/1.3.3/linux/cfssl']='/usr/local/bin/cfssl' \
    ['https://files.caas.ford.com:9443/cfssl/1.3.3/linux/cfssljson']='/usr/local/bin/cfssljson' \
    ['https://dl.minio.io/client/mc/release/linux-amd64/mc']='/usr/local/bin/mc' \
    ['https://github.com/a8m/envsubst/releases/download/v1.1.0/envsubst-Linux-x86_64']='/usr/local/bin/go-envsubst'
    ['https://github.com/FiloSottile/mkcert/releases/download/v1.4.0/mkcert-v1.4.0-linux-amd64']='/usr/local/bin/mkcert'
)

for tool in "${!TOOLS[@]}"; do
    if [ ! -f ${TOOLS[$tool]} ]; then
        echo "Downloading ${TOOLS[$tool]} from ${tool} ..."
        curl \
            --connect-timeout 20 \
            --retry 5 \
            --retry-delay 0 \
            --retry-max-time 60 \
            --insecure \
            --progress-bar \
            --location \
            --output ${TOOLS[$tool]} \
            ${tool}
        chmod +x ${TOOLS[$tool]}
    fi
done