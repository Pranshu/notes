Setup RSYSLOG on jumpbox -----------------------------------------
firewall-cmd --permanent --add-port=514/udp
firewall-cmd --reload

cat > /etc/rsyslog.d/haproxy.conf <<EOF
\$ModLoad imudp \$UDPServerRun 514
\$AllowedSender UDP, 19.15.251.0/32, 19.5.205.0/32, *.caas.ford.com
\$template RemoteLogs,"/var/log/%HOSTNAME%/%PROGRAMNAME%.log"
*.* ?RemoteLogs
& ~
EOF
systemctl restart rsyslog

# Fix default routers
```bash
# Update the existing router running in default namespace
oc set env dc/router -n default --overwrite ROUTER_SERVICE_SNI_PORT="20444"
oc set env dc/router -n default --overwrite ROUTER_SERVICE_NO_SNI_PORT="20443"
```

# Deploy debug router
```bash

oc new-project debug-router
oc annotate namespace debug-router openshift.io/node-selector=node-role.kubernetes.io/infra=true --overwrite

oc -n debug-router create serviceaccount router

oc -n debug-router adm policy add-scc-to-user hostnetwork -z router

#oc -n debug-router adm router router --replicas=0 --ports='10080:10080,10443:10443' --stats-port=1937 --service-account=router

oc -n debug-router adm policy add-cluster-role-to-user system:router -z router
oc -n debug-router adm policy add-cluster-role-to-user cluster-reader -z router

# Only in production
oc create secret generic router-certs \
    --from-file=tls.crt=/FULL-PATH-TO/WILDCARD-CERT.pem \
    --from-file=tls.key=/FULL-PATH-TO/WILDCARD-CERT-KEY.pem \
    --type=kubernetes.io/tls -o json --dry-run | oc -n debug-router replace -f -

Remove annotations.service.alpha.openshift.io/serving-cert-secret-name from svc.yaml

# create service before creating dc since it generates self-signed certificates
oc -n debug-router create -f /PATH-TO/scv.yaml

# Please update and uncomment the syslog endpoint see line 78 - 79 in this dc.yaml
# please update line 85 to point to correct domain name
oc -n debug-router create -f /PATH-TO/dc.yaml

oc -n debug-router scale dc/router --replicas 1
```

# Test
```bash
oc new-project test-router
oc label namespace test-router "router=debug-router" --overwrite

export MANIFEST_PATH='/home/vagrant/share/templates/debug-router'
export TEST_NAMESPACE='test-router'
export TEST_ROUTE='status.app1.oc.local'

oc create -f ${MANIFEST_PATH}/test/configmap.yaml
envsubst < ${MANIFEST_PATH}/test/deployment.yaml | oc create -f -


#oc -n test-router expose service/status --hostname="status.app1.oc.local"

curl -LIk ${TEST_ROUTE}
```


ssh \
    -o LogLevel=FATAL \
    -o Compression=yes \
    -o DSAAuthentication=yes \
    -o IdentitiesOnly=yes \
    -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o IdentityFile="/root/.ssh/files" \
    root@files.caas.ford.com


# Health check
curl -LI http://19.15.251.132:1937/healthz
curl -LI http://19.15.251.140:1937/healthz
curl -LI http://19.15.251.148:1937/healthz
curl -LI http://19.15.251.156:1937/healthz

curl -LI http://19.5.205.12:1937/healthz
curl -LI http://19.5.205.20:1937/healthz

# Router Smoke-Test
curl -H 'Host: status.app1.caas.ford.com' --insecure https://19.15.251.132:10443
curl -H 'Host: status.app1.caas.ford.com' --insecure https://19.15.251.140:10443
curl -H 'Host: status.app1.caas.ford.com' --insecure https://19.15.251.148:10443
curl -H 'Host: status.app1.caas.ford.com' --insecure https://19.15.251.156:10443

curl -H 'Host: status.app1.caas.ford.com' --insecure https://19.5.205.12:10443
curl -H 'Host: status.app1.caas.ford.com' --insecure https://19.5.205.20:10443





curl admin:8dyYNJbEc7@10.254.254.35:1936/metrics

http://admin:Oe9xmIoywj@19.15.251.132:1937/metrics
http://admin:Oe9xmIoywj@19.15.251.132:1937
curl -u admin:Oe9xmIoywj localhost:1937/metrics

https://access.redhat.com/solutions/3397701
https://blog.openshift.com/kubernetes-ingress-vs-openshift-route/
https://bugzilla.redhat.com/show_bug.cgi?id=1467257
https://www.me2digital.com/blog/2019/05/haproxy-sni-routing/
https://dodgydudes.se/expose-haproxy-stats-on-openshift/
https://access.redhat.com/discussions/3900071
https://access.redhat.com/articles/3679861
https://access.redhat.com/solutions/3867961
https://access.redhat.com/solutions/3447991


oc -n debug-router set env dc router ROUTER_METRICS_TYPE-
oc -n debug-router set env dc router --overwrite ROUTER_METRICS_TYPE="haproxy"

oc set env Alertmanager/main -n openshift-monitoring HTTPS_PROXY-