#!/bin/bash

set -o errexit
set -o nounset
set -o pipefail

IMAGE_NAME=files.caas.ford.com/caas-infra/grafana
IMAGE_TAG=6.3.3

SCRIPT_ROOT=$( cd "$( dirname "$0" )" && pwd )

function finish {
    buildah rmi --force $(buildah images --format "{{.ID}}:{{.Name}}" | grep ":<none>" | cut -d':' -f1) || true
    podman images
}

# Lets first assume we do not have to traverse Ford HTTP proxies
export ENABLE_PROXY=false

set +e
HTTP_CODE=$( \
    curl \
    --head \
    --insecure \
    --location \
    --silent \
    --show-error \
    --fail \
    --output /dev/null \
    --write-out "%{http_code}" \
    --connect-timeout 10 \
    --proxy http://internet.ford.com:83 \
    https://google.com
)
if [ "$HTTP_CODE" = "200" ]; then
    export ENABLE_PROXY=true
fi

set -e
if [ "$ENABLE_PROXY" = "true" ]; then
    export http_proxy="http://internet.ford.com:83"
    export https_proxy="http://internet.ford.com:83"
    export no_proxy="localhost,127.0.0.1,.ford.com,.local"
else
    export http_proxy=""
    export https_proxy=""
    export no_proxy=""
fi

# We need to be in the directory
cd $SCRIPT_ROOT

# --no-cache : Do not use cache when building the image
# --rm=true  : Remove intermediate containers after a successful build
# --compress : Compress the build context using gzip
# https://blog.codeship.com/3-different-ways-to-provide-docker-build-context/

#--build-arg VCS_URL=https://github.ford.com/Containers/samples \
#--build-arg VCS_REF=$(git rev-parse --short HEAD) \
#--build-arg BUILD_DATE=$(date -u +'%Y-%m-%dT%H:%M:%SZ') \

CMD="/bin/buildah bud  \
    --format=docker \
    --network=host \
    --build-arg http_proxy=$http_proxy \
    --build-arg HTTP_PROXY=$http_proxy \
    --build-arg https_proxy=$http_proxy \
    --build-arg HTTPS_PROXY=$http_proxy \
    --build-arg no_proxy=$no_proxy \
    --build-arg NO_PROXY=$no_proxy \
    --no-cache \
    --rm=true \
    -t $IMAGE_NAME:$IMAGE_TAG \
    -f Dockerfile \
    ."

$CMD

trap finish EXIT
trap finish INT
trap finish SIGHUP
trap finish SIGUSR1
trap finish SIGINT  # 2
trap finish SIGQUIT # 3
trap finish SIGKILL # 9
trap finish SIGTERM # 15
