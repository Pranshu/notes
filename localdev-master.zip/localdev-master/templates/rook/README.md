- https://github.com/rook/rook/blob/master/Documentation/ceph-object.md


kubectl -n rook-ceph get secret rook-ceph-object-user-my-store-my-user -o yaml | grep AccessKey | awk '{print $2}' | base64 --decode | pbcopy

kubectl -n rook-ceph get secret rook-ceph-object-user-my-store-my-user -o yaml | grep SecretKey | awk '{print $2}' | base64 --decode | pbcopy


./mc config host add ldev http://s3.app.oc.local 6AQ6WJNO3XG6ZQ038QBE Mlb2fFIrdIbEv44Pjb3SLQsR8DZC1LTmrRJNDOvL --api S3v4

mc config host add ldev http://s3.app.oc.local 6AQ6WJNO3XG6ZQ038QBE Mlb2fFIrdIbEv44Pjb3SLQsR8DZC1LTmrRJNDOvL --api S3v2

export MC_HOST_<alias>=https://<Access Key>:<Secret Key>@<YOUR-S3-ENDPOINT>
export MC_HOST_ldev=http://YEMPG5SF1I42E3L1489B:3aRl97zLFCo7p2ih2vpSJDeTGW2pgOCtB5OPXz3e@s3.app.oc.local
./mc ls --recursive --debug ldev
./mc mb --debug ldev/hello

./mc cp inventory.ini ldev/hello
./mc cat ldev/hello/inventory.ini


export AWS_HOST=s3.app.oc.local:8080
export AWS_ENDPOINT=172.30.124.226:8080
export AWS_ACCESS_KEY_ID=YEMPG5SF1I42E3L1489B
export AWS_SECRET_ACCESS_KEY=3aRl97zLFCo7p2ih2vpSJDeTGW2pgOCtB5OPXz3e

s3cmd mb --no-ssl --host=${AWS_HOST} --host-bucket=  s3://rookbucket

mc ls --recursive --insecure --debug ldev
mc mb --insecure ldev/datastorage/registry/


rook-ceph-object-user-quay-store-quay-user