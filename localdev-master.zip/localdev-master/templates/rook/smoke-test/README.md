```bash

oc new-project test-rook

oc create secret docker-registry toolbox-pull-secret \
--docker-username="caas-infra+image_puller" \
--docker-password="1ERKJU6QVC968VJ983LG4QM2HCX4FOFDW6DX05CP4XIRJZ85RRCLZAUPQQTWQ4LI" \
--docker-email=mysecret@ford.com \
--docker-server files.caas.ford.com \
--namespace=test-rook

oc secrets link default toolbox-pull-secret --for=pull --namespace=test-rook

POD=$(oc -n test-rook get pod -l "app=toolbox" -o jsonpath='{.items[0].metadata.name}')

oc -n test-rook exec ${POD} -- bash -c "while true; do echo \"$(date +'%Y/%m/%d %H:%M:%S,%3N')\" | tee -a /external-block-storage/rook-test.txt; sleep 1; done"

oc -n test-rook exec ${POD} -- bash -c "cat /external-block-storage/rook-test.txt"


while true; do echo "$(date +'%Y/%m/%d %H:%M:%S')" | tee -a /external-block-storage/rook-test.txt; sleep 1; done
```
