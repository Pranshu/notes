**What steps did you take and what happened:**
[A clear and concise description of what the bug is, and what commands you ran.)


**What did you expect to happen:**


**The output of the following commands will help us better understand what's going on**:
(Pasting long output into a [GitHub gist](https://gist.github.ford.com).)

* upload `./artifacts/logs/provision_*.log`
* `vagrant --version`
* `vboxmanage --version`
* Operating system version
* hardware configuration

**Anything else you would like to add:**
[Miscellaneous information that will assist in solving the issue.]
