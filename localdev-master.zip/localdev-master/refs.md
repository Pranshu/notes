## Localdev

## Kubeadm
- https://github.com/oracle/vagrant-boxes

## Ansible
- https://netapp.io/2018/12/14/can-you-keep-a-secret/
- https://github.com/chamilton614/ocp_advanced_deployment_homework/blob/master/playbooks/openshift_postinstall.yaml
- https://github.com/jcpowermac/ocp-public-url-change/blob/master/main.yml
- https://github.com/outcoldsolutions/openshift-webconsole-integration/tree/master (web-console)
- https://github.com/openshift/online-console-extensions (web-console)
- https://github.com/devonfw/devonfw-shop-floor/blob/master/dsf4openshift/openshift-cluster-setup/initial-setup/customizeOpenshift/README.md (web-console)
- https://github.com/radanalyticsio/oshinko-console/blob/master/tools/oshinko-setup.sh
- https://github.com/eformat/lib_openshift

## Vagrant

## VirtaulBox

## RHEL

## Packer

## Trident
- https://netapp.io/2018/12/19/installing-trident-from-a-private-registry/
- https://netapp.io/2018/09/21/ontap-ai-and-netapp-trident-streamlining-and-simplifying-ai-workloads/

## BGP
- http://networkstatic.net/gobgp-control-plane-evolving-software-networking/
- http://networkstatic.net/measuring-network-bandwidth-using-iperf-and-docker/
