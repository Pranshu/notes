#!/bin/bash

# https://serverfault.com/questions/741670/rsync-files-to-a-kubernetes-pod
# https://docs.amazee.io/openshift/rsync-into-container.html
# https://download.samba.org/pub/rsync/rsync.html

if [ -z "$KRSYNC_STARTED" ]; then
    export KRSYNC_STARTED=true
    exec rsync --blocking-io --rsh "$0" $@
fi

# Running as --rsh
namespace=''
pod=$1
shift

# If use uses pod@namespace rsync passes as: {us} -l pod namespace ...
if [ "X$pod" = "X-l" ]; then
    pod=$1
    shift
    namespace="-n $1"
    shift
fi

exec kubectl $namespace exec -i $pod -- "$@"

#./krsync -av --progress --stats source-dir/ $pod:/destination-dir/
#./krsync -av --progress --stats src-dir/ pod@namespace:/dest-dir
